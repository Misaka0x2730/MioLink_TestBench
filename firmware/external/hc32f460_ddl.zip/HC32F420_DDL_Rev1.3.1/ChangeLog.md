# Update History
------
## V1.3.1  Dec 26, 2025
### drivers
-  **ClassB**
  - 添加ClassB样例
## V1.3.0  Dec 26, 2024
### documents
- **更新hc32f420_ddl.chm文件**
### drivers
-  **adc.c**
  - 修改ADC\_Set\_SQR\_ChCnt()函数输入参数的数据范围
  - 修改ADC\_Threshold\_Cmp\_Cfg()函数
-  **adc.h**
  - 修改结构体注释等
-  **spi.c**
  - 修改Spi_Init()函数中CR0寄存器SMP位的mask值
-  **gpio.h**
  - 修改GPIO\_PORTx\_WRITE\_x\_BYTE宏定义等
-  **vc.c**
  - 修改VC\_GetFilterOutput()函数的注释
-  **lvd.c**
  - 删除边界值判断宏定义
### example
-  **adc**
   - adc\_scan\_sqr\_hw\_trig样例，修改main.c中ADC_Set_SQR_ChCnt()函数的调用数据描述形式
   - adc\_scan\_sqr\_sw样例，修改main.c中ADC_Set_SQR_ChCnt()函数的调用数据描述形式
   - adc\_single\_channel\_sw样例，修改main.c中EOC相关为ESG，u32AdcRestult的读取从寄存器读取改为API读取
   - 添加adc\_ts样例
-  **usart**
   - usart\_uart\_tx\_dma\_hw\_trigger\_block样例，修改main.c中u32DMATxRxTransfer的赋值
-  **flash**
   - flash\_cache样例，为GPIO宏定义调用添加分号
-  **sysctrl**
   - sysctrl\_clk\_switch样例，为GPIO宏定义调用添加分号
   - sysctrl\_systick样例，为GPIO宏定义调用添加分号
### mcu
- **common**
   - 修改HC32F420.h中\__MPU\_PRESENT宏定义值

------
## V1.2.0  Dec 29, 2023
### documents
- **更新hc32f420_ddl.chm文件**
### drivers
-  **lin.c**
  - 更新Parity生成代码、功能开启和除能位置修改
-  **usart.c和usart.h**
  - 更新以适配9bits数据、添加自动波特率计算中范围检查
  - 添加IR、smart card相关
-  **ctrim.h**
  - 添加CTRIM\_REF\_CLOCK\_DIV256宏定义
-  **iwdt.c**
  - IWDT开启后添加500us延时
-  **dmac.h**
  - 修改DMA触发源的注释
-  **lpm.c**
  - 修改LPM\_GotoDeepSleep函数和LPM\_GotoSleep函数
-  **ddl.c**
  - 修改delay1ms()、delay100us()和delay10us()函数
-  **flash.c和flash.h**
  - 添加Flash_Chip_Erase()功能
  - 在FLASH擦和写操作完成后添加CR.OP设置为0的操作
-  **sysctrl.c**
  - PLL的输入时钟不能为RCH的24M输出，在Sysctrl\_PLL\_Para\_Check()中添加SYSCTL_RCHCR.DIV不能设置为8（即1分频）的限制
-  **adc.h**
  - 删除ADC\_Channel\_Mux18\_VREF\_1p2宏定义
-  **vc.h**
  - 删除VC\_INPUT\_MINUS\_REF1p2宏定义
### example
-  **spi**
   - 修改部分样例中端口初始化函数
-  **usart**
   - 添加usart\_uart\_rx\_tx\_9bits样例
   - 添加usart\_smart\_card\_it样例
   - 添加usart\_ir\_38k样例
   - 修改部分样例API调用实参
-  **iwdt**
   - 删除样例中IWDT_Start()调用
-  **sysctrl**
   - 修改样例sysctrl\_clk\_switch中SYSCTRL\_XTH\_20t32MHz为SYSCTRL\_XTH\_8t16MHz
-  **ctrim**
   - 修改样例ctrim\_rcl\_cal中SYSCTRL\_XTH\_20t32MHz为SYSCTRL\_XTH\_8t16MHz
-  **flash**
   - 添加flash\_chip\_erase样例
-  **atimer3**
   - 修改atimer3\_m23\_pwm\_port\_vc样例中VC的设置
-  **vc**
   - 删除样例vc\_vref\_1p2\_falling\_irq和vc\_vref\_1p2\_high\_irq
### mcu
- **EWARM**
   - 更新HC32F420.svd
- **common**
   - system\_hc32f420.c中SystemCoreClockUpdate()函数中添加SysTick初始化

------
## V1.1.0  Aug 1, 2023
### documents
- **更新hc32f420_ddl.chm文件**
### drivers
-  **flash.c**
  - 擦写函数中添加关闭Cache功能及Cache原功能设置的恢复
-  **gtim.h**
  - 修改GTIM_CR1寄存器的ETRFLT位0y110和0y111的宏定义名
-  **sysctrl.c和sysctrl.h**
  - 删除FLASH Sector容量
  - 修改en\_sysctrl\_func_t内成员名
### example
-  **修改IAR和Keil工程文件默认芯片类型为STK芯片型号**
-  **adc**
    - 修改所有样例中注释
-  **dmac**
    - 修改所有样例中main.c中调用参数、注释和readme.h描述
    - 修改样例名dma\_terminate为dmac\_terminate
-  **iwdt**
   - 修改iwdt_int样例中main.c注释
-  **flash**
   - 添加flash_cache样例
-  **sysctrl**
   - 修改sysctrl\_clk\_switch样例，包括80M倍频设置参数、LED端口、注释等
-  **wwdt**
   - 修改wwdt\_reset\_window样例中main.c中注释
-  **usart**
   - 添加usart\_uart\_rx\_poll\_overtime样例
-  **lpmode**
   -  修改gpio\_deepsleep\_wakeup样例名为lpmode\_deepsleep\_wakeup，并修改切换Deepsleep前切回RCH并关闭PLL
-  **cortex_m4**
   -  添加bit_band样例
### mcu
- **修改EWARM\HC32F420.svd**
- **更新FlashHC32F420.out和HC32F420_128KB.FLM**

------
## V1.0.0  Apr 7, 2023
- Initial release.
