/**
 *******************************************************************************
 * @file  sysctrl.h
 * @brief This file contains all the functions prototypes of the SYSCTRL driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */
#ifndef __SYSCTRL_H__
#define __SYSCTRL_H__

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_SYSCTRL SYSCTRL子模块驱动库
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup SYSCTRL_Global_Types SYSCTRL全局类型定义
 * @{
 */

/**
 * @brief  SYSCTRL information structure definition
 */
typedef struct
{
    uint8_t  u8UID[6];        /*!< 6字节UID(唯一识别号)       */
    char_t*  pcProductNumber; /*!< 32字节产品型号"HC32xxx ……" */
    uint32_t u32FlashSize;    /*!< FLASH容量(Byte)            */
    uint32_t u32RamSize;      /*!< RAM容量(Byte)              */
    uint16_t u16PinCount;     /*!< 管脚数量                   */
} stc_sysctrl_chip_info_t;

/**
 * @brief  SYSCTRL source config structure definition
 */
typedef struct
{
    uint32_t u32SysClkSourceType; /*!<  系统时钟源 @ref SYSCLK_SOURCE_TYPE */
    uint32_t u32RCHState;         /*!<  RCH 配置   @ref SYSCLK_RCH_CONFIG  */
    uint32_t u32XTHState;         /*!<  XTH 配置   @ref SYSCLK_XTH_CONFIG  */
    uint32_t u32RCLState;         /*!<  RCL 配置   @ref SYSCLK_RCL_CONFIG  */
    uint32_t u32PLLState;         /*!<  PLL 配置   @ref SYSCLK_PLL_CONFIG  */
} stc_sysctrl_sysclk_source_init_t;

/**
 * @brief  SYSCTRL clock config structure definition
 */
typedef struct
{
    uint32_t u32ClockType;    /*!< 需要初始化的时钟类型   @ref Sysclk_Init_Type  */
    uint32_t u32SysClkSource; /*!< 系统时钟源             @ref Sysclk_Src_Type   */
    uint32_t u32HClkDiv;      /*!< HCLK时钟分频           @ref System_HCLK_Prs   */
    uint32_t u32PClk0Div;     /*!< PCLK0时钟分频          @ref System_PCLK0_Prs  */
    uint32_t u32PClk1Div;     /*!< PCLK1时钟分频          @ref System_PCLK1_Prs  */
    uint32_t u32WaitCycle;    /*!< FLASH读等待周期        @ref Flash_Wait_Cycle  */
} stc_sysctrl_clk_init_t;

/**
 * @brief  SYSCTRL pll config structure definition
 */
typedef struct
{
    uint8_t u8Source;    /*!< PLL时钟源   */
    uint8_t u8OutputDiv; /*!< PLL输出分频 */
    uint8_t u8DIVN;      /*!< PLL分频N    */
    uint8_t u8MulM;      /*!< PLL整数倍频 */
} stc_sysctrl_pll_cfg_t;

/**
 * @brief  SYSCTRL function enum definition
 */
typedef enum en_sysctrl_func
{
    Sysctrl_Fun_SWD_0_IO_1             = 0u, /*!< 0:用作SWD端口，1：设为IO功能                                                         */
    Sysctrl_Fun_SPI_0_IO_1             = 3u, /*!< 0:用于SPI端口，1：设为IO功能                                                         */
    Sysctrl_Fun_XTHFLT_DIS_0_EN_1      = 4u, /*!< 1:使能XTH时钟滤波，0：关闭该功能                                                     */
    Sysctrl_Fun_XTHFaultSw_DIS_0_EN_1  = 5u, /*!< 1:系统时钟来源为晶体且晶体失效时，自动切换系统时钟来源为RCH， 0：维持原系统时钟源    */
    Sysctrl_Fun_CMLockUpDIS_0_EN_1     = 6u, /*!< 1:使能后CPU执行无效指令会复位MCU，0：关闭该功能                                      */
    Sysctrl_Fun_WakeupByRCH_DIS_0_EN_1 = 7u, /*!< 1:使能从 Deep Sleep 唤醒后 system clock来源为RCH 原时钟继续使能，0：维持原系统时钟源 */

    Sysctrl_Fun_Gtim0_0_Btim012_1 = 8u,  /*!< 1：Gimer0不使用 Btimer012使用   0：Gimer0使用 Btimer012不使用                        */
    Sysctrl_Fun_Gtim1_0_Btim345_1 = 10u, /*!< 1：Gimer1不使用 Btimer345使用   0：Gimer1使用 Btimer345不使用                        */
    Sysctrl_Fun_Gtim2_0_Btim678_1 = 12u, /*!< 1：Gimer2不使用 Btimer678使用   0：Gimer2使用 Btimer678不使用                        */

    Sysctrl_Fun_RCH_DIS_0_EN_1  = 32u, /*!< 1:使能内部高速时钟 RCH 使能控制，0：关闭                                             */
    Sysctrl_Fun_XTH_DIS_0_EN_1  = 33u, /*!< 1:使能外部高速时钟 XTH 使能控制，0：关闭                                             */
    Sysctrl_Fun_RCL_DIS_0_EN_1  = 34u, /*!< 1:使能内部低速时钟 RCL使能控制，0：关闭                                              */
    Sysctrl_Fun_PLL_DIS_0_EN_1  = 36u, /*!< 1:时钟 PLL 使能控制，0：关闭                                                         */
    Sysctrl_Fun_EXTH_DIS_0_EN_1 = 37u, /*!< 1:XTH外部输入时钟使能，0：关闭                                                       */
} en_sysctrl_func_t;

/**
 * @brief  SYSCTRL peripheral gate enum definition
 */
typedef enum en_sysctrl_peripheral_gate
{
    SysctrlPeripheralUsart0 = 0u,  /*!<  串口0           */
    SysctrlPeripheralUsart1 = 1u,  /*!<  串口1           */
    SysctrlPeripheralUsart2 = 2u,  /*!<  串口2           */
    SysctrlPeripheralUsart3 = 3u,  /*!<  串口3           */
    SysctrlPeripheralI2c0   = 10u, /*!<  I2C0            */
    SysctrlPeripheralI2c1   = 11u, /*!<  I2C1            */
    SysctrlPeripheralSpi0   = 14u, /*!<  SPI0            */
    SysctrlPeripheralSpi1   = 15u, /*!<  SPI1            */
    SysctrlPeripheralCTim0  = 20u, /*!<  通用定时器CTIM0 */
    SysctrlPeripheralCTim1  = 21u, /*!<  通用定时器CTIM1 */
    SysctrlPeripheralCTim2  = 22u, /*!<  通用定时器CTIM2 */
    SysctrlPeripheralATim0  = 24u, /*!<  高级定时器ATIM0 */
    SysctrlPeripheralATim3  = 27u, /*!<  高级定时器ATIM3 */

    SysctrlPeripheralCtrim = 32u, /*!<  时钟校准        */
    SysctrlPeripheralWwt   = 34u, /*!<  看门狗          */
    SysctrlPeripheralIwt   = 35u, /*!<  看门狗          */
    SysctrlPeripheralAdc0  = 40u, /*!<  ADC0            */
    SysctrlPeripheralAdc1  = 41u, /*!<  ADC1            */
    SysctrlPeripheralVc    = 42u, /*!<  VC              */
    SysctrlPeripherallvd   = 43u, /*!<  LVD             */

    SysctrlPeripheralDma   = 64u, /*!<  DMA             */
    SysctrlPeripheralCrc   = 66u, /*!<  CRC             */
    SysctrlPeripheralFlash = 69u, /*!<  Flash           */

    SysctrlPeripheralGpioa = 128u, /*!<  GPIOA           */
    SysctrlPeripheralGpiob = 129u, /*!<  GPIOB           */
    SysctrlPeripheralGpioc = 130u, /*!<  GPIOC           */
    SysctrlPeripheralGpiod = 131u, /*!<  GPIOD           */
} en_sysctrl_peripheral_gate_t;

/**
 * @}
 */

/*******************************************************************************
 * Sysctrl pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup SYSCTRL_Global_Macros SYSCTRL全局宏定义
 * @{
 */

/**
 * @defgroup SYSCLK_SOURCE_TYPE 系统时钟源类型定义
 * @{
 */
#define SYSCTRL_SYSCLK_SOURCE_TYPE_RCH (0x1u) /*!< 选取RCH做系统时钟源  */
#define SYSCTRL_SYSCLK_SOURCE_TYPE_XTH (0x2u) /*!< 选取XTH做系统时钟源  */
#define SYSCTRL_SYSCLK_SOURCE_TYPE_RCL (0x4u) /*!< 选取RCL做系统时钟源  */
#define SYSCTRL_SYSCLK_SOURCE_TYPE_PLL (0x8u) /*!< 选取PLL做系统时钟源  */
/**
 * @}
 */

/**
 * @defgroup SYSCLK_RCH_CONFIG RCH相关配置参数定义
 * @{
 */
#define RCH_TRIM_24M_VALUE       *((uint32_t*)0x010011E4u) /*!< RCH = 24M 时的TRIM值       */

#define SYSCTRL_RCH_DIV_BIT_SIZE (0x04U)                                          /*!< 系统时钟选RCH的bit偏移地址 */
#define SYSCTRL_RCH_TRIM_24MHz   (RCH_TRIM_24M_VALUE << SYSCTRL_RCH_DIV_BIT_SIZE) /*!< 将RCH设置为24M             */

#define SYSCTRL_RCH_DIV1         (0x8U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/1              */
#define SYSCTRL_RCH_DIV2         (0x0U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/2              */
#define SYSCTRL_RCH_DIV4         (0x1U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/4              */
#define SYSCTRL_RCH_DIV6         (0x2U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/6              */
#define SYSCTRL_RCH_DIV8         (0x3U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/7              */
#define SYSCTRL_RCH_DIV10        (0x4U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/10             */
#define SYSCTRL_RCH_DIV12        (0x5U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/12             */
#define SYSCTRL_RCH_DIV14        (0x6U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/14             */
#define SYSCTRL_RCH_DIV16        (0x7U << SYSCTRL_RCH_DIV_Pos) /*!< RCH_D = RCH/16             */
/**
 * @}
 */

/** @defgroup SYSCLK_XTH_CONFIG XTH相关配置参数定义
 * @{
 */
#define SYSCTRL_XTH_DRV0       (0x0U << SYSCTRL_XTH_DRIVER_Pos) /*!< 外部晶振驱动能力配置为最弱驱动能力             */
#define SYSCTRL_XTH_DRV1       (0x1U << SYSCTRL_XTH_DRIVER_Pos) /*!< 外部晶振驱动能力配置为弱驱动能力               */
#define SYSCTRL_XTH_DRV2       (0x2U << SYSCTRL_XTH_DRIVER_Pos) /*!< 外部晶振驱动能力配置为默认驱动能力             */
#define SYSCTRL_XTH_DRV3       (0x3U << SYSCTRL_XTH_DRIVER_Pos) /*!< 外部晶振驱动能力配置为最强驱动能力             */

#define SYSCTRL_XTH_8t12MHz    (0x0U << SYSCTRL_XTH_RANGE_Pos) /*!< 外部晶振工作频率为8-12M                        */
#define SYSCTRL_XTH_8t16MHz    (0x1U << SYSCTRL_XTH_RANGE_Pos) /*!< 外部晶振工作频率为8-16M                        */
#define SYSCTRL_XTH_16t24MHz   (0x2U << SYSCTRL_XTH_RANGE_Pos) /*!< 外部晶振工作频率为16-24M                       */
#define SYSCTRL_XTH_20t32MHz   (0x3U << SYSCTRL_XTH_RANGE_Pos) /*!< 外部晶振工作频率为20-32M                       */

#define SYSCTRL_XTH_WAITCYCLE0 (0x0U << SYSCTRL_XTH_WAITCYCLE_Pos) /*!< 外部晶振工作稳定时间为8192个周期               */
#define SYSCTRL_XTH_WAITCYCLE1 (0x1U << SYSCTRL_XTH_WAITCYCLE_Pos) /*!< 外部晶振工作稳定时间为33768个周期              */
#define SYSCTRL_XTH_WAITCYCLE2 (0x2U << SYSCTRL_XTH_WAITCYCLE_Pos) /*!< 外部晶振工作稳定时间为131072个周期             */
#define SYSCTRL_XTH_WAITCYCLE3 (0x3U << SYSCTRL_XTH_WAITCYCLE_Pos) /*!< 外部晶振工作稳定时间为262144个周期             */

#define SYSCTRL_XTH_DETEN_OFF  (0x0U << SYSCTRL_XTH_DETEN_Pos) /*!< 关闭振失效检测与工作失效检测                   */
#define SYSCTRL_XTH_DETEN_ON   (0x1U << SYSCTRL_XTH_DETEN_Pos) /*!< 使能振失效检测与工作失效检测                   */

#define SYSCTRL_XTH_DETTIME_0  (0x0U << SYSCTRL_XTH_DETTIME_Pos) /*!< 每 2ms XTL计数小于32，则置位晶体失效标志Fault  */
#define SYSCTRL_XTH_DETTIME_1  (0x1U << SYSCTRL_XTH_DETTIME_Pos) /*!< 每 8ms XTL计数小于128，则置位晶体失效标志Fault */
/**
 * @}
 */

/** @defgroup SYSCLK_RCL_CONFIG RCL相关配置参数定义
 * @{
 */
#define RCL_TRIM_32K8_VALUE            *((uint32_t*)0x010011E8u)                               /*!< RCL = 32.8K 时的TRIM值  */
#define SYSCTRL_RCL_WAITCYCLE_BIT_SIZE (0x02u)                                                 /*!< 系统时钟选RCL的bit偏移地址  */
#define SYSCTRL_RCL_TRIM_32p8KHz       (RCL_TRIM_32K8_VALUE << SYSCTRL_RCL_WAITCYCLE_BIT_SIZE) /*!< 将RCL设置为32.8KHZ  */

#define SYSCTRL_RCL_WAITCYCLE4         (0x0u << SYSCTRL_RCL_WAITCYCLE_Pos) /*!< 内部低速时钟 RCL 稳定时间选择为4个周期 */
#define SYSCTRL_RCL_WAITCYCLE16        (0x1u << SYSCTRL_RCL_WAITCYCLE_Pos) /*!< 内部低速时钟 RCL 稳定时间选择为16个周期   */
#define SYSCTRL_RCL_WAITCYCLE64        (0x2u << SYSCTRL_RCL_WAITCYCLE_Pos) /*!< 内部低速时钟 RCL 稳定时间选择为64个周期   */
#define SYSCTRL_RCL_WAITCYCLE256       (0x3u << SYSCTRL_RCL_WAITCYCLE_Pos) /*!< 内部低速时钟 RCL 稳定时间选择为256个周期  */
/**
 * @}
 */

/** @defgroup SYSCLK_PLL_CONFIG PLL相关配置参数定义
 * @{
 */
#define SYSCTRL_PLL_SRC_RCH             (0x0u << SYSCTRL_PLL_SRC_Pos) /*!< PLL选择RCH作为时钟源                   */
#define SYSCTRL_PLL_SRC_XTH             (0x1u << SYSCTRL_PLL_SRC_Pos) /*!< PLL选择XTH作为时钟源                   */
#define SYSCTRL_PLL_SRC_XTHI            (0x2u << SYSCTRL_PLL_SRC_Pos) /*!< PLL选择RCL作为时钟源                   */

#define SYSCTRL_PLL_DIVN_CONFIG(x)      (((x) < (1) ? (1) : ((x) > (63) ? (63) : (x))) << SYSCTRL_PLL_DIVN_Pos) /*!< PLL时钟整数分频                        */
#define SYSCTRL_PLL_MULM_CONFIG(x)      (((x) < (2) ? (2) : ((x) > (63) ? (63) : (x))) << SYSCTRL_PLL_MULM_Pos) /*!< PLL时钟整数倍频                        */
#define SYSCTRL_PLL_OD_CONFIG(x)        ((x) << SYSCTRL_PLL_OD_Pos)                                             /*!< PLL时钟输出分频                        */
#define SYSCTRL_PLL_WAITCYCLE_CONFIG(x) ((x) << SYSCTRL_PLL_WAITCYCLE_Pos)                                      /*!< PLL时钟稳定时间选择                    */

#define SYSCTRL_PLL_OEN_ON              (0x1u << SYSCTRL_PLL_OEN_Pos) /*!< PLL时钟输出使能                        */
#define SYSCTRL_PLL_OEN_OFF             (0x0u << SYSCTRL_PLL_OEN_Pos) /*!< PLL时钟输出关闭                        */

#define SYSCTRL_PLL_BYPASS_ON           (0x1u << SYSCTRL_PLL_BYPASS_Pos) /*!< PLL输出时钟 = FIN/DIVN                 */
#define SYSCTRL_PLL_BYPASS_OFF          (0x0u << SYSCTRL_PLL_BYPASS_Pos) /*!< PLL输出时钟 = (FIN * MULM)/(DIVN * OD) */

#define SYSCTRL_PLL_LKEN_ON             (0x1u << SYSCTRL_PLL_LKEN_Pos) /*!< 将LOCK 设置为 1                        */
#define SYSCTRL_PLL_LKEN_OFF            (0x0u << SYSCTRL_PLL_LKEN_Pos) /*!< 无作用                                 */
/**
 * @}
 */

/** @defgroup SYSCTRL_MASK 系统功能掩码位定义
 * @{
 */
#define _SYSCTRL_FUNC_MSK   (0x20u) /*!< 系统功能掩码   */
#define _PERICLK_REG1_MSK   (0x20u) /*!< 外设使能掩码1  */
#define _PERICLK_REG2_MSK   (0x40u) /*!< 外设使能掩码2  */
#define _PERICLK_REG3_MSK   (0x80u) /*!< 外设使能掩码3  */

#define _PERIRESET_REG1_MSK (0x20u) /*!< 外设复位掩码1  */
#define _PERIRESET_REG2_MSK (0x40u) /*!< 外设复位掩码2  */
#define _PERIRESET_REG3_MSK (0x60u) /*!< 外设复位掩码3  */
/**
 * @}
 */

/** @defgroup SYSCTRL_PRI_RESET 系统外设复位定义
 * @{
 */
#define SYSCTRL_PERIRESET_USART0 SysctrlPeripheralUsart0 /*!< 复位USART0  */
#define SYSCTRL_PERIRESET_USART1 SysctrlPeripheralUsart1 /*!< 复位USART1  */
#define SYSCTRL_PERIRESET_USART2 SysctrlPeripheralUsart2 /*!< 复位USART2  */
#define SYSCTRL_PERIRESET_USART3 SysctrlPeripheralUsart3 /*!< 复位USART3  */
#define SYSCTRL_PERIRESET_I2C0   SysctrlPeripheralI2c0   /*!< 复位I2C0    */
#define SYSCTRL_PERIRESET_I2C1   SysctrlPeripheralI2c1   /*!< 复位I2C1    */
#define SYSCTRL_PERIRESET_SPI0   SysctrlPeripheralSpi0   /*!< 复位SPI0    */
#define SYSCTRL_PERIRESET_SPI1   SysctrlPeripheralSpi1   /*!< 复位SPI1    */
#define SYSCTRL_PERIRESET_CTIM0  SysctrlPeripheralCTim0  /*!< 复位CTIM0   */
#define SYSCTRL_PERIRESET_CTIM1  SysctrlPeripheralCTim1  /*!< 复位CTIM1   */
#define SYSCTRL_PERIRESET_CTIM2  SysctrlPeripheralCTim2  /*!< 复位CTIM2   */
#define SYSCTRL_PERIRESET_ATIM0  SysctrlPeripheralATim0  /*!< 复位ATIM0   */
#define SYSCTRL_PERIRESET_ATIM3  SysctrlPeripheralATim3  /*!< 复位ATIM3   */
#define SYSCTRL_PERIRESET_CTRIM  SysctrlPeripheralCtrim  /*!< 复位CTRIM   */
#define SYSCTRL_PERIRESET_WWDT   SysctrlPeripheralWwt    /*!< 复位WWDT    */
#define SYSCTRL_PERIRESET_IWDT   SysctrlPeripheralIwt    /*!< 复位IWDT    */
#define SYSCTRL_PERIRESET_ADC0   SysctrlPeripheralAdc0   /*!< 复位ADC0    */
#define SYSCTRL_PERIRESET_ADC1   SysctrlPeripheralAdc1   /*!< 复位ADC1    */
#define SYSCTRL_PERIRESET_VC     SysctrlPeripheralVc     /*!< 复位VC      */
#define SYSCTRL_PERIRESET_LVD    SysctrlPeripherallvd    /*!< 复位LVD     */
#define SYSCTRL_PERIRESET_DMA    SysctrlPeripheralDma    /*!< 复位DMAC    */
#define SYSCTRL_PERIRESET_CRC    SysctrlPeripheralCrc    /*!< 复位CRC     */
#define SYSCTRL_PERIRESET_FLASH  SysctrlPeripheralFlash  /*!< 复位FLASH   */
#define SYSCTRL_PERIRESET_GPIOA  SysctrlPeripheralGpioa  /*!< 复位GPIOA   */
#define SYSCTRL_PERIRESET_GPIOB  SysctrlPeripheralGpiob  /*!< 复位GPIOB   */
#define SYSCTRL_PERIRESET_GPIOC  SysctrlPeripheralGpioc  /*!< 复位GPIOC   */
#define SYSCTRL_PERIRESET_GPIOD  SysctrlPeripheralGpiod  /*!< 复位GPIOD   */
/**
 * @}
 */

/** @defgroup Sysctrl_Debug_Module 系统外设DEBUG下工作定义
 * @{
 */
#define SYSCTRL_DEBUG_STOP_ATIM0 SYSCTRL_DEBUG_ATIM0 /*!< 调试时， ATIM0 计数功能暂停  */
#define SYSCTRL_DEBUG_STOP_ATIM3 SYSCTRL_DEBUG_ATIM3 /*!< 调试时， ATIM3 计数功能暂停  */
#define SYSCTRL_DEBUG_STOP_CTIM0 SYSCTRL_DEBUG_CTIM0 /*!< 调试时， CTIM0 计数功能暂停  */
#define SYSCTRL_DEBUG_STOP_CTIM1 SYSCTRL_DEBUG_CTIM1 /*!< 调试时， CTIM1 计数功能暂停  */
#define SYSCTRL_DEBUG_STOP_CTIM2 SYSCTRL_DEBUG_CTIM2 /*!< 调试时， CTIM2 计数功能暂停  */
#define SYSCTRL_DEBUG_STOP_CTRIM SYSCTRL_DEBUG_CTRIM /*!< 调试时， CTRIM 计数功能暂停  */
#define SYSCTRL_DEBUG_STOP_IWDT  SYSCTRL_DEBUG_IWDT  /*!< 调试时， IWDT 计数功能暂停   */
#define SYSCTRL_DEBUG_STOP_WWDT  SYSCTRL_DEBUG_WWDT  /*!< 调试时， WWDT 计数功能暂停   */
/**
 * @}
 */

/** @defgroup Sysctrl_Reset_Flag 系统复位标志定义
 * @{
 */
#define SYSCTRL_RESET_FLAG_VCC     SYSCTRL_RESETFLAG_VCC    /*!< vcc电源域复位标志置1            */
#define SYSCTRL_RESET_FLAG_VCORE   SYSCTRL_RESETFLAG_VCORE  /*!< Vcore域复位标志置1              */
#define SYSCTRL_RESET_FLAG_LVD     SYSCTRL_RESETFLAG_LVD    /*!< lvd 复位标志置1                 */
#define SYSCTRL_RESET_FLAG_IWDT    SYSCTRL_RESETFLAG_IWDT   /*!< IWDT 复位标志置1                */
#define SYSCTRL_RESET_FLAG_WWDT    SYSCTRL_RESETFLAG_WWDT   /*!< WWDT 复位标志置1                */
#define SYSCTRL_RESET_FLAG_LOCKUP  SYSCTRL_RESETFLAG_LOCKUP /*!< cotrex-M4 cpu lockup 复位标志置1*/
#define SYSCTRL_RESET_FLAG_SYSREQ  SYSCTRL_RESETFLAG_SYSREQ /*!< cotrex-M4 cpu 软件复位标志置1   */
#define SYSCTRL_RESET_FLAG_RSTB    SYSCTRL_RESETFLAG_RSTB   /*!< resetb 端口复位标志置1          */
#define SYSCTRL_RESET_FLAG_SOFTPOR SYSCTRL_RSTFLAG_SOFTPOR  /*!< 通过寄存器复位芯片标志置1       */
#define SYSCTRL_RESET_FLAG_ALL     (0xFFu)                  /*!< 所有复位标志均置1               */
/**
 * @}
 */

/** @defgroup Sysclk_Init_Type 系统时钟初始化定义
 * @{
 */
#define SYSCTRL_CLOCKTYPE_SYSCLK (0x00000001u) /*!< SYSCLK to configure */
#define SYSCTRL_CLOCKTYPE_HCLK   (0x00000002u) /*!< HCLK to configure */
#define SYSCTRL_CLOCKTYPE_PCLK0  (0x00000004u) /*!< PCLK0 to configure */
#define SYSCTRL_CLOCKTYPE_PCLK1  (0x00000008u) /*!< PCLK1 to configure */
/**
 * @}
 */

/** @defgroup Sysclk_Src_Type 系统时钟源定义
 * @{
 */
#define SYSCTRL_SYSCLK_SOURCE_RCH (0x0u) /*!< 系统时钟源选择为RCH */
#define SYSCTRL_SYSCLK_SOURCE_XTH (0x1u) /*!< 系统时钟源选择为XTH */
#define SYSCTRL_SYSCLK_SOURCE_RCL (0x2u) /*!< 系统时钟源选择为RCL */
#define SYSCTRL_SYSCLK_SOURCE_PLL (0x4u) /*!< 系统时钟源选择为PLL */
/**
 * @}
 */

/** @defgroup System_HCLK_Prs 系统时钟 HCLK 分频系数定义
 * @{
 */
#define SYSCTRL_SYSCLK_HCLK_PRS1   (0x0u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 1   */
#define SYSCTRL_SYSCLK_HCLK_PRS2   (0x1u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 2   */
#define SYSCTRL_SYSCLK_HCLK_PRS4   (0x2u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 4   */
#define SYSCTRL_SYSCLK_HCLK_PRS8   (0x3u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 8   */
#define SYSCTRL_SYSCLK_HCLK_PRS16  (0x4u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 16  */
#define SYSCTRL_SYSCLK_HCLK_PRS32  (0x5u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 32  */
#define SYSCTRL_SYSCLK_HCLK_PRS64  (0x6u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 64  */
#define SYSCTRL_SYSCLK_HCLK_PRS128 (0x7u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 128 */
#define SYSCTRL_SYSCLK_HCLK_PRS256 (0x8u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 256 */
#define SYSCTRL_SYSCLK_HCLK_PRS512 (0x9u << SYSCTRL_CR0_HCLKPRS_Pos) /*!< HCLK = 系统时钟 / 512 */
/**
 * @}
 */

/** @defgroup System_PCLK0_Prs 系统时钟 PCLK0分频系数定义
 * @{
 */
#define SYSCTRL_SYSCLK_PCLK0_PRS1 (0x0u << SYSCTRL_CR0_PCLK0PRS_Pos) /*!< PCLK0 = 系统时钟 / 1 */
#define SYSCTRL_SYSCLK_PCLK0_PRS2 (0x1u << SYSCTRL_CR0_PCLK0PRS_Pos) /*!< PCLK0 = 系统时钟 / 2 */
#define SYSCTRL_SYSCLK_PCLK0_PRS4 (0x2u << SYSCTRL_CR0_PCLK0PRS_Pos) /*!< PCLK0 = 系统时钟 / 4 */
#define SYSCTRL_SYSCLK_PCLK0_PRS8 (0x3u << SYSCTRL_CR0_PCLK0PRS_Pos) /*!< PCLK0 = 系统时钟 / 8 */
/**
 * @}
 */

/** @defgroup System_PCLK1_Prs  系统时钟 PCLK1分频系数定义
 * @{
 */
#define SYSCTRL_SYSCLK_PCLK1_PRS1 (0x0u << SYSCTRL_CR0_PCLK1PRS_Pos) /*!< PCLK1 = 系统时钟 / 1 */
#define SYSCTRL_SYSCLK_PCLK1_PRS2 (0x1u << SYSCTRL_CR0_PCLK1PRS_Pos) /*!< PCLK1 = 系统时钟 / 2 */
#define SYSCTRL_SYSCLK_PCLK1_PRS4 (0x2u << SYSCTRL_CR0_PCLK1PRS_Pos) /*!< PCLK1 = 系统时钟 / 4 */
#define SYSCTRL_SYSCLK_PCLK1_PRS8 (0x3u << SYSCTRL_CR0_PCLK1PRS_Pos) /*!< PCLK1 = 系统时钟 / 8 */
/**
 * @}
 */

/** @defgroup Flash_Wait_Cycle FLASH指令读取等待周期定义
 * @{
 */
#define SYSCTRL_FLASH_WAIT_CYCLE1 (0x0u << FLASH_WAIT_WAIT_Pos) /*!< FLASH_WAIT = 1 */
#define SYSCTRL_FLASH_WAIT_CYCLE2 (0x1u << FLASH_WAIT_WAIT_Pos) /*!< FLASH_WAIT = 2 */
#define SYSCTRL_FLASH_WAIT_CYCLE3 (0x2u << FLASH_WAIT_WAIT_Pos) /*!< FLASH_WAIT = 3 */
#define SYSCTRL_FLASH_WAIT_CYCLE4 (0x3u << FLASH_WAIT_WAIT_Pos) /*!< FLASH_WAIT = 4 */
/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 * Global function prototypes (definition in C source)
 ******************************************************************************/
/**
 * @addtogroup SYSCTRL_Global_Functions SYSCTRL全局函数定义
 * @{
 */

uint32_t    SystemClockUpdate(void);
en_result_t SYSCTRL_SysClkSrcInit(stc_sysctrl_sysclk_source_init_t* pstcSysClkSrc);
en_result_t SYSCTRL_SysClkInit(stc_sysctrl_clk_init_t* pstcSysClk);
uint32_t    Sysctrl_GetHClk(void);
uint32_t    SYSCTRL_GetPCLK0(void);
uint32_t    SYSCTRL_GetPCLK1(void);
en_result_t SYSCTRL_Func_Ctrl(en_sysctrl_func_t enFunc, boolean_t bFlag);
en_result_t SYSCTRL_PeriphClkEnable(en_sysctrl_peripheral_gate_t enPeripheral);
en_result_t SYSCTRL_PeriphClkDisable(en_sysctrl_peripheral_gate_t enPeripheral);
en_result_t SYSCTRL_PeriphReset(uint32_t u32PeriphReset);
void        SYSCTRL_ResetFlagClear(uint32_t u32ResetFlag);
uint32_t    SYSCTRL_ResetFlagGet(uint32_t u32ResetFlag);
void        SYSCTRL_DebugEnable(uint32_t u32DebugModule);
void        SYSCTRL_DebugDisable(uint32_t u32DebugModule);
void        SYSCTRL_GetChipInfo(stc_sysctrl_chip_info_t* pstcChipInfo);
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */
#ifdef __cplusplus
}
#endif

#endif /* __SYSCTRL_H__ */
/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
