/**
 *******************************************************************************
 * @file  atim0.h
 * @brief This file contains all the functions prototypes of the ATIMER0 driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */
#ifndef __TIMER0_H__
#define __TIMER0_H__

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_ATIM0 ATIM0子模块驱动库
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode0_Global_Types ATIM0 Mode0全局类型定义
 * @{
 */

/**
 * @brief ATIM0 mode0 配置结构体定义(模式0)
 */
typedef struct
{
    uint32_t u32WorkMode;    /*!< 工作模式设置      @ref ATim0_Mode0_Work_Mode   */
    uint32_t u32GatePolar;   /*!< 门控极性控制      @ref ATim0_Mode0_Gate_Polar  */
    uint32_t u32EnGate;      /*!< 门控使能          @ref ATim0_Mode0_Gate_Enable */
    uint32_t u32PRS;         /*!< 预除频配置        @ref ATim0_Mode0_PRS         */
    uint32_t u32EnTog;       /*!< 翻转输出使能      @ref ATim0_Mode0_Tog_ON_OFF  */
    uint32_t u32CountClkSel; /*!< 定时/计数功能选择 @ref ATim0_Mode0_Count_Clock */
    uint32_t u32CntMode;     /*!< 计数模式配置      @ref ATim0_Mode0_Count_Mode  */
} stc_atim0_mode0_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode0_Global_Macros ATIM0_Mode0全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode0_Work_Mode 工作模式
 * @{
 */
#define ATIM0_M0_M0CR_WORK_MODE_TIMER      (0x00000000u)                    /*!< 定时器模式(模式0) */
#define ATIM0_M0_M0CR_WORK_MODE_PWC        (1u << ATIM0MODE0_M0CR_MODE_Pos) /*!< PWC模式(模式1)    */
#define ATIM0_M0_M0CR_WORK_MODE_SAWTOOTH   (2u << ATIM0MODE0_M0CR_MODE_Pos) /*!< 锯齿波模式(模式2) */
#define ATIM0_M0_M0CR_WORK_MODE_TRIANGULAR (ATIM0MODE0_M0CR_MODE)           /*!< 三角波模式(模式3) */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode0_Gate_Polar 门控极性控制
 * @{
 */
#define ATIM0_M0_M0CR_GATE_POLAR_HIGH (0x00000000u)           /*!< 端口门控高电平有效 */
#define ATIM0_M0_M0CR_GATE_POLAR_LOW  (ATIM0MODE0_M0CR_GATEP) /*!< 端口门控低电平有效 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode0_Gate_Enable 门控使能
 * @{
 */
#define ATIM0_M0_M0CR_GATE_OFF (0x00000000u)          /*!< 定时器门控禁止 */
#define ATIM0_M0_M0CR_GATE_ON  (ATIM0MODE0_M0CR_GATE) /*!< 定时器门控使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode0_PRS 预除频配置
 * @{
 */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS1   (0x00000000u)                   /*!< PCLK     */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS2   (1u << ATIM0MODE0_M0CR_PRS_Pos) /*!< PCLK/2   */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS4   (2u << ATIM0MODE0_M0CR_PRS_Pos) /*!< PCLK/4   */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS8   (3u << ATIM0MODE0_M0CR_PRS_Pos) /*!< PCLK/8   */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS16  (4u << ATIM0MODE0_M0CR_PRS_Pos) /*!< PCLK/16  */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS32  (5u << ATIM0MODE0_M0CR_PRS_Pos) /*!< PCLK/32  */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS64  (6u << ATIM0MODE0_M0CR_PRS_Pos) /*!< PCLK/64  */
#define ATIM0_M0_M0CR_ATIM0CLK_PRS256 (ATIM0MODE0_M0CR_PRS)           /*!< PCLK/256 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode0_Tog_ON_OFF 翻转输出使能
 * @{
 */
#define ATIM0_M0_M0CR_TOG_OFF (0x00000000u)         /*!< 翻转输出禁止 */
#define ATIM0_M0_M0CR_TOG_ON  (ATIM0MODE0_M0CR_TOG) /*!< 翻转输出使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode0_Count_Clock 定时/计数功能选择
 * @{
 */
#define ATIM0_M0_M0CR_CT_PCLK (0x00000000u)        /*!< 内部计数时钟PCLK    */
#define ATIM0_M0_M0CR_CT_ETR  (ATIM0MODE0_M0CR_CT) /*!< 外部输入计数时钟ETR */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode0_Count_Mode 计数模式配置
 * @{
 */
#define ATIM0_M0_M0CR_MD_32BIT_FREE (0x00000000u)        /*!< 32位自由计数 */
#define ATIM0_M0_M0CR_MD_16BIT_ARR  (ATIM0MODE0_M0CR_MD) /*!< 16位重载计数 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode1_Global_Types ATIM0 Mode1全局类型定义
 * @{
 */

/**
 * @brief ATIM0 mode1 配置结构体定义(模式1)
 */
typedef struct
{
    uint32_t u32WorkMode;    /*!< 工作模式设置          @ref ATim0_Mode1_Work_Mode   */
    uint32_t u32PRS;         /*!< 预除频配置            @ref ATim0_Mode1_PRS         */
    uint32_t u32CountClkSel; /*!< 定时/计数功能选择     @ref ATim0_Mode1_Count_Clock */
    uint32_t u32ShotMode;    /*!< 单次测量/循环测量选择 @ref ATim0_Mode1_Shot_Mode   */
} stc_atim0_mode1_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode1_Global_Macros ATIM0_Mode1全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode1_Work_Mode 工作模式
 * @{
 */
#define ATIM0_M1_M1CR_WORK_MODE_TIMER      (0x00000000u)                    /*!< 定时器模式(模式0) */
#define ATIM0_M1_M1CR_WORK_MODE_PWC        (1u << ATIM0MODE1_M1CR_MODE_Pos) /*!< PWC模式(模式1)    */
#define ATIM0_M1_M1CR_WORK_MODE_SAWTOOTH   (2u << ATIM0MODE1_M1CR_MODE_Pos) /*!< 锯齿波模式(模式2) */
#define ATIM0_M1_M1CR_WORK_MODE_TRIANGULAR (ATIM0MODE1_M1CR_MODE)           /*!< 三角波模式(模式3) */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode1_PRS 预除频配置
 * @{
 */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS1   (0x00000000u)                   /*!< PCLK     */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS2   (1u << ATIM0MODE1_M1CR_PRS_Pos) /*!< PCLK/2   */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS4   (2u << ATIM0MODE1_M1CR_PRS_Pos) /*!< PCLK/4   */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS8   (3u << ATIM0MODE1_M1CR_PRS_Pos) /*!< PCLK/8   */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS16  (4u << ATIM0MODE1_M1CR_PRS_Pos) /*!< PCLK/16  */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS32  (5u << ATIM0MODE1_M1CR_PRS_Pos) /*!< PCLK/32  */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS64  (6u << ATIM0MODE1_M1CR_PRS_Pos) /*!< PCLK/64  */
#define ATIM0_M1_M1CR_ATIM0CLK_PRS256 (ATIM0MODE1_M1CR_PRS)           /*!< PCLK/256 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode1_Count_Clock 定时/计数功能选择
 * @{
 */
#define ATIM0_M1_M1CR_CT_PCLK (0x00000000u)        /*!< 内部计数时钟PCLK    */
#define ATIM0_M1_M1CR_CT_ETR  (ATIM0MODE1_M1CR_CT) /*!< 外部输入计数时钟ETR */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode1_Shot_Mode 单次测量/循环测量选择
 * @{
 */
#define ATIM0_M1_M1CR_SHOT_CYCLE (0x00000000u)             /*!< 循环测量 */
#define ATIM0_M1_M1CR_SHOT_ONE   (ATIM0MODE1_M1CR_ONESHOT) /*!< 单次测量 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode1_PWC_Start_End_Edge PWC启动停止边沿选择
 * @{
 */
#define ATIM0_M1_M1CR_DETECT_EDGE_RISE_TO_RISE (0x00000000u)                                     /*!< 上沿-->上沿 (周期)   */
#define ATIM0_M1_M1CR_DETECT_EDGE_FALL_TO_RISE (ATIM0MODE1_M1CR_EDG1ST)                          /*!< 下沿-->上沿 (低电平) */
#define ATIM0_M1_M1CR_DETECT_EDGE_RISE_TO_FALL (ATIM0MODE1_M1CR_EDG2ND)                          /*!< 上沿-->下沿 (高电平) */
#define ATIM0_M1_M1CR_DETECT_EDGE_FALL_TO_FALL (ATIM0MODE1_M1CR_EDG2ND | ATIM0MODE1_M1CR_EDG1ST) /*!< 下沿-->下沿 (周期)   */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0PWC_Global_Types ATIM0 PWC全局类型定义
 * @{
 */

/**
 * @brief PWC输入配置结构体定义(模式1)
 */
typedef struct
{
    uint32_t u32TsSel;  /*!< 触发输入源选择 @ref ATim0_PWC_Trigger_Source */
    uint32_t u32IA0Sel; /*!< CHA0输入选择   @ref ATim0_PWC_IA0S_Input     */
    uint32_t u32IB0Sel; /*!< CHB0输入选择   @ref ATim0_PWC_IB0S_Input     */
    uint32_t u32ETR;    /*!< ETR相位选择    @ref ATim0_PWC_ET_Polarity    */
    uint32_t u32FltETR; /*!< ETR滤波设置    @ref ATim0_PWC_Input_Filter   */
    uint32_t u32FltIA0; /*!< CHA0滤波设置   @ref ATim0_PWC_Input_Filter   */
    uint32_t u32FltIB0; /*!< CHB0滤波设置   @ref ATim0_PWC_Input_Filter   */
} stc_atim0_pwc_input_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_PWC_Global_Macros ATIM0_PWC全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_PWC_Trigger_Source MSCR_TS触发输入源选择
 * @{
 */
#define ATIM0_M1_MSCR_TS_ETR         (0x00000000u)                  /*!< 端口ETR的滤波相位选择后的信号ETFP  */
#define ATIM0_M1_MSCR_TS_ITR0        (1u << ATIM0MODE1_MSCR_TS_Pos) /*!< 内部互联信号 ITR0                  */
#define ATIM0_M1_MSCR_TS_ITR1        (2u << ATIM0MODE1_MSCR_TS_Pos) /*!< 内部互联信号 ITR1                  */
#define ATIM0_M1_MSCR_TS_ITR2        (3u << ATIM0MODE1_MSCR_TS_Pos) /*!< 内部互联信号 ITR2                  */
#define ATIM0_M1_MSCR_TS_ITR3        (4u << ATIM0MODE1_MSCR_TS_Pos) /*!< 内部互联信号 ITR3                  */
#define ATIM0_M1_MSCR_TS_CH0A_EDGE   (5u << ATIM0MODE1_MSCR_TS_Pos) /*!< 端口CH0A的边沿信号                 */
#define ATIM0_M1_MSCR_TS_CH0A_FILTER (6u << ATIM0MODE1_MSCR_TS_Pos) /*!< 端口CH0A的滤波相位选择后的信号IAFP */
#define ATIM0_M1_MSCR_TS_CH0B_FILTER (ATIM0MODE1_MSCR_TS)           /*!< 端口CH0B的滤波相位选择后的信号IBFP */
/**
 * @}
 */

/**
 * @defgroup ATim0_PWC_IA0S_Input MSCR_IA0S CHA0输入选择
 * @{
 */
#define ATIM0_M1_MSCR_IA0S_CH0A       (0x00000000u)          /*!< CH0A               */
#define ATIM0_M1_MSCR_IA0S_CH012A_XOR (ATIM0MODE1_MSCR_IA0S) /*!< CH0A CH1A CH2A XOR */
/**
 * @}
 */

/**
 * @defgroup ATim0_PWC_IB0S_Input MSCR_IB0S CHB0输入选择
 * @{
 */
#define ATIM0_M1_MSCR_IB0S_CH0B   (0x00000000u)          /*!< CH0B               */
#define ATIM0_M1_MSCR_IB0S_TS_SEL (ATIM0MODE1_MSCR_IB0S) /*!< 内部触发TS选择信号 */
/**
 * @}
 */

/**
 * @defgroup ATim0_PWC_Input_Filter FLTR_FLTA0 CHA/CHB/ETR input filter config
 * @{
 */
#define ATIM0_M1_FLTR_FLTA0_B0_ET_NONE        (0x00000000u)                     /*!< 无滤波               */
#define ATIM0_M1_FLTR_FLTA0_B0_ET_3_PCLK      (4u << ATIM0MODE1_FLTR_FLTA0_Pos) /*!< PCLK, 3个连续有效    */
#define ATIM0_M1_FLTR_FLTA0_B0_ET_3_PCLKDIV4  (5u << ATIM0MODE1_FLTR_FLTA0_Pos) /*!< PCLK/4, 3个连续有效  */
#define ATIM0_M1_FLTR_FLTA0_B0_ET_3_PCLKDIV16 (6u << ATIM0MODE1_FLTR_FLTA0_Pos) /*!< PCLK/16, 3个连续有效 */
#define ATIM0_M1_FLTR_FLTA0_B0_ET_3_PCLKDIV64 (ATIM0MODE1_FLTR_FLTA0)           /*!< PCLK/64, 3个连续有效 */
/**
 * @}
 */

/**
 * @defgroup ATim0_PWC_ET_Polarity FLTR_ETP ET Polarity Config
 * @{
 */
#define ATIM0_M1_FLTR_ETP_POLARITY_POSITIVE (0x00000000u)         /*!< 同相位   */
#define ATIM0_M1_FLTR_ETP_POLARITY_NEGATIVE (ATIM0MODE1_FLTR_ETP) /*!< 反相输入 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 mode23 配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32WorkMode;    /*!< 工作模式设置             @ref ATim0_Mode23_Work_Mode           */
    uint32_t u32CntDir;      /*!< 计数方向                 @ref ATim0_Mode23_DIR                 */
    uint32_t u32PRS;         /*!< 时钟预除频配置           @ref ATim0_Mode23_PRS                 */
    uint32_t u32CountClkSel; /*!< 定时/计数功能选择        @ref ATim0_Mode23_Count_Clock         */
    uint32_t u32PWMTypeSel;  /*!< PWM模式选择（独立/互补） @ref ATim0_Mode23_PWM_Type            */
    uint32_t u32PWM2sSel;    /*!< OCREFA双点比较功能选择   @ref ATim0_Mode23_OCREFA_Compare_Type */
    uint32_t u32ShotMode;    /*!< 单次触发模式使能/禁止    @ref ATim0_Mode23_Shot_Mode           */
    uint32_t u32URSSel;      /*!< 更新源选择               @ref ATim0_Mode23_Refresh_Source      */
} stc_atim0_mode23_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_Work_Mode 工作模式
 * @{
 */
#define ATIM0_M23_M23CR_WORK_MODE_TIMER      (0x00000000u)                      /*!< 定时器模式(模式0) */
#define ATIM0_M23_M23CR_WORK_MODE_PWC        (1u << ATIM0MODE23_M23CR_MODE_Pos) /*!< PWC模式(模式1)    */
#define ATIM0_M23_M23CR_WORK_MODE_SAWTOOTH   (2u << ATIM0MODE23_M23CR_MODE_Pos) /*!< 锯齿波模式(模式2) */
#define ATIM0_M23_M23CR_WORK_MODE_TRIANGULAR (ATIM0MODE23_M23CR_MODE)           /*!< 三角波模式(模式3) */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_PRS 预除频配置
 * @{
 */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS1   (0x00000000u)                     /*!< PCLK     */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS2   (1u << ATIM0MODE23_M23CR_PRS_Pos) /*!< PCLK/2   */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS4   (2u << ATIM0MODE23_M23CR_PRS_Pos) /*!< PCLK/4   */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS8   (3u << ATIM0MODE23_M23CR_PRS_Pos) /*!< PCLK/8   */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS16  (4u << ATIM0MODE23_M23CR_PRS_Pos) /*!< PCLK/16  */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS32  (5u << ATIM0MODE23_M23CR_PRS_Pos) /*!< PCLK/32  */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS64  (6u << ATIM0MODE23_M23CR_PRS_Pos) /*!< PCLK/64  */
#define ATIM0_M23_M23CR_ATIM0CLK_PRS256 (ATIM0MODE23_M23CR_PRS)           /*!< PCLK/256 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_DIR 计数方向
 * @{
 */
#define ATIM0_M23_M23CR_DIR_UP_CNT   (0x00000000u)           /*!< 向上计数 */
#define ATIM0_M23_M23CR_DIR_DOWN_CNT (ATIM0MODE23_M23CR_DIR) /*!< 向下计数 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Count_Clock 定时/计数功能选择
 * @{
 */
#define ATIM0_M23_M23CR_CT_PCLK (0x00000000u)          /*!< 内部计数时钟PCLK    */
#define ATIM0_M23_M23CR_CT_ETR  (ATIM0MODE23_M23CR_CT) /*!< 外部输入计数时钟ETR */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_PWM_Type PWM模式选择（独立/互补）
 * @{
 */
#define ATIM0_M23_M23CR_COMP_PWM_INDEPT (0x00000000u)            /*!< 独立PWM */
#define ATIM0_M23_M23CR_COMP_PWM_COMP   (ATIM0MODE23_M23CR_COMP) /*!< 互补PWM */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_OCREFA_Compare_Type OCREFA双点比较功能选择
 * @{
 */
#define ATIM0_M23_M23CR_PWM2S_COMPARE_DOUBLE_POINT (0x00000000u)             /*!< 双点比较 */
#define ATIM0_M23_M23CR_PWM2S_COMPARE_SINGLE_POINT (ATIM0MODE23_M23CR_PWM2S) /*!< 单点比较 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Shot_Mode 单次触发模式使能/禁止
 * @{
 */
#define ATIM0_M23_M23CR_SHOT_CYCLE (0x00000000u)               /*!< 循环计数                       */
#define ATIM0_M23_M23CR_SHOT_ONE   (ATIM0MODE23_M23CR_ONESHOT) /*!< 单次，发送事件更新后定时器停止 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Refresh_Source 更新源选择
 * @{
 */
#define ATIM0_M23_M23CR_URS_OV_UND_UG_RST (0x00000000u)           /*!< 上溢出/下溢出/软件更新UG/从模式复位 */
#define ATIM0_M23_M23CR_URS_OV_UND        (ATIM0MODE23_M23CR_URS) /*!< 上溢出/下溢出                       */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_CCRxx_Channel CCRxx channel number define
 * @{
 */
#define ATIM0_COMPARE_CAPTURE_CH0A 0 /*!< ATIM0_CCR0A相对于ATIM0_CCR0A的偏移 */
#define ATIM0_COMPARE_CAPTURE_CH0B 1 /*!< ATIM0_CCR0B相对于ATIM0_CCR0A的偏移 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 GATE在PWM互补模式下捕获或比较功能 配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32GateFuncSel; /*!< Gate比较、捕获功能选择               @ref ATim0_Mode23_Gate_Func            */
    uint32_t u32GateRiseCap; /*!< GATE作为捕获功能时，上沿捕获有效控制 @ref ATim0_Mode23_Gate_Func_Rising_EN  */
    uint32_t u32GateFallCap; /*!< GATE作为捕获功能时，下沿捕获有效控制 @ref ATim0_Mode23_Gate_Func_Falling_EN */
} stc_atim0_m23_gate_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_Gate_Func Gate比较、捕获功能选择
 * @{
 */
#define ATIM0_M23_M23CR_GATE_FUN_COMPARE (0x00000000u)           /*!< 比较模式 */
#define ATIM0_M23_M23CR_GATE_FUN_CAPTURE (ATIM0MODE23_M23CR_CSG) /*!< 捕获模式 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Gate_Func_Rising_EN GATE作为捕获功能时，上沿捕获有效控制
 * @{
 */
#define ATIM0_M23_M23CR_GATE_CAP_RISE_DISABLE (0x00000000u)           /*!< 上沿捕获无效 */
#define ATIM0_M23_M23CR_GATE_CAP_RISE_ENABLE  (ATIM0MODE23_M23CR_CRG) /*!< 上沿捕获有效 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Gate_Func_Falling_EN GATE作为捕获功能时，下沿捕获有效控制
 * @{
 */
#define ATIM0_M23_M23CR_GATE_CAP_FALL_DISABLE (0x00000000u)           /*!< 下沿捕获无效 */
#define ATIM0_M23_M23CR_GATE_CAP_FALL_ENABLE  (ATIM0MODE23_M23CR_CFG) /*!< 下沿捕获有效 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 主从触发 配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32MasterSlaveSel; /*!< 主从模式选择     @ref ATim0_Mode23_Master_Slaver  */
    uint32_t u32MasterSrc;      /*!< 主模式触发源选择 @ref ATim0_Mode23_Master_Source  */
    uint32_t u32SlaveModeSel;   /*!< 从模式选择       @ref ATim0_Mode23_Slaver_Func    */
    uint32_t u32TsSel;          /*!< 触发输入源选择   @ref ATim0_Mode23_Trigger_Source */
} stc_atim0_m23_master_slave_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_Master_Slaver 主从模式选择
 * @{
 */
#define ATIM0_M23_MSCR_MSM_SlAVE  (0x00000000u)          /*!< 从模式 */
#define ATIM0_M23_MSCR_MSM_MASTER (ATIM0MODE23_MSCR_MSM) /*!< 主模式 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Master_Source 主模式触发源选择
 * @{
 */
#define ATIM0_M23_MSCR_MMS_TRIG_SOURCE_UG      (0x00000000u)                    /*!< 软件更新UG，写CR.UG       */
#define ATIM0_M23_MSCR_MMS_TRIG_SOURCE_CTEN    (1u << ATIM0MODE23_MSCR_MMS_Pos) /*!< 定时器使能CTEN            */
#define ATIM0_M23_MSCR_MMS_TRIG_SOURCE_UEV     (2u << ATIM0MODE23_MSCR_MMS_Pos) /*!< 定时器事件更新UEV         */
#define ATIM0_M23_MSCR_MMS_TRIG_SOURCE_CMPSO   (3u << ATIM0MODE23_MSCR_MMS_Pos) /*!< 比较匹配选择输出CMPSO     */
#define ATIM0_M23_MSCR_MMS_TRIG_SOURCE_OCREF0A (4u << ATIM0MODE23_MSCR_MMS_Pos) /*!< 定时器比较参数输出OCREF0A */
#define ATIM0_M23_MSCR_MMS_TRIG_SOURCE_OCREF0B (ATIM0MODE23_MSCR_MMS)           /*!< 定时器比较参数输出OCREF0B */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Slaver_Func 从模式选择
 * @{
 */
#define ATIM0_M23_MSCR_SMS_INTERNAL_CLK  (0x00000000u)                    /*!< 使用内部时钟      */
#define ATIM0_M23_MSCR_SMS_RESET         (1u << ATIM0MODE23_MSCR_SMS_Pos) /*!< 复位功能          */
#define ATIM0_M23_MSCR_SMS_TRIG          (2u << ATIM0MODE23_MSCR_SMS_Pos) /*!< 触发模式          */
#define ATIM0_M23_MSCR_SMS_EXTERNAL_CLK  (3u << ATIM0MODE23_MSCR_SMS_Pos) /*!< 外部时钟模式      */
#define ATIM0_M23_MSCR_SMS_QUADRATURE_M1 (4u << ATIM0MODE23_MSCR_SMS_Pos) /*!< 正交编码计数模式1 */
#define ATIM0_M23_MSCR_SMS_QUADRATURE_M2 (5u << ATIM0MODE23_MSCR_SMS_Pos) /*!< 正交编码计数模式2 */
#define ATIM0_M23_MSCR_SMS_QUADRATURE_M3 (6u << ATIM0MODE23_MSCR_SMS_Pos) /*!< 正交编码计数模式3 */
#define ATIM0_M23_MSCR_SMS_GATE          (ATIM0MODE23_MSCR_SMS)           /*!< 门控功能          */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Trigger_Source 触发输入源选择
 * @{
 */
#define ATIM0_M23_MSCR_TS_ETFP      (0x00000000u)                   /*!< 端口ETR的滤波相位选择后的信号ETFP  */
#define ATIM0_M23_MSCR_TS_ITR0      (1u << ATIM0MODE23_MSCR_TS_Pos) /*!< 内部互联信号 ITR0                  */
#define ATIM0_M23_MSCR_TS_ITR1      (2u << ATIM0MODE23_MSCR_TS_Pos) /*!< 内部互联信号 ITR1                  */
#define ATIM0_M23_MSCR_TS_ITR2      (3u << ATIM0MODE23_MSCR_TS_Pos) /*!< 内部互联信号 ITR2                  */
#define ATIM0_M23_MSCR_TS_ITR3      (4u << ATIM0MODE23_MSCR_TS_Pos) /*!< 内部互联信号 ITR3                  */
#define ATIM0_M23_MSCR_TS_CH0A_EDGE (5u << ATIM0MODE23_MSCR_TS_Pos) /*!< 端口CH0A的边沿信号                 */
#define ATIM0_M23_MSCR_TS_IAFP      (6u << ATIM0MODE23_MSCR_TS_Pos) /*!< 端口CH0A的滤波相位选择后的信号IAFP */
#define ATIM0_M23_MSCR_TS_IBFP      (ATIM0MODE23_MSCR_TS)           /*!< 端口CH0B的滤波相位选择后的信号IBFP */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_IA0_IN_Sel IA0(CH0A) Input Selection (MSCR.IA0S)
 * @{
 */
#define ATIM0_M23_MSCR_IA0_CH0A              (0x00000000u)           /*!< IA0选择CHA             */
#define ATIM0_M23_MSCR_IA0_CH0A_ETR_GATE_XOR (ATIM0MODE23_MSCR_IA0S) /*!< CHA,ETR,GATE的XOR的值 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_IB0_IN_Sel IB0(CH0B) Input Selection (MSCR.IB0S)
 * @{
 */
#define ATIM0_M23_MSCR_IB0_CH0B      (0x00000000u)           /*!<IB0选择CH0B   */
#define ATIM0_M23_MSCR_IB0_TS_SOURCE (ATIM0MODE23_MSCR_IB0S) /*!<IB0选择TS的源 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 CHxA通道比较、输出控制 配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32CHxCmpCap;      /*!< CHxA/CHxB比较/捕获功能选择 @ref ATim0_Mode23_CH_Mode        */
    uint32_t u32CHxCmpModeCtrl; /*!< CHxA/CHxB通道比较控制      @ref ATim0_Mode23_PWM_Comp_Mode  */
    uint32_t u32CHxPolarity;    /*!< CHxA/CHxB输出极性控制      @ref ATim0_Mode23_PWM_Polarity   */
    uint32_t u32CHxCmpBufEn;    /*!< 比较A/B缓存功能 使能/禁止  @ref ATim0_Mode23_CH_Buf_EN      */
    uint32_t u32CHxCmpIntSel;   /*!< CHxA/CHxB比较匹配中断选择  @ref ATim0_Mode23_CHxA_Match_INT */
                                /*!<                            @ref ATim0_Mode23_CHxB_Match_INT */
} stc_atim0_m23_compare_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_CH_Mode CHxA/CHxB比较/捕获功能选择
 * @{
 */
#define ATIM0_M23_CRCHx_CSA_CSB_COMPARE (0x00000000u)           /*!< 比较模式 */
#define ATIM0_M23_CRCHx_CSA_CSB_CAPTURE (ATIM0MODE23_CRCH0_CSA) /*!< 捕获模式 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_CH_Buf_EN 比较A/B缓存功能 使能/禁止
 * @{
 */
#define ATIM0_M23_CRCHx_BUFEx_DISABLE (0x00000000u)             /*!< 禁止 */
#define ATIM0_M23_CRCHx_BUFEx_ENABLE  (ATIM0MODE23_CRCH0_BUFEA) /*!< 使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_CHxA_Match_INT CHxA/CHxB比较匹配中断选择
 * @{
 */
#define ATIM0_M23_M23CR_CISA_DISABLE_IRQ   (0x00000000u)                    /*!< 无匹配             */
#define ATIM0_M23_M23CR_CISA_RISE_IRQ      (1 << ATIM0MODE23_M23CR_CIS_Pos) /*!< 上升沿匹配         */
#define ATIM0_M23_M23CR_CISA_FALL_IRQ      (2 << ATIM0MODE23_M23CR_CIS_Pos) /*!< 下降沿匹配         */
#define ATIM0_M23_M23CR_CISA_RISE_FALL_IRQ (ATIM0MODE23_M23CR_CIS)          /*!< 上升沿和下降沿匹配 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_PWM_Comp_Mode CHxA/CHxB通道比较控制
 * @{
 */
#define ATIM0_M23_FLTR_OCMxx_FORCE_LOW         (0x00000000u)                           /*!< 强制为0低电平                        */
#define ATIM0_M23_FLTR_OCMxx_FORCE_HIGH        (1u << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< 强制为1高电平                        */
#define ATIM0_M23_FLTR_OCMxx_COMP_FORCE_LOW    (2u << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< 比较匹配时候强制为0低电平            */
#define ATIM0_M23_FLTR_OCMxx_COMP_FORCE_HIGH   (3u << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< 比较匹配时候强制为1高电平            */
#define ATIM0_M23_FLTR_OCMxx_COMP_REVERSE      (4u << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< 比较匹配时候翻转                     */
#define ATIM0_M23_FLTR_OCMxx_COMP_ONE_PRD_HIGH (5u << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< 比较匹配时候输出一个计数周期的高电平 */
#define ATIM0_M23_FLTR_OCMxx_PWM_MODE_1        (6u << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< PWM模式1                             */
#define ATIM0_M23_FLTR_OCMxx_PWM_MODE_2        (ATIM0MODE23_FLTR_OCMA0FLTA0)           /*!< PWM模式2                             */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_PWM_Polarity CHxA/CHxB输出极性控制
 * @{
 */
#define ATIM0_M23_FLTR_CCPxx_NORMAL_IN_OUT  (0x00000000u)            /*!< 正常输出 */
#define ATIM0_M23_FLTR_CCPxx_REVERSE_IN_OUT (ATIM0MODE23_FLTR_CCPA0) /*!< 反向输出 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_CHxB_Match_INT CHxB比较匹配中断选择
 * @{
 */
#define ATIM0_M23_CRCHx_CISBx_DISABLE_IRQ   (0x00000000u)                     /*!< 无匹配             */
#define ATIM0_M23_CRCHx_CISBx_RISE_IRQ      (1 << ATIM0MODE23_CRCH0_CISB_Pos) /*!< 上升沿匹配         */
#define ATIM0_M23_CRCHx_CISBx_FALL_IRQ      (2 << ATIM0MODE23_CRCH0_CISB_Pos) /*!< 下降沿匹配         */
#define ATIM0_M23_CRCHx_CISBx_RISE_FALL_IRQ (ATIM0MODE23_CRCH0_CISB)          /*!< 上升沿和下降沿匹配 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 CHA/CHB通道捕获、输入控制 配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32CHxCmpCap;   /*!< CHxA/CHxB比较/捕获功能选择 @ref ATim0_Mode23_CH_Mode      */
    uint32_t u32CHxCapSel;   /*!< CHxA/CHxB捕获边沿选择      @ref ATim0_Mode23_Capture_Edge */
    uint32_t u32CHxInFlt;    /*!< CHxA/CHxB通道捕获滤波控制  @ref ATim0_Mode23_Filter       */
    uint32_t u32CHxPolarity; /*!< CHxA/CHxB输入相位          @ref ATim0_Mode23_PWM_Polarity */
} stc_atim0_m23_input_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_Capture_Edge CRA_CFA(BKSA)& CRB_CFB(BKSB) CHxA/CHxB捕获边沿选择
 * @{
 */
#define ATIM0_M23_CRCHx_CRxCFx_CAPTURE_EDGE_DISABLE   (0x00000000u)                           /*!< 禁止上升沿或下降沿捕获 */
#define ATIM0_M23_CRCHx_CRxCFx_CAPTURE_EDGE_RISE      (1 << ATIM0MODE23_CRCH0_BKSACFACRA_Pos) /*!< 上升沿捕获使能         */
#define ATIM0_M23_CRCHx_CRxCFx_CAPTURE_EDGE_FALL      (2 << ATIM0MODE23_CRCH0_BKSACFACRA_Pos) /*!< 下降沿捕获使能         */
#define ATIM0_M23_CRCHx_CRxCFx_CAPTURE_EDGE_RISE_FALL (ATIM0MODE23_CRCH0_BKSACFACRA)          /*!< 上升沿和下降沿捕获使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Filter FLTAx/FLTBx/FLTET CHxB通道捕获滤波控制
 * @{
 */
#define ATIM0_M23_FLTR_FLTxx_NONE          (0x00000000u)                          /*!< 无滤波              */
#define ATIM0_M23_FLTR_FLTxx_THREE_PCLK    (4 << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< PCLK 3个连续有效    */
#define ATIM0_M23_FLTR_FLTxx_THREE_PCLK_4  (5 << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< PCLK/4 3个连续有效  */
#define ATIM0_M23_FLTR_FLTxx_THREE_PCLK_16 (6 << ATIM0MODE23_FLTR_OCMA0FLTA0_Pos) /*!< PCLK/16 3个连续有效 */
#define ATIM0_M23_FLTR_FLTxx_THREE_PCLK_64 (ATIM0MODE23_FLTR_OCMA0FLTA0)          /*!< PCLK/64 3个连续有效 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 ETR输入相位滤波配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32ETRPolarity; /*!< ETR输入极性设置 @ref ATim0_Mode23_Input_Polarity */
    uint32_t u32ETRFlt;      /*!< ETR滤波设置     @ref ATim0_Mode23_Filter         */
} stc_atim0_m23_etr_input_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_Input_Polarity ETR输入极性设置
 * @{
 */
#define ATIM0_M23_FLTR_ETP_NORMAL_IN  (0x00000000u)          /*!< 正常输入 */
#define ATIM0_M23_FLTR_ETP_REVERSE_IN (ATIM0MODE23_FLTR_ETP) /*!< 反向输入 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief ATIM0 刹车BK输入相位滤波配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32EnBrake;       /*!< 刹车使能           @ref ATim0_Mode23_Brake_EN        */
    uint32_t u32EnVCBrake;     /*!< 使能VC刹车         @ref ATim0_Mode23_Brake_VC_EN     */
    uint32_t u32EnSafetyBk;    /*!< 使能safety刹车     @ref ATim0_Mode23_Brake_Safe_EN   */
    uint32_t u32BrakePolarity; /*!< 刹车BK输入极性设置 @ref ATim0_Mode23_Brake_Polarity  */
    uint32_t u32BrakeFlt;      /*!< 刹车BK滤波设置     @ref ATim0_Mode23_Filter          */
} stc_atim0_m23_bk_input_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_Brake_EN 刹车使能
 * @{
 */
#define ATIM0_M23_DTR_BKE_BRAKE_DISABLE (0x00000000u)        /*!< 禁止 */
#define ATIM0_M23_DTR_BKE_BRAKE_ENABLE  (ATIM0MODE23_DTR_BK) /*!< 使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Brake_VC_EN 使能VC刹车
 * @{
 */
#define ATIM0_M23_DTR_VCE_BRAKE_DISABLE (0x00000000u)        /*!< 禁止 */
#define ATIM0_M23_DTR_VCE_BRAKE_ENABLE  (ATIM0MODE23_DTR_VC) /*!< 使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Brake_Safe_EN 使能safety刹车
 * @{
 */
#define ATIM0_M23_DTR_SAFEEN_BRAKE_DISABLE (0x00000000u)          /*!< 禁止 */
#define ATIM0_M23_DTR_SAFEEN_BRAKE_ENABLE  (ATIM0MODE23_DTR_SAFE) /*!< 使能 */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Brake_Polarity 刹车BK输入极性设置
 * @{
 */
#define ATIM0_M23_FLTR_BKP_NORMAL_IN  (0x00000000u)          /*!< 正相 */
#define ATIM0_M23_FLTR_BKP_REVERSE_IN (ATIM0MODE23_FLTR_BKP) /*!< 反相 */
/**
 * @}
 */

/**
 * @brief BKSEL Brake sync setting
 */
#define ATIM0_M23_DTR_BKSEL_BRAKE_SYNC_DISABLE (0x00000000u)
#define ATIM0_M23_DTR_BKSEL_BRAKE_SYNC_ENABLE  (ATIM0MODE23_DTR_BKSEL)

/**
 * @defgroup ATim0_Mode23_Brake_Port_Out_Level 刹车发生时端口电平及状态
 * @{
 */
#define ATIM0_M23_CRCHx_BKSA_BKSB_PORT_OUTPUT_HIZ  (0x00000000u)                           /*!< 高阻态         */
#define ATIM0_M23_CRCHx_BKSA_BKSB_PORT_OUTPUT_KEEP (1 << ATIM0MODE23_CRCH0_BKSACFACRA_Pos) /*!< 保持，无影响   */
#define ATIM0_M23_CRCHx_BKSA_BKSB_PORT_OUTPUT_LOW  (2 << ATIM0MODE23_CRCH0_BKSACFACRA_Pos) /*!< 强制输出低电平 */
#define ATIM0_M23_CRCHx_BKSA_BKSB_PORT_OUTPUT_HIGH (ATIM0MODE23_CRCH0_BKSACFACRA)          /*!< 强制输出高电平 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief 死区功能配置结构体定义(模式23)
 */
typedef struct
{
    boolean_t bEnDeadTime;      /*!< 死区使能设置，FALSE: 禁止, TRUE: 使能 */
    uint32_t  u32DeadTimeValue; /*!< 8 bit 死区时间设置                    */
} stc_atim0_m23_dt_cfg_t;

/**
 * @brief 触发ADC配置结构体定义(模式23)
 */
typedef struct
{
    boolean_t bEnTrigADC;        /*!< 触发ADC全局控制，FALSE: 禁止, TRUE: 使能     */
    boolean_t bEnUevTrigADC;     /*!< 事件更新触发ADC，FALSE: 禁止, TRUE: 使能     */
    boolean_t bEnCH0ACmpTrigADC; /*!< CH0A比较匹配触发ADC，FALSE: 禁止, TRUE: 使能 */
    boolean_t bEnCH0BCmpTrigADC; /*!< CH0B比较匹配触发ADC，FALSE: 禁止, TRUE: 使能 */
} stc_atim0_m23_adc_trig_cfg_t;

/**
 * @brief 重复计数功能配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t u32EnUnderFlowMask; /*!< 下溢使能屏蔽 @ref ATim0_Mode23_UND_Repeat_Cnt */
    uint32_t u32EnOverFLowMask;  /*!< 上溢使能屏蔽 @ref ATim0_Mode23_OVF_Repeat_Cnt */
    uint32_t u32RepeatCountNum;  /*!< 8 bit重复计数次数设置                         */
} stc_atim0_m23_rcr_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_UND_Repeat_Cnt Under Flow Repeat Count setting
 * @{
 */
#define ATIM0_M23_RCR_UND_IRQ_EVT_CNT_ENABLE (0x00000000u)        /*!< 下溢出计数屏蔽，RCR不计算下溢出 */
#define ATIM0_M23_RCR_UND_IRQ_EVT_CNT_MASK   (ATIM0MODE23_RCR_UD) /*!< 下溢出计数使能，RCR计算下溢出   */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_OVF_Repeat_Cnt Over Flow Repeat Count setting
 * @{
 */
#define ATIM0_M23_RCR_OVF_IRQ_EVT_CNT_ENABLE (0x00000000u)        /*!< 上溢出屏蔽，RCR不计算上溢出 */
#define ATIM0_M23_RCR_OVF_IRQ_EVT_CNT_MASK   (ATIM0MODE23_RCR_OV) /*!< 上溢出不屏蔽，RCR计算上溢出 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup ATIM0Mode23_Global_Types ATIM0 Moder23全局类型定义
 * @{
 */

/**
 * @brief OCREF清除功能 配置结构体定义(模式23)
 */
typedef struct
{
    uint32_t  u32OCRefClrSrcSel; /*!< OCREF清除源选择 @ref ATim0_Mode23_OCREF_Clear_Source               */
    boolean_t bOCSourceClrEn;    /*!< 来自OCCS的OCREF_Clr源是否使能清除OCREF输出,FALSE: 禁止, TRUE: 使能 */
} stc_atim0_m23_ocref_clr_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ATim0_Mode23_Global_Macros ATIM0_Mode23全局宏定义
 * @{
 */

/**
 * @defgroup ATim0_Mode23_OCREF_Clear_Source OCREF清除源选择
 * @{
 */
#define ATIM0_M23_M23CR_OCCS_VC  (0x00000000u)            /*!< 来自VC输出的OCREF_Clr                */
#define ATIM0_M23_M23CR_OCCS_ETR (ATIM0MODE23_M23CR_OCCS) /*!< 来自ETR端口滤波相位选择后的OCREF_Clr */
/**
 * @}
 */

/**
 * @defgroup ATim0_Mode23_Comp_Trigger_DMA Compare trig DMA enable or disable setting
 * @{
 */
#define ATIM0_M23_MSCR_COMPARE_TRIG_DMA_ENABLE  (0x00000000u)           /*!< 比较模式下，比较匹配触发DMA许可                        */
#define ATIM0_M23_MSCR_COMPARE_TRIG_DMA_DISABLE (ATIM0MODE23_MSCR_CCDS) /*!< 比较模式下，比较匹配不触发DMA，使用事件更新替代触发DMA */
/**
 * @}
 */

/**
 * @defgroup ATIM0_INT_Status_Flags     ATIM0 Mode0/1/2/3 Interrupt Status Flags
 * @{
 */
#define ATIM0_INT_FLAG_UI      (ATIM0MODE23_IFR_UIF)  /*!< 溢出中断标志                  */
#define ATIM0_INT_FLAG_PWC_CA0 (ATIM0MODE23_IFR_CA0F) /*!< 通道CH0A发生捕获/比较匹配标志 */
#define ATIM0_INT_FLAG_CB0     (ATIM0MODE23_IFR_CB0F) /*!< 通道CH0B发生捕获/比较匹配标志 */
#define ATIM0_INT_FLAG_CA0E    (ATIM0MODE23_IFR_CA0E) /*!< 通道CH0A捕获数据丢失标志      */
#define ATIM0_INT_FLAG_CB0E    (ATIM0MODE23_IFR_CB0E) /*!< 通道CH0B捕获数据丢失标志      */
#define ATIM0_INT_FLAG_BI      (ATIM0MODE23_IFR_BI)   /*!< 刹车中断标志                  */
#define ATIM0_INT_FLAG_TI      (ATIM0MODE23_IFR_TI)   /*!< 触发中断标志                  */
#define ATIM0_INT_FLAG_OV      (ATIM0MODE23_IFR_OV)   /*!< 上溢出中断标志                */
#define ATIM0_INT_FLAG_UND     (ATIM0MODE23_IFR_UND)  /*!< 下溢出中断标志                */
/**
 * @}
 */

/**
 * @defgroup ATIM0_INT_Clear_Flags     ATIM0 Mode0/1/2/3 Interrupt Clear Flags
 * @{
 */
#define ATIM0_INT_CLR_UI      (ATIM0MODE23_ICLR_UIF)  /*!< 溢出中断标志                  */
#define ATIM0_INT_CLR_PWC_CA0 (ATIM0MODE23_ICLR_CA0F) /*!< 通道CH0A发生捕获/比较匹配标志 */
#define ATIM0_INT_CLR_CB0     (ATIM0MODE23_ICLR_CB0F) /*!< 通道CH0B发生捕获/比较匹配标志 */
#define ATIM0_INT_CLR_CA0E    (ATIM0MODE23_ICLR_CA0E) /*!< 通道CH0A捕获数据丢失标志      */
#define ATIM0_INT_CLR_CB0E    (ATIM0MODE23_ICLR_CB0E) /*!< 通道CH0B捕获数据丢失标志      */
#define ATIM0_INT_CLR_BI      (ATIM0MODE23_ICLR_BI)   /*!< 刹车中断标志                  */
#define ATIM0_INT_CLR_TI      (ATIM0MODE23_ICLR_TI)   /*!< 触发中断标志                  */
#define ATIM0_INT_CLR_OV      (ATIM0MODE23_ICLR_OV)   /*!< 上溢出中断标志                */
#define ATIM0_INT_CLR_UND     (ATIM0MODE23_ICLR_UND)  /*!< 下溢出中断标志                */
/**
 * @}
 */

/**
 * @defgroup ATIM0_Mode1_INT_Request ATIM0 Mode1 Interrupt Request
 * @{
 */
#define ATIM0_M1_INT_UI  (0x00000001u) /*!< 模式1 溢出中断         */
#define ATIM0_M1_INT_CA0 (0x00000002u) /*!< 模式1 脉宽测量完成中断 */
/**
 * @}
 */

/**
 * @defgroup ATIM0_Mode23_INT_Request ATIM0 Mode23 Interrupt Request
 * @{
 */
#define _INTERRUPT_M23CR_ID   (0x80000000U)
#define _INTERRUPT_CRCH0_ID   (0x08000000U)

#define _INTERRUPT_M23CR_MASK (0x30180400U)
#define _INTERRUPT_CRCH0_MASK (0x00000300U)

#define ATIM0_M23_INT_UI      (_INTERRUPT_M23CR_ID | ATIM0MODE23_M23CR_UI)   /*!< 模式23 溢出中断         */
#define ATIM0_M23_INT_BI      (_INTERRUPT_M23CR_ID | ATIM0MODE23_M23CR_BI)   /*!< 模式23 刹车中断         */
#define ATIM0_M23_INT_TI      (_INTERRUPT_M23CR_ID | ATIM0MODE23_M23CR_TI)   /*!< 模式23 触发中断         */
#define ATIM0_M23_INT_OV      (_INTERRUPT_M23CR_ID | ATIM0MODE23_M23CR_OV)   /*!< 模式23 上溢中断         */
#define ATIM0_M23_INT_UND     (_INTERRUPT_M23CR_ID | ATIM0MODE23_M23CR_UND)  /*!< 模式23 下溢中断         */
#define ATIM0_M23_INT_CA0     (_INTERRUPT_CRCH0_ID | ATIM0MODE23_CRCH0_CIEA) /*!< 模式23 比较捕获CH0A中断 */
#define ATIM0_M23_INT_CB0     (_INTERRUPT_CRCH0_ID | ATIM0MODE23_CRCH0_CIEB) /*!< 模式23 比较捕获CH0B中断 */
/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
  Global function prototypes (definition in C source)
*******************************************************************************/
/**
 * @addtogroup ATIM0_Global_Functions ATIM0全局函数定义 模式0初始化及相关功能操作
 * @{
 */
/**
 * @brief timer配置及初始化
 */
void ATIM0_Mode0_Init(stc_atim0_mode0_cfg_t* pstcCfg);
/**
 * @brief timer 启动/停止
 */
void ATIM0_Mode0_Run(void);
void ATIM0_Mode0_Stop(void);
/**
 * @brief 重载值设置/获取
 */
void     ATIM0_Mode0_ARRSet(uint32_t u16Data);
uint32_t ATIM0_Mode0_ARRGet(void);
/**
 * @brief 16位计数值设置/获取
 */
void     ATIM0_Mode0_Cnt16Set(uint32_t u16Data);
uint32_t ATIM0_Mode0_Cnt16Get(void);
/**
 * @brief 32位计数值设置/获取
 */
void     ATIM0_Mode0_Cnt32Set(uint32_t u32Data);
uint32_t ATIM0_Mode0_Cnt32Get(void);
/**
 * @brief 端口输出使能/禁止设定
 */
void ATIM0_Mode0_Enable_Output(boolean_t bEnOutput);
/**
 * @brief 翻转使能/禁止（低电平）设定
 */
void ATIM0_Mode0_Enable_TOG(boolean_t bEnTOG);
/**
 * @}
 */

/**
 * @addtogroup ATIM0_Global_Functions ATIM0全局函数定义 模式1初始化及相关功能操作
 * @{
 */
/**
 * @brief timer配置及初始化
 */
void ATIM0_Mode1_Init(stc_atim0_mode1_cfg_t* pstcCfg);
/**
 * @brief PWC 输入配置
 */
void ATIM0_Mode1_Input_Cfg(stc_atim0_pwc_input_cfg_t* pstcCfg);
/**
 * @brief PWC测量边沿起始结束选择
 */
void ATIM0_Mode1_PWC_Edge_Sel(uint32_t u32DetectEdgeSel);
/**
 * @brief timer 启动/停止
 */
void ATIM0_Mode1_Run(void);
void ATIM0_Mode1_Stop(void);
/**
 * @brief 16位计数值设置/获取
 */
void     ATIM0_Mode1_Cnt16Set(uint32_t u16Data);
uint32_t ATIM0_Mode1_Cnt16Get(void);
/**
 * @brief 脉冲宽度测量结果数值获取
 */
uint32_t ATIM0_Mode1_PWC_CapValueGet(void);
/**
 * @}
 */

/**
 * @addtogroup ATIM0_Global_Functions ATIM0全局函数定义 模式23初始化及相关功能操作
 * @{
 */
/**
 * @brief timer配置及初始化
 */
void ATIM0_Mode23_Init(stc_atim0_mode23_cfg_t* pstcCfg);
/**
 * @brief timer 启动/停止
 */
void ATIM0_Mode23_Run(void);
void ATIM0_Mode23_Stop(void);
/**
 * @brief PWM 手动 输出使能/禁止
 */
void ATIM0_Mode23_Manual_PWM_Output_Enable(boolean_t bEnOutput);
/**
 * @brief PWM 自动 输出使能/禁止
 */
void ATIM0_Mode23_Auto_PWM_Output_Enable(boolean_t bEnAutoOutput);
/**
 * @brief 重载值(周期)缓存功能使能/禁止
 */
void ATIM0_Mode23_ARR_Buffer_Enable(boolean_t bEnBuffer);
/**
 * @brief 重载值(周期)设置/获取
 */
void     ATIM0_Mode23_ARRSet(uint16_t u16Data);
uint32_t ATIM0_Mode23_GetARR(void);
/**
 * @brief 16位计数值设置/获取
 */
void     ATIM0_Mode23_Cnt16Set(uint16_t u16Data);
uint32_t ATIM0_Mode23_Cnt16Get(void);
/**
 * @brief 比较捕获寄存器CCRxA/CCRxB/CCR3设置/读取
 */
void     ATIM0_Mode23_Channel_Compare_Value_Set(uint32_t u32Channel, uint16_t u16Data);
uint32_t ATIM0_Mode23_Channel_Capture_Value_Get(uint32_t u32Channel);
/**
 * @brief PWM互补输出模式下，GATE功能选择
 */
void ATIM0_Mode23_GateFuncSel(stc_atim0_m23_gate_cfg_t* pstcCfg);
/**
 * @brief 主从触发配置
 */
void ATIM0_Mode23_MasterSlave_Trig_Set(stc_atim0_m23_master_slave_cfg_t* pstcCfg);
void ATIM0_Mode23_MSCR_IA0_Sel(uint32_t u32Ia0Sel);
void ATIM0_Mode23_MSCR_IB0_Sel(uint32_t u32Ib0Sel);
/**
 * @brief CHxA/CHxB比较输出通道控制
 */
void ATIM0_Mode23_PortOutput_CHA_Cfg(stc_atim0_m23_compare_cfg_t* pstcCfg);
void ATIM0_Mode23_PortOutput_CHB_Cfg(stc_atim0_m23_compare_cfg_t* pstcCfg);
/**
 * @brief CH0A/CH0B输入控制
 */
void ATIM0_Mode23_PortInput_CHA_Cfg(stc_atim0_m23_input_cfg_t* pstcCfg);
void ATIM0_Mode23_PortInput_CHB_Cfg(stc_atim0_m23_input_cfg_t* pstcCfg);
/**
 * @brief ERT输入控制
 */
void ATIM0_Mode23_ETRInput_Cfg(stc_atim0_m23_etr_input_cfg_t* pstcCfg);
/**
 * @brief 刹车BK输入控制
 */
void ATIM0_Mode23_BrakeInput_Cfg(stc_atim0_m23_bk_input_cfg_t* pstcBkCfg);
void ATIM0_Mode23_Brake_Port_Status_Cfg(uint32_t u32ChxaStatus, uint32_t u32ChxbStatus);
/**
 * @brief 死区功能
 */
void ATIM0_Mode23_DT_Cfg(stc_atim0_m23_dt_cfg_t* pstcCfg);
/**
 * @brief 触发ADC控制
 */
void ATIM0_Mode23_TrigADC_Cfg(stc_atim0_m23_adc_trig_cfg_t* pstcCfg);
/**
 * @brief 重复周期设置
 */
void ATIM0_Mode23_SetRepeatPeriod(stc_atim0_m23_rcr_cfg_t* pstcCfg);
/**
 * @brief OCREF清除功能
 */
void ATIM0_Mode23_OCRefClr(stc_atim0_m23_ocref_clr_cfg_t* pstcCfg);
/**
 * @brief 使能DMA传输
 */
void ATIM0_Mode23_EnDisable_UEV_TrigDMA(boolean_t bUevTrigDMA);
void ATIM0_Mode23_EnDisable_Trigger_TrigDMA(boolean_t bTITrigDMA);
void ATIM0_Mode23_EnDisable_CH0A_TrigDMA(boolean_t bCH0ATrigDMA);
void ATIM0_Mode23_EnDisable_CH0B_TrigDMA(boolean_t bCH0BTrigDMA);
void ATIM0_Mode23_Compare_Trig_DMA_Sel(uint32_t u32CmpUevTrigDMA);
/**
 * @brief CHxA/CHxB捕获比较软件触发
 */
void ATIM0_Mode23_Enable_CH0A_SwTrig_Capture_Compare(void);
void ATIM0_Mode23_Enable_CH0B_SwTrig_Capture_Compare(void);
/**
 * @brief 软件更新使能
 */
void ATIM0_Mode23_EnableSoftwareUev(void);
/**
 * @brief 软件触发使能
 */
void ATIM0_Mode23_EnableSoftwareTrig(void);
/**
 * @brief 软件刹车使能
 */
void ATIM0_Mode23_EnableSoftwareBrake(void);
/**
 * @}
 */

/**
 * @addtogroup ATIM0_Global_Functions ATIM0全局函数定义 中断函数相关
 * @{
 */
/**
 * @brief 中断标志获取
 */
uint32_t ATIM0_GetIntFlag(uint32_t u32InterruptFlagTypes);
/**
 * @brief 中断标志清除
 */
void ATIM0_ClearIrqFlag(uint32_t u32InterruptFlagTypes);
/**
 * @brief 所有中断标志清除
 */
void ATIM0_ClearAllIrqFlag(void);
/**
 * @brief 模式0中断使能
 */
void ATIM0_Mode0_EnableIrq(void);
/**
 * @brief 模式0中断禁止
 */
void ATIM0_Mode0_DisableIrq(void);
/**
 * @brief 模式1中断使能
 */
void ATIM0_Mode1_EnableIrq(uint32_t u32InterruptTypes);
/**
 * @brief 模式1中断禁止
 */
void ATIM0_Mode1_DisableIrq(uint32_t u32InterruptTypes);
/**
 * @brief 模式23中断使能
 */
void ATIM0_Mode23_EnableIrq(uint32_t u32InterruptTypes);
/**
 * @brief 模式23中断禁止
 */
void ATIM0_Mode23_DisableIrq(uint32_t u32InterruptTypes);

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __ATIM0_H__ */

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
