/**
 *******************************************************************************
 * @file  vc.h
 * @brief This file contains all the functions prototypes of the VC driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2023-12-18       MADS            Delete VC_INPUT_MINUS_REF1p2
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

#ifndef __VC_H__
#define __VC_H__

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_VC VC子模块驱动库
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/

/**
 * @defgroup VC_Global_Types VC全局类型定义
 * @{
 */

/**
 * @brief  VC Init structure definition
 */
typedef struct
{
    uint32_t u32VcCmpDly;      /*! VC迟滞  @ref VC_HYSTERESIS_VOLT_SELECTION */
    uint32_t u32VcBiasCurrent; /*! VC功耗选择  @ref VC_BIAS_SELECTION */
    uint32_t u32VcFilter;      /*! 输出滤波配置  @ref VC_FILTER_CONFIG */
    uint32_t u32VcInPin_P;     /*! P端输入  @ref VC_INPUT_PLUS_SELECTION */
    uint32_t u32VcInPin_N;     /*! N端输入  @ref VC_INPUT_MINUS_SELECTION */
    uint32_t u32VcOutCfg;      /*! 输出配置  @ref VC_OUTPUT_POLARITY_SELECTION */
} stc_vc_init_cfg_t;

/**
 * @brief  VC电阻分压配置
 */

typedef struct
{
    uint32_t u32VcRefVolt;    /*! 电阻分压电路参考电压选择  @ref VC_REF_VOLT_SELECTION */
    uint32_t u32VcRefVoltDiv; /*! 对参考电压进行分压配置  分压比例：u32RefVoltDiv/64 */
} stc_vc_res_volt_div_cfg_t;

/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup VC_Global_Macros VC全局宏定义
 * @{
 */
/** @defgroup Bit_Define    位定义
 * @{
 */
#define VC_CR0_BIAS_0    (0x1U << VC_CR0_BIAS_Pos)
#define VC_CR0_BIAS_1    (0x2U << VC_CR0_BIAS_Pos)

#define VC_CR0_HYS_0     (0x1U << VC_CR0_HYS_Pos)
#define VC_CR0_HYS_1     (0x2U << VC_CR0_HYS_Pos)

#define VC_CR1_PSEL_0    (0x1U << VC_CR1_PSEL_Pos)
#define VC_CR1_PSEL_1    (0x2U << VC_CR1_PSEL_Pos)
#define VC_CR1_PSEL_2    (0x4U << VC_CR1_PSEL_Pos)
#define VC_CR1_PSEL_3    (0x8U << VC_CR1_PSEL_Pos)

#define VC_CR1_NSEL_0    (0x1U << VC_CR1_NSEL_Pos)
#define VC_CR1_NSEL_1    (0x2U << VC_CR1_NSEL_Pos)
#define VC_CR1_NSEL_2    (0x4U << VC_CR1_NSEL_Pos)
#define VC_CR1_NSEL_3    (0x8U << VC_CR1_NSEL_Pos)

#define VC_CR1_FLTTIME_0 (0x1U << VC_CR1_FLTTIME_Pos)
#define VC_CR1_FLTTIME_1 (0x2U << VC_CR1_FLTTIME_Pos)
#define VC_CR1_FLTTIME_2 (0x4U << VC_CR1_FLTTIME_Pos)
/**
 * @}
 */

/** @defgroup VC_REF_VOLT_SELECTION  VC电阻分压电路参考电压选择
 * @{
 */
#define VC_REF_VOLT_AVCC (0x00000000U) /*!< AVCC */
#define VC_REF_VOLT_ADC  VC_CR0_REF    /*!< ADC参考电压，需使能ADC */
/**
 * @}
 */

/** @defgroup VC_BIAS_SELECTION  VC 偏置电流选择
 * @{
 */
#define VC_BIAS_300nA  (0x00000000U)
#define VC_BIAS_1200nA (VC_CR0_BIAS_0)
#define VC_BIAS_10uA   (VC_CR0_BIAS_1)
#define VC_BIAS_20uA   (VC_CR0_BIAS_0 | VC_CR0_BIAS_1)
/**
 * @}
 */

/** @defgroup VC_HYSTERESIS_VOLT_SELECTION  VC 迟滞电压
 * @{
 */
#define VC_HYSTERESIS_VOLT_NONE (0x00000000U)
#define VC_HYSTERESIS_VOLT_10mV (VC_CR0_HYS_0)
#define VC_HYSTERESIS_VOLT_20mV (VC_CR0_HYS_1)
#define VC_HYSTERESIS_VOLT_30mV (VC_CR0_HYS_0 | VC_CR0_HYS_1)
/**
 * @}
 */

/** @defgroup VC_INPUT_PLUS_SELECTION  VC 电压比较器“+”端输入信号选择
 * @{
 */
#define VC_INPUT_PLUS_PA00 (0x00000000U)
#define VC_INPUT_PLUS_PA01 (VC_CR1_PSEL_0)
#define VC_INPUT_PLUS_PA02 (VC_CR1_PSEL_1)
#define VC_INPUT_PLUS_PA03 (VC_CR1_PSEL_0 | VC_CR1_PSEL_1)
#define VC_INPUT_PLUS_PA04 (VC_CR1_PSEL_2)
#define VC_INPUT_PLUS_PA05 (VC_CR1_PSEL_0 | VC_CR1_PSEL_2)
#define VC_INPUT_PLUS_PB00 (VC_CR1_PSEL_1 | VC_CR1_PSEL_2)
#define VC_INPUT_PLUS_PB01 (VC_CR1_PSEL_0 | VC_CR1_PSEL_1 | VC_CR1_PSEL_2)
#define VC_INPUT_PLUS_PB12 (VC_CR1_PSEL_3)
#define VC_INPUT_PLUS_PB04 (VC_CR1_PSEL_0 | VC_CR1_PSEL_3)
#define VC_INPUT_PLUS_PB05 (VC_CR1_PSEL_1 | VC_CR1_PSEL_3)
/**
 * @}
 */

/** @defgroup VC_INPUT_MINUS_SELECTION  VC 电压比较器“-”端输入信号选择
 * @{
 */
#define VC_INPUT_MINUS_PA00       (0x00000000U)
#define VC_INPUT_MINUS_PA01       (VC_CR1_NSEL_0)
#define VC_INPUT_MINUS_PA02       (VC_CR1_NSEL_1)
#define VC_INPUT_MINUS_PA03       (VC_CR1_NSEL_0 | VC_CR1_NSEL_1)
#define VC_INPUT_MINUS_PA04       (VC_CR1_NSEL_2)
#define VC_INPUT_MINUS_PA05       (VC_CR1_NSEL_0 | VC_CR1_NSEL_2)
#define VC_INPUT_MINUS_PB00       (VC_CR1_NSEL_1 | VC_CR1_NSEL_2)
#define VC_INPUT_MINUS_PB01       (VC_CR1_NSEL_0 | VC_CR1_NSEL_1 | VC_CR1_NSEL_2)
#define VC_INPUT_MINUS_PB12       (VC_CR1_NSEL_3)
#define VC_INPUT_MINUS_PB04       (VC_CR1_NSEL_0 | VC_CR1_NSEL_3)
#define VC_INPUT_MINUS_PB05       (VC_CR1_NSEL_1 | VC_CR1_NSEL_3)
#define VC_INPUT_MINUS_RESVOLTDIV (VC_CR1_NSEL_0 | VC_CR1_NSEL_1 | VC_CR1_NSEL_3)
#define VC_INPUT_MINUS_TEMP       (VC_CR1_NSEL_2 | VC_CR1_NSEL_3)
#define VC_INPUT_MINUS_ADCREF     (VC_CR1_NSEL_1 | VC_CR1_NSEL_2 | VC_CR1_NSEL_3)
#define VC_INPUT_MINUS_LDO        (VC_CR1_NSEL_0 | VC_CR1_NSEL_1 | VC_CR1_NSEL_2 | VC_CR1_NSEL_3)
/**
 * @}
 */

/** @defgroup VC_FILTER_CONFIG  VC 滤波配置
 * @{
 */
#define VC_FILTER_NONE               (0x00000000UL)
#define VC_FILTER_RC150KHz_1CYCLE    ((VC_CR1_FLTEN) | (0x00000000UL))
#define VC_FILTER_RC150KHz_3CYCLE    ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_0))
#define VC_FILTER_RC150KHz_7CYCLE    ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_1))
#define VC_FILTER_RC150KHz_15CYCLE   ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_0 | VC_CR1_FLTTIME_1))
#define VC_FILTER_RC150KHz_63CYCLE   ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_2))
#define VC_FILTER_RC150KHz_255CYCLE  ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_0 | VC_CR1_FLTTIME_2))
#define VC_FILTER_RC150KHz_1023CYCLE ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_1 | VC_CR1_FLTTIME_2))
#define VC_FILTER_RC150KHz_4095CYCLE ((VC_CR1_FLTEN) | (VC_CR1_FLTTIME_0 | VC_CR1_FLTTIME_1 | VC_CR1_FLTTIME_2))
#define VC_FILTER_PCLK_1CYCLE        ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (0x00000000UL))
#define VC_FILTER_PCLK_3CYCLE        ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_0))
#define VC_FILTER_PCLK_7CYCLE        ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_1))
#define VC_FILTER_PCLK_15CYCLE       ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_0 | VC_CR1_FLTTIME_1))
#define VC_FILTER_PCLK_63CYCLE       ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_2))
#define VC_FILTER_PCLK_255CYCLE      ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_0 | VC_CR1_FLTTIME_2))
#define VC_FILTER_PCLK_1023CYCLE     ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_1 | VC_CR1_FLTTIME_2))
#define VC_FILTER_PCLK_4095CYCLE     ((VC_CR1_FLTEN) | (VC_CR1_FLTCLK) | (VC_CR1_FLTTIME_0 | VC_CR1_FLTTIME_1 | VC_CR1_FLTTIME_2))
/**
 * @}
 */

/** @defgroup VC_IT_SELECTION  VC 中断选择
 * @{
 */
#define VC_IT_HIGHLEVEL (VC_CR1_LEVEL)   /*!< 滤波信号高电平触发中断 */
#define VC_IT_RISING    (VC_CR1_RISING)  /*!< 滤波信号上升沿触发中断 */
#define VC_IT_FALLING   (VC_CR1_FALLING) /*!< 滤波信号下降沿触发中断 */
/**
 * @}
 */

/** @defgroup VC_FILTER_CLK_SELECTION  VC 滤波时钟选择
 * @{
 */
#define VC_FILTER_CLK_RC150KHz (0x00000000UL)  /*!< 使用内置RC振荡器，频率约150KHz */
#define VC_FILTER_CLK_PCLK     (VC_CR1_FLTCLK) /*!< 使用PCLK */
/**
 * @}
 */

/** @defgroup VC_OUTPUT_POLARITY_SELECTION  VC 输出极性选择
 * @{
 */
#define VC_OUTPUT_NONINVERTED (0x00000000UL) /*!< 正端大于负端时VCx_OUTP高 */
#define VC_OUTPUT_INVERTED    (VC_CR2_POL)   /*!< 正端大于负端时VCx_OUTP低 */
/**
 * @}
 */

/** @defgroup VC_OUTPUT_ATIM_SELECTION  VC_OUTPUT信号到定时器使能配置
 * @{
 */
#define VC_OUTPUT_ATIM0_REFCLK      (VC_CR2_ATIM0CLR) /*!< VCx滤波后信号输出到 ATIM0 REFCLR 使能控制 */
#define VC_OUTPUT_ATIM3_REFCLK      (VC_CR2_ATIM3CLR) /*!< VCx滤波后信号输出到 ATIM3 REFCLR 使能控制 */
#define VC_OUTPUT_ATIM0_ATIM3_BRAKE (VC_CR2_ATIMBK)   /*!< VCx滤波后信号输出到 ATIM0/3 刹车使能控制 */
/**
 * @}
 */

/** @defgroup VC_WINDOWMODE_CONFIG  VC 串口比较功能配置
 * @{
 */
#define VC_WINDOWMODE_DISABLE     (0x00000000UL)  /*!< 禁止窗口功能，VCx_OUTW信号等于VCx_OUTP */
#define VC_WINDOWMODE_VC1_XOR_VC2 (VC_CR2_WINDOW) /*!< 使能窗口功能，VCx_OUTW信号等于VC0_OUTP与VC1_OUTP的异或值 */
/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 * Global variable definitions ('extern')
 ******************************************************************************/

/******************************************************************************
 * Global function prototypes (definition in C source)
 ******************************************************************************/
/**
 * @addtogroup VC_Global_Functions VC全局函数定义
 * @{
 */
en_result_t VC_Init(VC_TypeDef* VCx, stc_vc_init_cfg_t* pstcInitCfg);
en_result_t VC_ResVoltDivConfig(VC_TypeDef* VCx, stc_vc_res_volt_div_cfg_t* pstcResVoltDivCfg);
void        VC_SetRefVoltDiv(VC_TypeDef* VCx, uint32_t u32RefVoltDiv);
uint32_t    VC_GetRefVoltDiv(VC_TypeDef* VCx);
void        VC_EnableRefVoltDiv(VC_TypeDef* VCx);
void        VC_DisableRefVoltDiv(VC_TypeDef* VCx);
uint32_t    VC_IsEnableRefVoltDiv(VC_TypeDef* VCx);
void        VC_SetRefVolt(VC_TypeDef* VCx, uint32_t u32RefVolt);
uint32_t    VC_GetRefVolt(VC_TypeDef* VCx);
void        VC_SetBiasCurrent(VC_TypeDef* VCx, uint32_t u32BiasCurrent);
uint32_t    VC_GetBiasCurrent(VC_TypeDef* VCx);
void        VC_SetHysteresisVolt(VC_TypeDef* VCx, uint32_t u32HysVolt);
uint32_t    VC_GetHysteresisVolt(VC_TypeDef* VCx);
void        VC_SetInputPlus(VC_TypeDef* VCx, uint32_t u32InputPlus);
uint32_t    VC_GetInputPlus(VC_TypeDef* VCx);
void        VC_SetInputMinus(VC_TypeDef* VCx, uint32_t u32InputMinus);
uint32_t    VC_GetInputMinus(VC_TypeDef* VCx);
void        VC_EnableFilter(VC_TypeDef* VCx);
void        VC_DisableFilter(VC_TypeDef* VCx);
uint32_t    VC_IsEnableFilter(VC_TypeDef* VCx);
void        VC_SetFilterTime(VC_TypeDef* VCx, uint32_t u32FilterTime);
uint32_t    VC_GetFilterTime(VC_TypeDef* VCx);
void        VC_EnableIT(VC_TypeDef* VCx, uint32_t u32IT);
void        VC_DisableIT(VC_TypeDef* VCx, uint32_t u32IT);
void        VC_DisableIT_ALL(VC_TypeDef* VCx);
uint32_t    VC_IsEnableIT(VC_TypeDef* VCx, uint32_t u32IT);
void        VC_Enable(VC_TypeDef* VCx);
void        VC_Disable(VC_TypeDef* VCx);
uint32_t    VC_IsEnable(VC_TypeDef* VCx);
void        VC_SetFilterClk(VC_TypeDef* VCx, uint32_t u32FilterClk);
uint32_t    VC_GetFilterClk(VC_TypeDef* VCx);
void        VC_SetOutputPolarity(VC_TypeDef* VCx, uint32_t u32OutputPolarity);
uint32_t    VC_GetOutputPolarity(VC_TypeDef* VCx);
void        VC_SetOutputAtim(VC_TypeDef* VCx, uint32_t u32OutputAtim);
uint32_t    VC_GetOutputAtim(VC_TypeDef* VCx);
void        VC_SetWindowMode(VC_TypeDef* VCx, uint32_t u32WindowMode);
uint32_t    VC_GetWindowMode(VC_TypeDef* VCx);
uint32_t    VC_GetFilterOutput(VC_TypeDef* VCx);
uint32_t    VC_IsActiveFlag_IT(VC_TypeDef* VCx);
void        VC_ClearFlag_IT(VC_TypeDef* VCx);

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __VC_H__ */
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
