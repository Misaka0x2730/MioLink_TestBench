/**
 *******************************************************************************
 * @file  flash.h
 * @brief This file contains all the functions prototypes of the FLASH driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2023-12-18       MADS            Add flash chip erase function
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

#ifndef __FLASH_H__
#define __FLASH_H__

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "ddl.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_FLASH FLASH子模块驱动库
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup FLASH_Global_Types FLASH全局类型定义
 * @{
 */

/**
 * @brief  Flash中断类型重定义
 */
typedef enum
{
    FlashPCInt    = 0x01u, /*!< FLASH 擦写PC地址报警中断   */
    FlashSlockInt = 0x02u, /*!< FLASH 擦写保护报警中断     */
} en_flash_int_type_t;

/**
 * @brief  Flash功能设置类型重定义
 */
typedef enum
{
    FlashDpStbEn = 0x80u, /*!< 系统进入DeepSleep时，FLASH进入低功耗使能   */
} en_flash_func_type_t;

/**
 * @brief  Flash读等待周期类型重定义
 */
typedef enum
{
    FlashWaitCycle0 = 0u, /*!< 读等待周期设置为0-即读周期为1（当HCLK小于等于24MHz时）   */
    FlashWaitCycle1 = 1u, /*!< 读等待周期设置为1-即读周期为2（当HCLK大于24MHz时必须至少为1）   */
    FlashWaitCycle2 = 2u, /*!< 读等待周期设置为2-即读周期为3（当HCK大于48MHz时必须至少为2）   */
    FlashWaitCycle3 = 3u, /*!< 读等待周期设置为3-即读周期为4（当HCK大于72MHz时必须至少为3）   */
} en_flash_waitcycle_t;

/**
 * @brief  Flash擦写保护范围重定义
 */
typedef enum
{
    FlashLock0 = 0u, /*!< SLOCK0 Sector擦写保护寄存器0  */
    FlashLock1 = 4u, /*!< SLOCK1 Sector擦写保护寄存器1 */
} en_flash_lock_t;

/**
 * @brief  Flash操作模式配置
 */
typedef enum
{
    FlashReadMode        = 0u,  ///< Flash 读模式
    FlashWriteMode       = 1u,  ///< Flash 写（编程）模式
    FlashSectorEraseMode = 2u,  ///< Flash 扇区（页）擦除模式
    FlashChipEraseMode   = 3u,  ///< Flash 全片擦除模式
} en_flash_op_mode_t;

/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup FLASH_Global_Macros FLASH全局宏定义
 * @{
 */
/** @defgroup  Flash_Lock_State_Level
 * @{
 */
#define FLASH_LOCK_STATE_LEVEL0 (0u)
#define FLASH_LOCK_STATE_LEVEL1 (1u)
#define FLASH_LOCK_STATE_LEVEL2 (2u)
#define FLASH_LOCK_STATE_LEVEL3 (3u)
/**
 * @}
 */

/** @defgroup  Flash_Cache_Fun_Config
 * @{
 */
#define FLASH_CACHE_DISABLE        (0u)
#define FLASH_CACHE_INSTRUCTION_EN (1u)
#define FLASH_CACHE_DATA_EN        (2u)
/**
 * @}
 */

/**
 * @}
 */
/*******************************************************************************
 * Global variable definitions ('extern')
 ******************************************************************************/

/*******************************************************************************
  Global function prototypes (definition in C source)
 ******************************************************************************/
/**
 * @addtogroup FLASH_Global_Functions FLASH全局函数定义
 * @{
 */

en_result_t Flash_LockAll(void);
en_result_t Flash_UnlockAll(void);
en_result_t Flash_FuncSet(en_flash_func_type_t enFunc, boolean_t bFlag);
en_result_t Flash_SectorErase(uint32_t u32SectorAddr);
en_result_t Flash_WriteHalfWord(uint32_t u32Addr, uint16_t pu16Data[], uint32_t u32Len);
en_result_t Flash_WriteWord(uint32_t u32Addr, uint32_t pu32Data[], uint32_t u32Len);
en_result_t Flash_OpModeConfig(en_flash_op_mode_t enFlashOpMode);
en_result_t Flash_LockSet(en_flash_lock_t enLock, uint32_t u32LockValue);
en_result_t Flash_WaitCycle(en_flash_waitcycle_t enWaitCycle);
uint8_t     Flash_ReadProtectLevel(void);
en_result_t Flash_EnableIrq(en_flash_int_type_t enFlashIntType);
en_result_t Flash_DisableIrq(en_flash_int_type_t enFlashIntType);
boolean_t   Flash_GetIntFlag(en_flash_int_type_t enFlashIntType);
en_result_t Flash_ClearIntFlag(en_flash_int_type_t enFlashIntType);
en_result_t Flash_CacheConfig(uint32_t flash_cache_fun);
en_result_t Flash_Cache_Reset(void);

#if defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6100100)
en_result_t Flash_Chip_Erase(void);
#elif defined(__ICCARM__)
__ramfunc en_result_t Flash_Chip_Erase(void);
#endif
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __FLASH_H__ */
/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
