/**
 *******************************************************************************
 * @file  i2c.h
 * @brief This file contains all the functions prototypes of the I2C driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */
#ifndef __I2C_H__
#define __I2C_H__

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_I2C I2C子模块驱动库
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup I2C_Global_Types I2C全局类型定义
 * @{
 */

/**
 * @brief  I2C 从机初始化配置结构
 */
typedef struct
{
    uint8_t  u8SlaveAddr0;   /*!< 从机地址0  取值范围0 ~ 127 */
    uint8_t  u8SlaveAddr1;   /*!< 从机地址1  取值范围0 ~ 127 */
    uint8_t  u8SlaveAddr2;   /*!< 从机地址2  取值范围0 ~ 127 */
    uint32_t u32Filter;      /*!< 滤波配置  @ref I2C_FILTER_MODE */
    uint32_t u32BroadcastEn; /*!< 广播地址使能  @ref I2C_BROADCAST_CFG */
} stc_i2c_slave_init_cfg_t;

/**
 * @brief  I2C 主机初始化配置结构
 */
typedef struct
{
    uint32_t u32Pclk;     /*!< pclk时钟频率 */
    uint32_t u32BaudRate; /*!< 波特率 */
} stc_i2c_master_init_cfg_t;
/**
 * @}
 */

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup I2C_Global_Macros I2C全局宏定义
 * @{
 */

/**
 * @defgroup I2C_FILTER_MODE 滤波方式选择
 * @brief    作为主机I2C_BRR值大于9，或者作为从机PCLK与SCL频率比值大于30时，建议使用I2C_FILTER_ADVANCE
 * @{
 */
#define I2C_FILTER_ADVANCE (0x00000000UL) /*!< 更高的抗干扰性能 */
#define I2C_FILTER_SIMPLE  (I2C_CR_FLT)   /*!< 更快的通信滤波 */
/**
 * @}
 */

/**
 * @defgroup I2C_ACKNOWLEDGE_CFG  应答控制
 * @{
 */
#define I2C_NACK (0x00000000UL) /*!< 在应答阶段发送ACK */
#define I2C_ACK  (I2C_CR_AA)    /*!< 在应答阶段发送NAK */
/**
 * @}
 */

/**
 * @defgroup I2C_START_CFG  向总线发送start控制
 * @{
 */
#define I2C_START_DISABLE (0x00000000UL) /*!< 禁止向总线发送start */
#define I2C_START_ENABLE  (I2C_CR_STA)   /*!< 向总线发送start */
/**
 * @}
 */

/**
 * @defgroup I2C_STOP_CFG  向总线发送stop控制
 * @{
 */
#define I2C_STOP_DISABLE (0x00000000UL) /*!< 禁止向总线发送stop */
#define I2C_STOP_ENABLE  (I2C_CR_STO)   /*!< 向总线发送stop */
/**
 * @}
 */

/**
 * @defgroup I2C_BROADCAST_CFG  广播地址应答使能控制
 * @{
 */
#define I2C_BROADCAST_DISABLE (0x00000000UL) /*!< 禁止广播地址应答 */
#define I2C_BROADCAST_ENABLE  (I2C_ADDR0_GC) /*!< 使能广播地址应答 */
/**
 * @}
 */

/**
 * @defgroup I2C_BUS_ADDR_MATCH  总线设备地址匹配
 * @{
 */
#define I2C_BUS_ADDR_MATCH_NONE  (0x00000000UL)   /*!< 无从地址与总线上的设备地址匹配 */
#define I2C_BUS_ADDR_MATCH_ADDR0 (I2C_MATCH_AD0F) /*!< 设备从地址ADDR0与总线上的设备地址匹配 */
#define I2C_BUS_ADDR_MATCH_ADDR1 (I2C_MATCH_AD1F) /*!< 设备从地址ADDR1与总线上的设备地址匹配 */
#define I2C_BUS_ADDR_MATCH_ADDR2 (I2C_MATCH_AD2F) /*!< 设备从地址ADDR2与总线上的设备地址匹配 */
/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
  Global function prototypes (definition in C source)
*******************************************************************************/
/**
 * @addtogroup I2C_Global_Functions I2C全局函数定义
 * @{
 */
en_result_t I2C_MasterInit(I2C_TypeDef* I2Cx, stc_i2c_master_init_cfg_t* pstcMasterInitCfg);
en_result_t I2C_SlaveInit(I2C_TypeDef* I2Cx, stc_i2c_slave_init_cfg_t* pstcSlaveInitCfg);
void        I2C_EnableBaud(I2C_TypeDef* I2Cx);
void        I2C_DisableBaud(I2C_TypeDef* I2Cx);
uint32_t    I2C_IsEnableBaud(I2C_TypeDef* I2Cx);
void        I2C_SetBaud(I2C_TypeDef* I2Cx, uint32_t u32Baud);
uint32_t    I2C_GetBaud(I2C_TypeDef* I2Cx);
void        I2C_SetFilter(I2C_TypeDef* I2Cx, uint32_t u32Filter);
uint32_t    I2C_GetFilter(I2C_TypeDef* I2Cx);
uint32_t    I2C_IsActiveFlag_SI(I2C_TypeDef* I2Cx);
void        I2C_ClearFlag_SI(I2C_TypeDef* I2Cx);
void        I2C_SetAck(I2C_TypeDef* I2Cx, uint32_t u32Ack);
uint32_t    I2C_GetAck(I2C_TypeDef* I2Cx);
void        I2C_SetStop(I2C_TypeDef* I2Cx, uint32_t u32Stop);
uint32_t    I2C_GetStop(I2C_TypeDef* I2Cx);
void        I2C_SetStart(I2C_TypeDef* I2Cx, uint32_t u32Start);
uint32_t    I2C_GetStart(I2C_TypeDef* I2Cx);
void        I2C_Enable(I2C_TypeDef* I2Cx);
void        I2C_Disable(I2C_TypeDef* I2Cx);
uint32_t    I2C_IsEnable(I2C_TypeDef* I2Cx);
void        I2C_WriteByte(I2C_TypeDef* I2Cx, uint8_t u8Data);
uint8_t     I2C_ReadByte(I2C_TypeDef* I2Cx);
uint8_t     I2C_GetBusState(I2C_TypeDef* I2Cx);
void        I2C_EnableBroadcast(I2C_TypeDef* I2Cx);
void        I2C_DisableBroadcast(I2C_TypeDef* I2Cx);
uint32_t    I2C_IsEnableBroadcast(I2C_TypeDef* I2Cx);
void        I2C_SetSlaveAddr0(I2C_TypeDef* I2Cx, uint32_t u32Addr);
uint32_t    I2C_GetSlaveAddr0(I2C_TypeDef* I2Cx);
void        I2C_SetSlaveAddr1(I2C_TypeDef* I2Cx, uint32_t u32Addr);
uint32_t    I2C_GetSlaveAddr1(I2C_TypeDef* I2Cx);
void        I2C_SetSlaveAddr2(I2C_TypeDef* I2Cx, uint32_t u32Addr);
uint32_t    I2C_GetSlaveAddr2(I2C_TypeDef* I2Cx);
uint32_t    I2C_GetBusMatchSlaveAddr(I2C_TypeDef* I2Cx);
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __I2C_H__ */

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
