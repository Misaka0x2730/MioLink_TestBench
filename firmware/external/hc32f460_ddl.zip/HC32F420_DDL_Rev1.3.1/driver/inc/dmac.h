/**
 *******************************************************************************
 * @file  dmac.h
 * @brief This file contains all the functions prototypes of the DMAC driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2023-12-18       MADS            Add comments for DMA_Trigger_Source
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */
#ifndef __DMAC_H__
#define __DMAC_H__

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "ddl.h"

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_DMAC DMAC子模块驱动库
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
 ******************************************************************************/
/**
 * @defgroup DMAC_Global_Types DMAC全局类型定义
 * @{
 */

/**
 * @brief  DMAC通道类型重定义
 */
typedef enum
{
    DMA_CHANNEL0 = 0,
    DMA_CHANNEL1 = 1,
    DMA_CHANNEL2 = 2,
    DMA_CHANNEL3 = 3,
    DMA_CHANNEL4 = 4,
    DMA_CHANNEL5 = 5,
} en_dma_channel_t;

/**
 * @brief  DMAC配置重定义
 */
typedef struct
{
    uint32_t u32Priority;
    uint32_t u32TrigSrc;

    uint32_t u32BlockCnt;
    uint32_t u32TransferCnt;

    uint32_t u32TransferMode;
    uint32_t u32DataSize;

    uint32_t u32SrcAddrFix;
    uint32_t u32DstAddrFix;
    uint32_t u32BTCntReload;
    uint32_t u32SrcAddrReload;
    uint32_t u32DstAddrReload;
    uint32_t u32ChanelEnMsk;

    uint32_t u32SrcAddr;
    uint32_t u32DstAddr;

} stc_dmac_channel_init_t;

/**
 * @}
 */

/*******************************************************************************
 * Sysctrl pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup DMA_Global_Macros DMA全局宏定义
 * @{
 */

/** @defgroup DMA_REG_OFFSET   DMA寄存器偏移地址
 * @{
 */
#define CONFA_OFFSET  0x10U
#define CONFB_OFFSET  0x14U
#define SRCADR_OFFSET 0x18U
#define DSTADR_OFFSET 0x1CU
/**
 * @}
 */

/** @defgroup DMA_Ctrl_EN   DMA控制器开关控制
 * @{
 */
#define DMA_CTRL_DISABLE 0x00000000U  /*!< DMA控制器关闭 */
#define DMA_CTRL_ENABLE  DMAC_CONF_EN /*!< DMA控制器开启 */
/**
 * @}
 */

/** @defgroup DMA_Priority_SEL  DMA优先级选择
 * @{
 */
#define DMA_FIX_PRIORITY  0x00000000U    /*!< 固定优先级模式 CH0 > CH1 */
#define DMA_LOOP_PRIORITY DMAC_CONF_PRIO /*!< 循环优先级模式 CH0和CH1轮流进行 */
/**
 * @}
 */

/** @defgroup DMA_ALL_CH_HALT_CTRL  DMA所有通道暂停控制
 * @{
 */
#define DMA_ALL_CHANNEL_RESUME 0x00000000U    /*!< 恢复所有通道 */
#define DMA_ALL_CHANNEL_HALT   DMAC_CONF_HALT /*!< 暂停所有通道 */
/**
 * @}
 */

/** @defgroup DMA_Channel_enable  DMA当前通道开启
 * @{
 */
#define DMA_CHANNEL_DISABLE 0x00000000U                 /*!< 关闭当前通道 */
#define DMA_CHANNEL_ENABLE  (1U << DMAC_CONFA0_ENS_Pos) /*!< 开启当前通道 */
/**
 * @}
 */

/** @defgroup DMA_Pause_Set  DMA当前通道暂停
 * @{
 */
#define DMA_CHANNEL_RESUME 0x00000000U                 /*!< 恢复当前通道 */
#define DMA_CHANNEL_PAUSE  (1U << DMAC_CONFA0_PAS_Pos) /*!< 暂停当前通道 */
/**
 * @}
 */

/** @defgroup DMA_Soft_Start DMA软件触发控制
 * @{
 */
#define DMA_CHANNEL_SOFT_STOP    0x00000000U                /*!< 停止DMA通道软件Block/Burst传输 */
#define DMA_CHANNEL_SOFT_TRIGGER (1U << DMAC_CONFA0_ST_Pos) /*!< 触发DMA通道软件Block/Burst传输 */
/**
 * @}
 */

/** @defgroup DMA_Trigger_Source DMA触发源
 * @{
 */
#define DMA_TRISRC_SOFTWARE        (0x00U << DMAC_CONFA0_TRI_SEL_Pos) /*!< 软件触发源 */
#define DMA_TRISRC_USART0_TXE      (0x40U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART0发送Buffer空 */
#define DMA_TRISRC_USART0_RXNE     (0x41U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART0接收Buffer非空 */
#define DMA_TRISRC_USART1_TXE      (0x42U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART1发送Buffer空 */
#define DMA_TRISRC_USART1_RXNE     (0x43U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART1接收Buffer非空 */
#define DMA_TRISRC_USART2_TXE      (0x44U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART2发送Buffer空 */
#define DMA_TRISRC_USART2_RXNE     (0x45U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART2接收Buffer非空 */
#define DMA_TRISRC_USART3_TXE      (0x46U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART3发送Buffer空 */
#define DMA_TRISRC_USART3_RXNE     (0x47U << DMAC_CONFA0_TRI_SEL_Pos) /*!< USART3接收Buffer非空 */
#define DMA_TRISRC_GTIM0           (0x48U << DMAC_CONFA0_TRI_SEL_Pos) /*!< GTIM0发生捕获事件或比较事件 */
#define DMA_TRISRC_GTIM1           (0x49U << DMAC_CONFA0_TRI_SEL_Pos) /*!< GTIM1发生捕获事件或比较事件 */
#define DMA_TRISRC_GTIM2           (0x4AU << DMAC_CONFA0_TRI_SEL_Pos) /*!< GTIM2发生捕获事件或比较事件 */
#define DMA_TRISRC_ADC0_SINGLE_EOC (0x4DU << DMAC_CONFA0_TRI_SEL_Pos) /*!< ADC0顺序单次转换完成 */
#define DMA_TRISRC_ADC1_SINGLE_EOC (0x4FU << DMAC_CONFA0_TRI_SEL_Pos) /*!< ADC1顺序单次转换完成 */
#define DMA_TRISRC_SPI0_TXE        (0x50U << DMAC_CONFA0_TRI_SEL_Pos) /*!< SPI0发送Buffer空 */
#define DMA_TRISRC_SPI0_RXNE       (0x51U << DMAC_CONFA0_TRI_SEL_Pos) /*!< SPI0接收Buffer非空 */
#define DMA_TRISRC_SPI1_TXE        (0x52U << DMAC_CONFA0_TRI_SEL_Pos) /*!< SPI1发送Buffer空 */
#define DMA_TRISRC_SPI1_RXNE       (0x53U << DMAC_CONFA0_TRI_SEL_Pos) /*!< SPI1接收Buffer非空 */
#define DMA_TRISRC_ATIM0_CHA       (0x58U << DMAC_CONFA0_TRI_SEL_Pos) /*!< ATIM0通道A发生捕获或比较事件或外部触发 */
#define DMA_TRISRC_ATIM0_CHB       (0x59U << DMAC_CONFA0_TRI_SEL_Pos) /*!< ATIM0通道B发生捕获或比较事件或事件更新 */
#define DMA_TRISRC_ATIM3_CHA       (0x5EU << DMAC_CONFA0_TRI_SEL_Pos) /*!< ATIM3通道A发生捕获或比较事件或外部触发 */
#define DMA_TRISRC_ATIM3_CHB       (0x5FU << DMAC_CONFA0_TRI_SEL_Pos) /*!< ATIM3通道B发生捕获或比较事件或事件更新 */
/**
 * @}
 */

/** @defgroup DMA_Transfer_Mode_SEL DMA传输模式选择
 * @{
 */
#define DMA_BLOCK_MODE 0x00000000U                  /*!< Block传输模式 */
#define DMA_BURST_MODE (1U << DMAC_CONFB0_MODE_Pos) /*!< Burst传输模式 */
/**
 * @}
 */

/** @defgroup DMA_Data_Size  DMA传输数据单位
 * @{
 */
#define DMA_DATA_BYTE     0x00000000U                   /*!< 字节传输 */
#define DMA_DATA_HALFWORD (1U << DMAC_CONFB0_WIDTH_Pos) /*!< 半字传输 */
#define DMA_DATA_WORD     (2U << DMAC_CONFB0_WIDTH_Pos) /*!< 字传输 */
/**
 * @}
 */

/** @defgroup DMA_SourceAddr_SEL DMA源地址保持/自加选择
 * @{
 */
#define DMA_SRCADDR_INC 0x00000000U    /*!< 每传输完一个数据，源地址自增一个数据宽度 */
#define DMA_SRCADDR_FIX DMAC_CONFB0_FS /*!< 数据传输过程中源地址保持不变 */
/**
 * @}
 */

/** @defgroup DMA_DestinationAddr_SEL DMA目标地址保持/自加选择
 * @{
 */
#define DMA_DSTADDR_INC 0x00000000U    /*!< 每传输完一个数据，目标地址自增一个数据宽度 */
#define DMA_DSTADDR_FIX DMAC_CONFB0_FD /*!< 数据传输过程中目标地址保持不变 */
/**
 * @}
 */

/** @defgroup DMA_Bcnt_Tcnt_Reload DMABT/CT重载控制
 * @{
 */
#define DMA_BTCNT_RELOAD_DISABLE 0x00000000U    /*!< 传输完成后BCNT/TCNT均为0 */
#define DMA_BTCNT_RELOAD_ENABLE  DMAC_CONFB0_RC /*!< 传输完成后BCNT/TCNT重载 */
/**
 * @}
 */

/** @defgroup DMA_SourceAddr_Reload DMA源地址重载控制
 * @{
 */
#define DMA_SRCADDR_RELOAD_DISABLE 0x00000000U    /*!< 传输完成后源地址值不重载 */
#define DMA_SRCADDR_RELOAD_ENABLE  DMAC_CONFB0_RS /*!< 传输完成后源地址重载 */
/**
 * @}
 */

/** @defgroup DMA_DestinationAddr_Reload DMA目标地址重载控制
 * @{
 */
#define DMA_DSTADDR_RELOAD_DISABLE 0x00000000U    /*!< 传输完成后目标地址值不重载 */
#define DMA_DSTADDR_RELOAD_ENABLE  DMAC_CONFB0_RD /*!< 传输完成后目标地址重载 */
/**
 * @}
 */

/** @defgroup DMA_Auto_Disable_SEL DMA传输完成后关闭/保持选择
 * @{
 */
#define DMA_AUTO_DISABLE 0x00000000U     /*!< 传输完成后通道使能自动关闭 */
#define DMA_KEEP_ENABLE  DMAC_CONFB0_MSK /*!< 传输完成后通道使能状态保持 */
/**
 * @}
 */

/** @defgroup DMA_Irq_Type DMA中断类型
 * @{
 */
#define DMA_IRQ_TC DMAC_CONFB0_FIS_IE /*!< DMA通道传输完成中断 */
#define DMA_IRQ_TE DMAC_CONFB0_ERR_IE /*!< DMA通道传输错误中断 */
/**
 * @}
 */

/** @defgroup DMA_Status DMA标志位
 * @{
 */
#define DMA_STATUS_ADDR_OVER          (0x01U << DMAC_CONFB0_STAT_Pos) /*!< 传输错误， 传输地址超出寻址范围 */
#define DMA_STATUS_PERIPHERAL_SUSPEND (0x02U << DMAC_CONFB0_STAT_Pos) /*!< 传输错误， 外设请求停止DMA */
#define DMA_STATUS_SRCADDR_ERR        (0x03U << DMAC_CONFB0_STAT_Pos) /*!< 传输错误， 访问传输来源地址出错 */
#define DMA_STATUS_DSTADDR_ERR        (0x04U << DMAC_CONFB0_STAT_Pos) /*!< 传输错误， 访问传输目的地址出错 */
#define DMA_STATUS_FINISHED           (0x05U << DMAC_CONFB0_STAT_Pos) /*!< 传输完成 */
#define DMA_STATUS_PAUSE              (0x07U << DMAC_CONFB0_STAT_Pos) /*!< 传输暂停 */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
  Global function prototypes (definition in C source)
 ******************************************************************************/
/**
 * @addtogroup DMAC_Global_Functions DMAC全局函数定义
 * @{
 */
en_result_t DMACCH_Init(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id, stc_dmac_channel_init_t* pstcDmacChInit);
void        DMAC_Enable(void);
void        DMAC_Disable(void);
void        DMAC_Pause(void);
void        DMAC_PRIO_FIX(void);
void        DMAC_PRIO_LOOP(void);
void        DMAC_Resume(void);
void        DMACCH_Enable(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_Disable(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_Soft_Start(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_Soft_Stop(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_Pause(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_Resume(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_EnableIrq(DMAC_TypeDef* pstcDmacChx, uint32_t u32IrqType, en_dma_channel_t channel_id);
void        DMACCH_DisableIrq(DMAC_TypeDef* pstcDmacChx, uint32_t u32IrqType, en_dma_channel_t channel_id);
uint32_t    DMACCH_GetStatus(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);
void        DMACCH_ClrStatus(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id);

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __DMA_H__ */
/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
