/**
 *******************************************************************************
 * @file  adc.h
 * @brief This file contains all the functions prototypes of the ADC driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2023-12-18       MADS            Delete ADC_Channel_Mux18_VREF_1p2
   2024-12-23       MADS            Modify comments etc.
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

#ifndef __ADC_H__
#define __ADC_H__

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "ddl.h"

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @addtogroup DDL_ADC ADC子模块驱动库
 * @{
 */

/*******************************************************************************
 * Sysctrl pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup ADC_Global_Macros ADC全局宏定义
 * @{
 */

/** @defgroup ADC_BGR_CONFIG  ADC模拟器件配置
 * @{
 */
#define ADC_TS_ENABLE   ADC_BGR_TSEN
#define ADC_TS_DISABLE  ((uint32_t)0x00000000)
#define ADC_BGR_ENABLE  ADC_BGR_BGREN
#define ADC_BGR_DISABLE ((uint32_t)0x00000000)
/**
 * @}
 */

/** @defgroup ADC_SAMPLINGTIME_CYCLE_SELECTION  ADC采样周期选择
 * @{
 */
#define ADC_SAMPLINGTIME_3CYCLE  (((uint32_t)0x00000000) << ADC_CR0_SAM_Pos)
#define ADC_SAMPLINGTIME_6CYCLE  (((uint32_t)0x00000001) << ADC_CR0_SAM_Pos)
#define ADC_SAMPLINGTIME_9CYCLE  (((uint32_t)0x00000002) << ADC_CR0_SAM_Pos)
#define ADC_SAMPLINGTIME_10CYCLE (((uint32_t)0x00000003) << ADC_CR0_SAM_Pos)
/**
 * @}
 */

/** @defgroup ADC_BUFF  ADC 输入信号放大器配置
 * @{
 */
#define ADC_BUFF_ENABLE  ADC_CR0_BUF
#define ADC_BUFF_DISABLE ((uint32_t)0x00000000)
/**
 * @}
 */

/** @defgroup ADC_REF_VOLTAGE_SELECTION  ADC 参考电压选择
 * @{
 */
#define ADC_REF_VOLTAGE_IN_1p5 (((uint32_t)0x00000000) << ADC_CR0_REF_Pos) /*!< 内部1.5V                */
#define ADC_REF_VOLTAGE_IN_2p5 (((uint32_t)0x00000001) << ADC_CR0_REF_Pos) /*!< 内部2.5V                */
#define ADC_REF_VOLTAGE_EXREF  (((uint32_t)0x00000002) << ADC_CR0_REF_Pos) /*!< 外部参考电压ExRef(PB01) */
#define ADC_REF_VOLTAGE_AVCC   (((uint32_t)0x00000003) << ADC_CR0_REF_Pos) /*!< AVCC电压                */
/**
 * @}
 */

/** @defgroup ADC_SGLMUX_SELECTION  ADC通道输入信号选择
 * @{
 */
#define ADC_Channel_Mux0_PA00       ((uint32_t)0x00000000)
#define ADC_Channel_Mux1_PA01       ((uint32_t)0x00000001)
#define ADC_Channel_Mux2_PA02       ((uint32_t)0x00000002)
#define ADC_Channel_Mux3_PA03       ((uint32_t)0x00000003)
#define ADC_Channel_Mux4_PA04       ((uint32_t)0x00000004)
#define ADC_Channel_Mux5_PA05       ((uint32_t)0x00000005)
#define ADC_Channel_Mux6_PA06       ((uint32_t)0x00000006)
#define ADC_Channel_Mux7_PA07       ((uint32_t)0x00000007)
#define ADC_Channel_Mux8_PB00       ((uint32_t)0x00000008)
#define ADC_Channel_Mux9_PB01       ((uint32_t)0x00000009)
#define ADC_Channel_Mux10_PC00      ((uint32_t)0x0000000A)
#define ADC_Channel_Mux11_PC01      ((uint32_t)0x0000000B)
#define ADC_Channel_Mux12_PC02      ((uint32_t)0x0000000C)
#define ADC_Channel_Mux13_PC03      ((uint32_t)0x0000000D)
#define ADC_Channel_Mux14_PC04      ((uint32_t)0x0000000E)
#define ADC_Channel_Mux15_PC05      ((uint32_t)0x0000000F)
#define ADC_Channel_Mux16_AVCC_DIV3 ((uint32_t)0x00000010)
#define ADC_Channel_Mux17_AI_TS     ((uint32_t)0x00000011)

/**
 * @}
 */

/** @defgroup ADC_CLOCK_SELECTION  ADC 时钟选择
 * @{
 */
#define ADC_CLOCK_PCLK_DIV1  (((uint32_t)0x00000000) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV4  (((uint32_t)0x00000001) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV6  (((uint32_t)0x00000002) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV8  (((uint32_t)0x00000003) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV10 (((uint32_t)0x00000004) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV12 (((uint32_t)0x00000005) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV14 (((uint32_t)0x00000006) << ADC_CR0_CKDIV_Pos)
#define ADC_CLOCK_PCLK_DIV16 (((uint32_t)0x00000007) << ADC_CR0_CKDIV_Pos)
/**
 * @}
 */

/** @defgroup ADC_ONOFF  ADC模块使能控制
 * @{
 */
#define ADC_ENABLE  ADC_CR0_EN
#define ADC_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_RACCCLR  ADC转换结果累加清零
 * @{
 */
#define ADC_RACCCLR_ENABLE  ADC_CR1_RACCEN
#define ADC_RACCCLR_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_REGCMP  ADC区间比较控制
 * @{
 */
#define ADC_REGCMP_ENABLE  ADC_CR1_REGCMP
#define ADC_REGCMP_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_HTCMP  ADC高阈值比较控制
 * @{
 */
#define ADC_HTCMP_ENABLE  ADC_CR1_HTCMP
#define ADC_HTCMP_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_LTCMP  ADC低阈值比较控制
 * @{
 */
#define ADC_LTCMP_ENABLE  ADC_CR1_LTCMP
#define ADC_LTCMP_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_RACCEN  ADC转换结果自动累加控制
 * @{
 */
#define ADC_RACCEN_ENABLE  ADC_CR1_RACCEN
#define ADC_RACCEN_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_OVMD  ADC过转换结果控制
 * @{
 */
#define ADC_OVMD_ENABLE  ADC_CR1_OVMD
#define ADC_OVMD_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_THRESHOLD_CHANNEL_SELECTION  ADC阈值比较通道选择
 * @{
 */
#define ADC_THRESHOLD_CHANNEL_0  (((uint32_t)0x00000000) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_1  (((uint32_t)0x00000001) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_2  (((uint32_t)0x00000002) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_3  (((uint32_t)0x00000003) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_4  (((uint32_t)0x00000004) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_5  (((uint32_t)0x00000005) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_6  (((uint32_t)0x00000006) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_7  (((uint32_t)0x00000007) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_8  (((uint32_t)0x00000008) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_9  (((uint32_t)0x00000009) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_10 (((uint32_t)0x0000000A) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_11 (((uint32_t)0x0000000B) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_12 (((uint32_t)0x0000000C) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_13 (((uint32_t)0x0000000D) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_14 (((uint32_t)0x0000000E) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_15 (((uint32_t)0x0000000F) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_16 (((uint32_t)0x00000010) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_17 (((uint32_t)0x00000011) << ADC_CR1_THCH_Pos)
#define ADC_THRESHOLD_CHANNEL_18 (((uint32_t)0x00000012) << ADC_CR1_THCH_Pos)
/**
 * @}
 */

/** @defgroup ADC_ALIGN  ADC转换结果对齐控制
 * @{
 */
#define ADC_LEFT_ALIGN_ENABLE  ADC_CR1_ALIGN
#define ADC_RIGHT_ALIGN_ENABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_CONVERSION_MODE  ADC转换模式选择
 * @{
 */
#define ADC_CONVERSION_MODE_SINGLE        (((uint32_t)0x00000000) << ADC_CR1_MODE_Pos) /*!< 单次转换，一次转换所有已配置的通道          */
#define ADC_CONVERSION_MODE_SQR_SINGLE    (((uint32_t)0x00000001) << ADC_CR1_MODE_Pos) /*!< 连续转换，循环依次转换所有已配置的通道,单次 */
#define ADC_CONVERSION_MODE_CONTINUOUS    (((uint32_t)0x00000002) << ADC_CR1_MODE_Pos) /*!< 连续转换，循环依次转换所有已配置的通道,循环 */
#define ADC_CONVERSION_MODE_DISCONTINUOUS (((uint32_t)0x00000003) << ADC_CR1_MODE_Pos) /*!< 非连续转换，一次只转换一个通道              */
/**
 * @}
 */

/** @defgroup ADC_SQR_CHANNEL_SELECTION  ADC顺序转换通道选择
 * @{
 */
#define ADC_SQRCH0MUX  (0x00000000U)
#define ADC_SQRCH1MUX  (0x00000001U)
#define ADC_SQRCH2MUX  (0x00000002U)
#define ADC_SQRCH3MUX  (0x00000003U)
#define ADC_SQRCH4MUX  (0x00000004U)
#define ADC_SQRCH5MUX  (0x00000005U)
#define ADC_SQRCH6MUX  (0x00000006U)
#define ADC_SQRCH7MUX  (0x00000007U)
#define ADC_SQRCH8MUX  (0x00000008U)
#define ADC_SQRCH9MUX  (0x00000009U)
#define ADC_SQRCH10MUX (0x0000000AU)
#define ADC_SQRCH11MUX (0x0000000BU)
#define ADC_SQRCH12MUX (0x0000000CU)
#define ADC_SQRCH13MUX (0x0000000DU)
#define ADC_SQRCH14MUX (0x0000000EU)
#define ADC_SQRCH15MUX (0x0000000FU)
/**
 * @}
 */

/** @defgroup ADC_FLAG_SELECTION  ADC中断标记选择
 * @{
 */
#define ADC_FLAG_OV   (ADC_IFR_OV)  /*!< ADC结果被读取前又有一次数据结果被存储标志                            */
#define ADC_FLAG_EOC  (ADC_IFR_EOC) /*!< ADC一次转换完成标志，转换完成 产生标志                               */
#define ADC_FLAG_EOS  (ADC_IFR_EOS) /*!< ADC顺序序列转换完成标志，转换完成 产生标志                           */
#define ADC_FLAG_REGI (ADC_IFR_RGI) /*!< ADC转换结果比较区间标志，转换结果位于[ADC_LT, ADC_HT]区间内 产生标志 */
#define ADC_FLAG_HTI  (ADC_IFR_HTI) /*!< ADC转换结果比较上阈值标志，转换结果位于[ADC_HT, 4095]区间内 产生标志 */
#define ADC_FLAG_LTI  (ADC_IFR_LTI) /*!< ADC转换结果比较下阈值标志，转换结果位于[0, ADC_LT]区间内 产生标志    */
#define ADC_FLAG_ESG  (ADC_IFR_ESG) /*!< ADC单次转换完成，产生标志                                            */

/**
 * @}
 */

/** @defgroup ADC_CLEAR_SELECTION  ADC中断标记清除选择
 * @{
 */
#define ADC_CLEAR_OV   (ADC_ICR_OV)  /*!< ADC结果被读取前又有一次数据结果被存储标志清除位 */
#define ADC_CLEAR_EOC  (ADC_ICR_EOC) /*!< ADC一次转换完成标志清除位                       */
#define ADC_CLEAR_EOS  (ADC_ICR_EOS) /*!< ADC顺序序列转换完成标志清除位                   */
#define ADC_CLEAR_REGI (ADC_ICR_RGI) /*!< ADC转换结果比较区间标志清除位                   */
#define ADC_CLEAR_HTI  (ADC_ICR_HTI) /*!< ADC转换结果比较上阈值标志清除位                 */
#define ADC_CLEAR_LTI  (ADC_ICR_LTI) /*!< ADC转换结果比较下阈值标志清除位                 */
#define ADC_CLEAR_ESG  (ADC_ICR_ESG) /*!< ADC单次转换中断标志清除位                       */

/**
 * @}
 */

/** @defgroup ADC_IT_SELECTION  ADC中断源选择
 * @{
 */
#define ADC_IT_OV   (ADC_IER_OV)  /*!< ADC结果被读取前又有一次数据结果被存储 产生中断                       */
#define ADC_IT_EOC  (ADC_IER_EOC) /*!< ADC一次转换完成标志，转换完成 产生中断                               */
#define ADC_IT_EOS  (ADC_IER_EOS) /*!< ADC顺序序列转换完成标志，转换完成 产生中断                           */
#define ADC_IT_REGI (ADC_IER_RGI) /*!< ADC转换结果比较区间标志，转换结果位于[ADC_LT, ADC_HT]区间内 产生中断 */
#define ADC_IT_HTI  (ADC_IER_HTI) /*!< ADC转换结果比较上阈值标志，转换结果位于[ADC_HT, 4095]区间内 产生中断 */
#define ADC_IT_LTI  (ADC_IER_LTI) /*!< ADC转换结果比较下阈值标志，转换结果位于[0, ADC_LT]区间内 产生中断    */
#define ADC_IT_ESG  (ADC_IER_ESG) /*!< ADC单次转换中断使能产生中断                                          */

/**
 * @}
 */

/** @defgroup ADC_TRIGGER_SRC_SELECT  ADC触发信号选择
 * @{
 */
#define ADCMSKTRIGSOFT    ((uint32_t)0x00000000) /*!<选择软件触发ADC采样                */
#define ADCMSKTRIGATIMER0 ((uint32_t)0x00000001) /*!<选择Atimer0中断源，自动触发ADC采样 */
#define ADCMSKTRIGATIMER3 ((uint32_t)0x00000002) /*!<选择Atimer3中断源，自动触发ADC采样 */
#define ADCMSKTRIGGTIMER0 ((uint32_t)0x00000003) /*!<选择Gtimer0中断源，自动触发ADC采样 */
#define ADCMSKTRIGGTIMER1 ((uint32_t)0x00000004) /*!<选择Gtimer1中断源，自动触发ADC采样 */
#define ADCMSKTRIGGTIMER2 ((uint32_t)0x00000005) /*!<选择Gtimer2中断源，自动触发ADC采样 */
#define ADCMSKTRIGUSART0  ((uint32_t)0x00000006) /*!<选择uart0中断源，自动触发ADC采样   */
#define ADCMSKTRIGUSART1  ((uint32_t)0x00000007) /*!<选择uart1中断源，自动触发ADC采样   */
#define ADCMSKTRIGUSART2  ((uint32_t)0x00000008) /*!<选择uart2中断源，自动触发ADC采样   */
#define ADCMSKTRIGUSART3  ((uint32_t)0x00000009) /*!<选择uart3中断源，自动触发ADC采样   */
#define ADCMSKTRIGSPI0    ((uint32_t)0x0000000A) /*!<选择SPI0中断源，自动触发ADC采样    */
#define ADCMSKTRIGSPI1    ((uint32_t)0x0000000B) /*!<选择SPI1中断源，自动触发ADC采样    */
#define ADCMSKTRIGDMA     ((uint32_t)0x0000000C) /*!<选择DMA中断源，自动触发ADC采样     */
#define ADCMSKTRIGVC0     ((uint32_t)0x0000000D) /*!<选择VC0中断源，自动触发ADC采样     */
#define ADCMSKTRIGVC1     ((uint32_t)0x0000000E) /*!<选择VC1中断源，自动触发ADC采样     */
#define ADCMSKTRIGLVD     ((uint32_t)0x0000000F) /*!<选择LVD中断源，自动触发ADC采样     */
#define ADCMSKTRIGPA01    ((uint32_t)0x00000010) /*!<选择PA01中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB01    ((uint32_t)0x00000011) /*!<选择PB01中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA03    ((uint32_t)0x00000012) /*!<选择PA03中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB03    ((uint32_t)0x00000013) /*!<选择PB03中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA05    ((uint32_t)0x00000014) /*!<选择PA05中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB05    ((uint32_t)0x00000015) /*!<选择PB05中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA07    ((uint32_t)0x00000016) /*!<选择PA07中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB07    ((uint32_t)0x00000017) /*!<选择PB07中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA09    ((uint32_t)0x00000018) /*!<选择PA09中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB09    ((uint32_t)0x00000019) /*!<选择PB09中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA11    ((uint32_t)0x0000001A) /*!<选择PA11中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB11    ((uint32_t)0x0000001B) /*!<选择PB11中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA13    ((uint32_t)0x0000001C) /*!<选择PA13中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB13    ((uint32_t)0x0000001D) /*!<选择PB13中断源，自动触发ADC采样    */
#define ADCMSKTRIGPA15    ((uint32_t)0x0000001E) /*!<选择PA15中断源，自动触发ADC采样    */
#define ADCMSKTRIGPB15    ((uint32_t)0x0000001F) /*!<选择PB15中断源，自动触发ADC采样    */

/**
 * @}
 */

/** @defgroup ADC_TRIGGER_DELAY_SELECT  ADC 触发延时控制
 * @{
 */
#define ADCTRIG_GTIM   ADC_EXTTRIGGER0_DELAY
#define ADCTRIG_DIRECT ((uint32_t)0x00000000U)

/**
 * @}
 */

/** @defgroup ADC_DEOC  ADC插队转换完成触发DMA
 * @{
 */
#define ADC_DEOC_ENABLE  ADC_IER_DEOC
#define ADC_DEOC_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_SGL_START  ADC单次转换启动控制
 * @{
 */
#define ADC_SGLSTART_START_ENABLE  ADC_SGLSTART_START
#define ADC_SGLSTART_START_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/** @defgroup ADC_SQR_START  ADC顺序扫描转换启动控制
 * @{
 */
#define ADC_SQRSTART_START_ENABLE  ADC_SQRSTART_START
#define ADC_SQRSTART_START_DISABLE ((uint32_t)0x00000000U)
/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 ** Global type definitions
 *****************************************************************************/
/**
 * @defgroup ADC_Global_Types ADC全局类型定义
 * @{
 */

/**
 * @brief ADC初始化配置结构体
 */
typedef struct
{
    uint32_t AdcSampCycleSel; /*!< ADC采样周期选择 */
    uint32_t AdcOpBuf;        /*!< ADC输入信号放大器控制使能 */
    uint32_t AdcRefVolSel;    /*!< ADC参考电压选择 */
    uint32_t AdcClkDiv;       /*!< ADC时钟选择 */
    uint32_t RaccEn;          /*!< ADC转换结果自动累加功能 */
    uint32_t OvMode;          /*!< ADC过转换时Adc_Result存储方式 */
    uint32_t AdcAlign;        /*!< ADC转换结果对齐控制 */
    uint32_t AdcMode;         /*!< ADC转换模式 */
} stc_adc_cfg_t;

/**
 * @brief  ADC比较功能配置结构体
 */
typedef struct
{
    uint32_t bAdcRegCmp;    /*!< ADC区间使能 @ref ADC_REGCMP */
    uint32_t bAdcHtCmp;     /*!< ADC上超出区间使能 @ref ADC_HTCMP */
    uint32_t bAdcLtCmp;     /*!< ADC下超出区间使能 @ref ADC_LTCMP */
    uint32_t u32AdcHighThd; /*!< ADC比较上阈值 */
    uint32_t u32AdcLowThd;  /*!< ADC比较下阈值 */
    uint32_t SampChSel;     /*!< ADC采样通道选择 @ref ADC_THRESHOLD_CHANNEL_SELECTION */
} stc_adc_threshold_cfg_t;

/**
 * @}
 */

/******************************************************************************
 ** Global type definitions
 *****************************************************************************/

/******************************************************************************
 * Global variable definitions ('extern')
 ******************************************************************************/

/******************************************************************************
 * Global function prototypes (definition in C source)
 ******************************************************************************/
/**
 * @addtogroup ADC_Global_Functions ADC全局函数定义
 * @{
 */
en_result_t ADC_Init(ADC_TypeDef* ADCx, stc_adc_cfg_t* pstcAdcCfg);
void        ADC_Threshold_Cmp_Cfg(ADC_TypeDef* ADCx, stc_adc_threshold_cfg_t* adc_th_cfg);
void        ADC_TS_Enable(ADC_TypeDef* ADCx);
void        ADC_TS_Disable(ADC_TypeDef* ADCx);
uint32_t    ADC_IsEnable_TS(ADC_TypeDef* ADCx);
void        ADC_BGR_Enable(ADC_TypeDef* ADCx);
void        ADC_BGR_Disable(ADC_TypeDef* ADCx);
uint32_t    ADC_IsEnable_BGR(ADC_TypeDef* ADCx);
void        ADC_Enable(ADC_TypeDef* ADCx);
void        ADC_Disable(ADC_TypeDef* ADCx);
uint32_t    ADC_IsEnable(ADC_TypeDef* ADCx);
void        ADC_SetClockDiv(ADC_TypeDef* ADCx, uint32_t u32ClockDiv);
uint32_t    ADC_GetClockDiv(ADC_TypeDef* ADCx);
void        ADC_SetSglMux(ADC_TypeDef* ADCx, uint32_t u32sglmux);
uint32_t    ADC_GetSglMux(ADC_TypeDef* ADCx);
void        ADC_SetRefVol(ADC_TypeDef* ADCx, uint32_t u32RefVol);
uint32_t    ADC_GetRefVol(ADC_TypeDef* ADCx);
void        ADC_EnableBuf(ADC_TypeDef* ADCx);
void        ADC_DisableBuf(ADC_TypeDef* ADCx);
uint32_t    ADC_IsEnableBuf(ADC_TypeDef* ADCx);
void        ADC_SetSampCycle(ADC_TypeDef* ADCx, uint32_t u32SampCycle);
uint32_t    ADC_GetSampCycle(ADC_TypeDef* ADCx);
void        ADC_SetThresholdCh(ADC_TypeDef* ADCx, uint32_t u32ThresholdCh);
void        ADC_SetThresholdCompare(ADC_TypeDef* ADCx, uint32_t u32ThresholdCompare);
uint32_t    ADC_GetThresholdCompare(ADC_TypeDef* ADCx);
uint32_t    ADC_GetThresholdCh(ADC_TypeDef* ADCx);
void        ADC_SetConversionMode(ADC_TypeDef* ADCx, uint32_t u32ConversionMode);
uint32_t    ADC_GetConversionMode(ADC_TypeDef* ADCx);
void        ADC_SetDataAlignment(ADC_TypeDef* ADCx, uint32_t u32DataAlignment);
uint32_t    ADC_GetDataAlignment(ADC_TypeDef* ADCx);
void        ADC_SetRegOverrun(ADC_TypeDef* ADCx, uint32_t u32Overrun);
uint32_t    ADC_GetRegOverrun(ADC_TypeDef* ADCx);
void        ADC_EnableResultAcc(ADC_TypeDef* ADCx);
void        ADC_DisableResultAcc(ADC_TypeDef* ADCx);
uint32_t    ADC_IsEnableResultAcc(ADC_TypeDef* ADCx);
void        ADC_ClearResultAccReg(ADC_TypeDef* ADCx);
void        ADC_SetChannelInputSource(ADC_TypeDef* ADCx, uint32_t sqr_u32Channel_num, uint32_t u32AdcSampInput);
uint32_t    ADC_GetChannelInputSource(ADC_TypeDef* ADCx, uint32_t sqr_u32Channel_num);
void        ADC_Set_SQR_ChCnt(ADC_TypeDef* ADCx, uint32_t u32ChCnt);
uint32_t    ADC_Get_SQR_ChCnt(ADC_TypeDef* ADCx);
uint32_t    ADC_GetResult(ADC_TypeDef* ADCx);
uint32_t    ADC_GetResultAcc(ADC_TypeDef* ADCx);
void        ADC_SetHighThreshold(ADC_TypeDef* ADCx, uint32_t u32HighThreshold);
uint32_t    ADC_GetHighThreshold(ADC_TypeDef* ADCx);
void        ADC_SetLowThreshold(ADC_TypeDef* ADCx, uint32_t u32LowThreshold);
uint32_t    ADC_GetLowThreshold(ADC_TypeDef* ADCx);
void        ADC_EnableIT(ADC_TypeDef* ADCx, uint32_t u32IT);
void        ADC_DisableIT(ADC_TypeDef* ADCx, uint32_t u32IT);
uint32_t    ADC_IsEnableIT(ADC_TypeDef* ADCx, uint32_t u32IT);
void        ADC_Enable_EOC_DMATransfer(ADC_TypeDef* ADCx);
void        ADC_Disable_EOC_DMATransfer(ADC_TypeDef* ADCx);
uint32_t    ADC_IsEnable_EOC_DMATransfer(ADC_TypeDef* ADCx);
uint32_t    ADC_IsActiveFlag(ADC_TypeDef* ADCx, uint32_t u32ITFlag);
void        ADC_ClearFlag(ADC_TypeDef* ADCx, uint32_t u32ITFlag);
void        ADC_ClearFlag_ALL(ADC_TypeDef* ADCx);
void        ADC_SetExtTrigger0Source(ADC_TypeDef* ADCx, uint32_t u32ExtTriggerSource);
uint32_t    ADC_GetExtTrigger0Source(ADC_TypeDef* ADCx);
void        ADC_SetExtTrigger0_Delay_Sel(ADC_TypeDef* ADCx, uint32_t u32Delaysel);
uint32_t    ADC_GetExtTrigger0_Delay_Cfg(ADC_TypeDef* ADCx);
void        ADC_Sgl_SoftStart(ADC_TypeDef* ADCx);
void        ADC_Sqr_SoftStart(ADC_TypeDef* ADCx);
void        ADC_Sgl_SoftStop(ADC_TypeDef* ADCx);
void        ADC_Sqr_SoftStop(ADC_TypeDef* ADCx);
uint32_t    ADC_Sgl_IsConversionOngoing(ADC_TypeDef* ADCx);
uint32_t    ADC_Sqr_IsConversionOngoing(ADC_TypeDef* ADCx);

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __ADC_H__ */
/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
