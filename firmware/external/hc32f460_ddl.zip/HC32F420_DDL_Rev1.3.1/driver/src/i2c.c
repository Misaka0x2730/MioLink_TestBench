/**
 *******************************************************************************
 * @file  i2c.c
 * @brief This file provides firmware functions to manage the I2C.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "i2c.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_I2C I2C子模块驱动库
 * @brief I2C Driver Library I2C子模块驱动库
 * @{
 */

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup I2C_Global_Functions I2C全局函数定义
 * @{
 */

/**
 * @brief  I2C 主机初始化
 * @param  [in] I2Cx:              I2C类型定义               @ref I2C_TypeDef
 * @param  [in] pstcMasterInitCfg: I2C主机初始化结构体       @ref stc_i2c_master_init_cfg_t
 * @retval en_result_t
 *         - Ok:             OK
 */
en_result_t I2C_MasterInit(I2C_TypeDef* I2Cx, stc_i2c_master_init_cfg_t* pstcMasterInitCfg)
{
    uint8_t u8BRR;

    I2Cx->CR = 0;

    if ((pstcMasterInitCfg->u32BaudRate > (pstcMasterInitCfg->u32Pclk >> 4)) || (pstcMasterInitCfg->u32BaudRate < (pstcMasterInitCfg->u32Pclk >> 11)))
    {
        return Error;
    }

    /* Fscl = Fpclk/8*(BRR+1) */
    u8BRR     = ((pstcMasterInitCfg->u32Pclk / pstcMasterInitCfg->u32BaudRate) >> 3) - 1;
    I2Cx->BRR = u8BRR;
    if (9 >= u8BRR)
    {
        I2Cx->CR |= I2C_CR_FLT; /* 使用简单滤波，以适应更快的通信速率 */
    }

    I2Cx->BRREN |= I2C_BRREN_EN; /* 使能波特率发生器 */
    return Ok;
}

/**
 * @brief  I2C 从机初始化
 * @param  [in] I2Cx:             I2C类型定义               @ref I2C_TypeDef
 * @param  [in] pstcSlaveInitCfg: I2C从机初始化结构体       @ref stc_i2c_slave_init_cfg_t
 * @retval en_result_t
 *         - Ok:             OK
 */
en_result_t I2C_SlaveInit(I2C_TypeDef* I2Cx, stc_i2c_slave_init_cfg_t* pstcSlaveInitCfg)
{
    I2Cx->CR = 0;

    I2Cx->BRREN = 0; /* 禁止波特率发生器 */

    I2Cx->ADDR0 = ((uint32_t)pstcSlaveInitCfg->u8SlaveAddr0 << 1) | (pstcSlaveInitCfg->u32BroadcastEn);
    I2Cx->ADDR1 = ((uint32_t)pstcSlaveInitCfg->u8SlaveAddr1 << 1);
    I2Cx->ADDR2 = ((uint32_t)pstcSlaveInitCfg->u8SlaveAddr2 << 1);

    /* pclk与scl频率比值小于等于30时置1，否则置0 */
    REG_MODIFY(I2Cx->CR, I2C_CR_FLT, pstcSlaveInitCfg->u32Filter);

    return Ok;
}

/**
 * @brief  I2C 波特率发生器使能
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_EnableBaud(I2C_TypeDef* I2Cx)
{
    REG_SETBITS(I2Cx->BRREN, I2C_BRREN_EN);
}

/**
 * @brief  I2C 波特率发生器禁止
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_DisableBaud(I2C_TypeDef* I2Cx)
{
    REG_CLEARBITS(I2Cx->BRREN, I2C_BRREN_EN);
}

/**
 * @brief  I2C 波特率发生器是否开启
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t：
 *         - 0:   未开启
 *         - 非0: 已开启
 */
uint32_t I2C_IsEnableBaud(I2C_TypeDef* I2Cx)
{
    return (REG_READBITS(I2Cx->BRREN, I2C_BRREN_EN) == I2C_BRREN_EN);
}

/**
 * @brief  I2C 设置波特率配置寄存器
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Baud: 波特率配置值
 * @retval None
 */
void I2C_SetBaud(I2C_TypeDef* I2Cx, uint32_t u32Baud)
{
    REG_MODIFY(I2Cx->BRR, I2C_BRR_BRR, u32Baud);
}

/**
 * @brief  I2C 获取波特率配置寄存器的值
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Baud: 波特率配置值
 * @retval uint32_t：    I2C 波特率配置寄存器的值
 */
uint32_t I2C_GetBaud(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->BRR, I2C_BRR_BRR));
}

/**
 * @brief  I2C 滤波参数设置，作为主机I2C_BRR值大于9，或者作为从机PCLK与SCL频率比值大于30时，建议使用I2C_FILTER_ADVANCE
 * @param  [in] I2Cx:      I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Filter: 滤波参数
 *         - I2C_FILTER_ADVANCE     更高的抗干扰性能
 *         - I2C_FILTER_SIMPLE      更快的通信滤波
 * @retval None
 */
void I2C_SetFilter(I2C_TypeDef* I2Cx, uint32_t u32Filter)
{
    REG_MODIFY(I2Cx->CR, I2C_CR_FLT, u32Filter);
}

/**
 * @brief  I2C 获取滤波参数
 * @param  [in] I2Cx:     I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t:      滤波参数
 *         - I2C_FILTER_ADVANCE     更高的抗干扰性能
 *         - I2C_FILTER_SIMPLE      更快的通信滤波
 */
uint32_t I2C_GetFilter(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->CR, I2C_CR_FLT));
}

/**
 * @brief  I2C 获取中断状态标志
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t:     中断标志
 *         - 0     未发生I2C中断
 *         - 1     已发生I2C中断
 */
uint32_t I2C_IsActiveFlag_SI(I2C_TypeDef* I2Cx)
{
    return (REG_READBITS(I2Cx->CR, I2C_CR_SI) == I2C_CR_SI);
}

/**
 * @brief  I2C 清除中断状态标志
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_ClearFlag_SI(I2C_TypeDef* I2Cx)
{
    REG_CLEARBITS(I2Cx->CR, I2C_CR_SI);
}

/**
 * @brief  I2C 设置应答控制
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Ack: 应答控制
 *         - I2C_NACK     在应答阶段发送ACK
 *         - I2C_ACK      在应答阶段发送NAK
 * @retval None
 */
void I2C_SetAck(I2C_TypeDef* I2Cx, uint32_t u32Ack)
{
    REG_MODIFY(I2Cx->CR, I2C_CR_AA, u32Ack);
}

/**
 * @brief  I2C 获取应答控制
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t:     I2C应答配置
 *         - I2C_NACK    在应答阶段发送ACK
 *         - I2C_ACK     在应答阶段发送NAK
 */
uint32_t I2C_GetAck(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->CR, I2C_CR_AA));
}

/**
 * @brief  I2C 总线状态控制 发送STOP
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Stop: 是否发送STOP
 *         - I2C_STOP_DISABLE     不发送STOP
 *         - I2C_STOP_ENABLE      发送STOP
 * @retval None
 */
void I2C_SetStop(I2C_TypeDef* I2Cx, uint32_t u32Stop)
{
    REG_MODIFY(I2Cx->CR, I2C_CR_STO, u32Stop);
}

/**
 * @brief  I2C 总线状态控制 获取STOP位状态
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t: STOP位状态
 *         - I2C_STOP_DISABLE     无功能
 *         - I2C_STOP_ENABLE      已发送STOP
 */
uint32_t I2C_GetStop(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->CR, I2C_CR_STO));
}

/**
 * @brief  I2C 总线状态控制 发送START
 * @param  [in] I2Cx:     I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Start: 是否发送START
 *         - I2C_START_DISABLE     不发送START
 *         - I2C_START_ENABLE      发送START
 * @retval None
 */
void I2C_SetStart(I2C_TypeDef* I2Cx, uint32_t u32Start)
{
    REG_MODIFY(I2Cx->CR, I2C_CR_STA, u32Start);
}

/**
 * @brief  I2C 总线状态控制 获取START位状态
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t: START位状态
 *         - I2C_START_DISABLE     无功能
 *         - I2C_START_ENABLE      已发送START
 */
uint32_t I2C_GetStart(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->CR, I2C_CR_STA));
}

/**
 * @brief  I2C 使能模块
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_Enable(I2C_TypeDef* I2Cx)
{
    REG_SETBITS(I2Cx->CR, I2C_CR_EN);
}

/**
 * @brief  I2C 禁止模块
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_Disable(I2C_TypeDef* I2Cx)
{
    REG_CLEARBITS(I2Cx->CR, I2C_CR_EN);
}

/**
 * @brief  I2C 检查模块是否已开启
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t：    开启状态
 *         - 0     未开启
 *         - 1     已开启
 */
uint32_t I2C_IsEnable(I2C_TypeDef* I2Cx)
{
    return (REG_READBITS(I2Cx->CR, I2C_CR_EN) == I2C_CR_EN);
}

/**
 * @brief  I2C 将待发送的数据写入数据寄存器
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u8Data:  8bit数据值
 * @retval None
 */
void I2C_WriteByte(I2C_TypeDef* I2Cx, uint8_t u8Data)
{
    REG_MODIFY(I2Cx->DR, I2C_DR_DR, u8Data);
}

/**
 * @brief  I2C 读取数据寄存器的值
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint8_t：     8bit数据值
 */
uint8_t I2C_ReadByte(I2C_TypeDef* I2Cx)
{
    return (uint8_t)(REG_READBITS(I2Cx->DR, I2C_DR_DR));
}

/**
 * @brief  I2C 获取总线状态
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint8_t：     I2C总线状态码 状态码的具体定义详见手册
 */
uint8_t I2C_GetBusState(I2C_TypeDef* I2Cx)
{
    return (uint8_t)(REG_READBITS(I2Cx->STAT, I2C_STAT_STAT));
}

/**
 * @brief  I2C 使能广播地址应答
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_EnableBroadcast(I2C_TypeDef* I2Cx)
{
    REG_SETBITS(I2Cx->ADDR0, I2C_ADDR0_GC);
}

/**
 * @brief  I2C 禁止广播地址应答
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval None
 */
void I2C_DisableBroadcast(I2C_TypeDef* I2Cx)
{
    REG_CLEARBITS(I2Cx->ADDR0, I2C_ADDR0_GC);
}

/**
 * @brief  I2C 检查广播地址应答是否已开启
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t：
 *         - 0     未开启
 *         - 1     已开启
 */
uint32_t I2C_IsEnableBroadcast(I2C_TypeDef* I2Cx)
{
    return (REG_READBITS(I2Cx->ADDR0, I2C_ADDR0_GC) == I2C_ADDR0_GC);
}

/**
 * @brief  I2C 设置从机地址0
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Addr: 地址值
 * @retval None
 */
void I2C_SetSlaveAddr0(I2C_TypeDef* I2Cx, uint32_t u32Addr)
{
    REG_MODIFY(I2Cx->ADDR0, I2C_ADDR0_ADDR0, u32Addr);
}

/**
 * @brief  I2C 获取从机地址0
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval u32Addr: 地址值
 */
uint32_t I2C_GetSlaveAddr0(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->ADDR0, I2C_ADDR0_ADDR0));
}

/**
 * @brief  I2C 设置从机地址1
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @param  [in] u32Addr: 地址值
 * @retval None
 */
void I2C_SetSlaveAddr1(I2C_TypeDef* I2Cx, uint32_t u32Addr)
{
    REG_MODIFY(I2Cx->ADDR1, I2C_ADDR1_ADDR, u32Addr);
}

/**
 * @brief  I2C 获取从机地址1
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval u32Addr: 地址值
 */
uint32_t I2C_GetSlaveAddr1(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->ADDR1, I2C_ADDR1_ADDR));
}

/**
 * @brief  I2C 获取从机地址2
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval u32Addr: 地址值
 */
void I2C_SetSlaveAddr2(I2C_TypeDef* I2Cx, uint32_t u32Addr)
{
    REG_MODIFY(I2Cx->ADDR2, I2C_ADDR2_ADDR, u32Addr);
}

/**
 * @brief  I2C 获取从机地址2
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval u32Addr: 地址值
 */
uint32_t I2C_GetSlaveAddr2(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->ADDR2, I2C_ADDR2_ADDR));
}

/**
 * @brief  I2C 获取是哪个从机地址与总线收到的设备地址匹配
 * @param  [in] I2Cx:    I2C类型定义               @ref I2C_TypeDef
 * @retval uint32_t:
 *         - I2C_BUS_ADDR_MATCH_NONE    无从地址与总线上的设备地址匹配
 *         - I2C_BUS_ADDR_MATCH_ADDR0   设备从地址ADDR0与总线上的设备地址匹配
 *         - I2C_BUS_ADDR_MATCH_ADDR1   设备从地址ADDR1与总线上的设备地址匹配
 *         - I2C_BUS_ADDR_MATCH_ADDR2   设备从地址ADDR2与总线上的设备地址匹配
 */
uint32_t I2C_GetBusMatchSlaveAddr(I2C_TypeDef* I2Cx)
{
    return (uint32_t)(REG_READBITS(I2Cx->MATCH, (I2C_MATCH_AD0F | I2C_MATCH_AD1F | I2C_MATCH_AD2F)));
}
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
