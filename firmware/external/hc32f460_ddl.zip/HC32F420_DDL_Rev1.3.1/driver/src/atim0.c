/**
 *******************************************************************************
 * @file  atim0.c
 * @brief This file provides firmware functions to manage the ATIM0.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_ATIM0 ATIM0子模块驱动库
 * @brief ATIM0 Driver Library ATIM0子模块驱动库
 * @{
 */
/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup ATIM0_Global_Functions ATIM0全局函数定义
 * @{
 */

/**
 * @brief  ATIM0 初始化配置(模式0)
 * @param  [in] pstcCfg:        初始化配置结构体指针      @ref stc_atim0_mode0_cfg_t
 * @retval None
 */
void ATIM0_Mode0_Init(stc_atim0_mode0_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE0->M0CR,
        ATIM0MODE0_M0CR_MODE | ATIM0MODE0_M0CR_GATEP | ATIM0MODE0_M0CR_GATE | ATIM0MODE0_M0CR_PRS | ATIM0MODE0_M0CR_TOG
            | ATIM0MODE0_M0CR_CT | ATIM0MODE0_M0CR_MD,
        pstcCfg->u32WorkMode | pstcCfg->u32GatePolar | pstcCfg->u32EnGate | pstcCfg->u32PRS | pstcCfg->u32EnTog
            | pstcCfg->u32CountClkSel | pstcCfg->u32CntMode);
}

/**
 * @brief  ATIM0 启动运行(模式0)
 * @param  None
 * @retval None
 */
void ATIM0_Mode0_Run(void)
{
    REG_SETBITS(HC_ATIM0MODE0->M0CR, ATIM0MODE0_M0CR_CEN);
}

/**
 * @brief  ATIM0 停止运行(模式0)
 * @param  None
 * @retval None
 */
void ATIM0_Mode0_Stop(void)
{
    REG_CLEARBITS(HC_ATIM0MODE0->M0CR, ATIM0MODE0_M0CR_CEN);
}

/**
 * @brief  ATIM0 重载值设置(模式0)
 * @param  [in] u16Data:        16bits重载值
 * @retval None
 */
void ATIM0_Mode0_ARRSet(uint32_t u16Data)
{
    REG_WRITE(HC_ATIM0MODE0->ARR, (u16Data & 0xFFFFu));
}

/**
 * @brief  ATIM0 获取重载值(模式0)
 * @param  None
 * @retval uint32_t: 16bits重载值
 */
uint32_t ATIM0_Mode0_ARRGet(void)
{
    return ((REG_READ(HC_ATIM0MODE0->ARR)) & 0xFFFFu);
}

/**
 * @brief  ATIM0 16位计数器初值设置(模式0)
 * @param  [in] u16Data:        CNT 16位初值
 * @retval None
 */
void ATIM0_Mode0_Cnt16Set(uint32_t u16Data)
{
    REG_WRITE(HC_ATIM0MODE0->CNT, (u16Data & 0xFFFFu));
}

/**
 * @brief  ATIM0 16位计数值获取(模式0)
 * @param  None
 * @retval uint32_t: 16bits计数值
 */
uint32_t ATIM0_Mode0_Cnt16Get(void)
{
    return ((REG_READ(HC_ATIM0MODE0->CNT)) & 0xFFFFu);
}

/**
 * @brief  ATIM0 32位计数器初值设置(模式0)
 * @param  [in] u32Data:        32位初值
 * @retval None
 */
void ATIM0_Mode0_Cnt32Set(uint32_t u32Data)
{
    REG_WRITE(HC_ATIM0MODE0->CNT32, u32Data);
}

/**
 * @brief  ATIM0 32位计数值获取(模式0)
 * @param  None
 * @retval uint32_t: 32bits计数值
 */
uint32_t ATIM0_Mode0_Cnt32Get(void)
{
    return (REG_READ(HC_ATIM0MODE0->CNT32));
}

/**
 * @brief  ATIM0 端口输出使能/禁止设定(模式0)
 * @param  [in] bEnOutput:        翻转输出设定 TRUE:使能, FALSE:禁止
 * @retval None
 */
void ATIM0_Mode0_Enable_Output(boolean_t bEnOutput)
{
    REG_MODIFY(HC_ATIM0MODE0->DTR, ATIM0MODE0_DTR_MO, (uint32_t)bEnOutput << ATIM0MODE0_DTR_MO_Pos);
}

/**
 * @brief  ATIM0 翻转使能/禁止（低电平）设定(模式0)
 * @param  [in] bEnTOG:        翻转输出设定 TRUE:使能, FALSE:禁止
 * @retval None
 */
void ATIM0_Mode0_Enable_TOG(boolean_t bEnTOG)
{
    REG_MODIFY(HC_ATIM0MODE0->M0CR, ATIM0MODE0_M0CR_TOG, (uint32_t)bEnTOG << ATIM0MODE0_M0CR_TOG_Pos);
}

/**
 * @brief  ATIM0 初始化配置(模式1)
 * @param  [in] pstcCfg:        初始化配置结构体指针 @ref stc_atim0_mode1_cfg_t
 * @retval None
 */
void ATIM0_Mode1_Init(stc_atim0_mode1_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE1->M1CR,
        ATIM0MODE1_M1CR_MODE | ATIM0MODE1_M1CR_PRS | ATIM0MODE1_M1CR_CT | ATIM0MODE1_M1CR_ONESHOT,
        pstcCfg->u32WorkMode | pstcCfg->u32PRS | pstcCfg->u32CountClkSel | pstcCfg->u32ShotMode);
}

/**
 * @brief  ATIM0 PWC 输入配置(模式1)
 * @param  [in] pstcCfg:        初始化配置结构体指针 @ref stc_atim0_pwc_input_cfg_t
 * @retval None
 */
void ATIM0_Mode1_Input_Cfg(stc_atim0_pwc_input_cfg_t* pstcCfg)
{
    volatile ATIM0MODE1_TypeDef* pstcAtim = (ATIM0MODE1_TypeDef*)(HC_ATIM0MODE1);

    REG_MODIFY(HC_ATIM0MODE1->MSCR, ATIM0MODE1_MSCR_TS | ATIM0MODE1_MSCR_IA0S | ATIM0MODE1_MSCR_IB0S,
        pstcCfg->u32IA0Sel | pstcCfg->u32IB0Sel | pstcCfg->u32TsSel);

    if (ATIM0_M1_FLTR_FLTA0_B0_ET_NONE != pstcCfg->u32FltIA0)
    {
        pstcAtim->CR0_f.CSA = 1U;
    }
    if (ATIM0_M1_FLTR_FLTA0_B0_ET_NONE != pstcCfg->u32FltIB0)
    {
        pstcAtim->CR0_f.CSB = 1U;
    }

    REG_MODIFY(HC_ATIM0MODE1->FLTR,
        ATIM0MODE1_FLTR_FLTA0 | ATIM0MODE1_FLTR_FLTB0 | ATIM0MODE1_FLTR_FLTET | ATIM0MODE1_FLTR_ETP,
        pstcCfg->u32FltIA0 | (pstcCfg->u32FltIB0 << ATIM0MODE1_FLTR_FLTB0_Pos)
            | (pstcCfg->u32FltETR << ATIM0MODE1_FLTR_FLTET_Pos) | pstcCfg->u32ETR);
}

/**
 * @brief  ATIM0 PWC测量边沿起始结束选择(周期) (模式1)
 * @param  [in] u32DetectEdgeSel:        测量起始和结束边沿选择 @ref ATim0_Mode1_PWC_Start_End_Edge
 * @retval None
 */
void ATIM0_Mode1_PWC_Edge_Sel(uint32_t u32DetectEdgeSel)
{
    REG_MODIFY(HC_ATIM0MODE1->M1CR, ATIM0MODE1_M1CR_EDG2ND | ATIM0MODE1_M1CR_EDG1ST, u32DetectEdgeSel);
}

/**
 * @brief  ATIM0 启动运行(模式1)
 * @param  None
 * @retval None
 */
void ATIM0_Mode1_Run(void)
{
    REG_SETBITS(HC_ATIM0MODE1->M1CR, ATIM0MODE1_M1CR_CEN);
}

/**
 * @brief  ATIM0 停止运行(模式1)
 * @param  None
 * @retval None
 */
void ATIM0_Mode1_Stop(void)
{
    REG_CLEARBITS(HC_ATIM0MODE1->M1CR, ATIM0MODE1_M1CR_CEN);
}

/**
 * @brief  ATIM0 16位计数器初值设置(模式1)
 * @param  [in] u16Data:        CNT 16位初值
 * @retval None
 */
void ATIM0_Mode1_Cnt16Set(uint32_t u16Data)
{
    REG_WRITE(HC_ATIM0MODE1->CNT, (u16Data & 0xFFFFu));
}

/**
 * @brief  ATIM0 16位计数值获取(模式1)
 * @param  None
 * @retval uint32_t: 16bits计数值
 */
uint32_t ATIM0_Mode1_Cnt16Get(void)
{
    return ((REG_READ(HC_ATIM0MODE1->CNT)) & 0xFFFFu);
}

/**
 * @brief  ATIM0 脉冲宽度测量结果数值获取(模式1)
 * @param  None
 * @retval uint32_t: 16bits脉冲宽度测量结果
 */
uint32_t ATIM0_Mode1_PWC_CapValueGet(void)
{
    return ((REG_READ(HC_ATIM0MODE1->CCR0A)) & 0xFFFFu);
}

/**
 * @brief  ATIM0 初始化配置(模式23)
 * @param  [in] pstcCfg:        初始化配置结构体指针 @ref stc_atim0_mode23_cfg_t
 * @retval None
 */
void ATIM0_Mode23_Init(stc_atim0_mode23_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->M23CR,
        ATIM0MODE23_M23CR_MODE | ATIM0MODE23_M23CR_DIR | ATIM0MODE23_M23CR_PRS | ATIM0MODE23_M23CR_CT
            | ATIM0MODE23_M23CR_COMP | ATIM0MODE23_M23CR_PWM2S | ATIM0MODE23_M23CR_ONESHOT | ATIM0MODE23_M23CR_URS,
        pstcCfg->u32WorkMode | pstcCfg->u32CntDir | pstcCfg->u32PRS | pstcCfg->u32CountClkSel | pstcCfg->u32PWMTypeSel
            | pstcCfg->u32PWM2sSel | pstcCfg->u32ShotMode | pstcCfg->u32URSSel);
}

/**
 * @brief  ATIM0 启动运行(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_Run(void)
{
    REG_SETBITS(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_CTEN);
}

/**
 * @brief  ATIM0 停止运行(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_Stop(void)
{
    REG_CLEARBITS(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_CTEN);
}

/**
 * @brief  ATIM0 手动PWM输出使能/禁止(模式23)
 * @param  [in] bEnOutput:        手动PWM输出 TRUE: 使能, FALSE: 禁止
 * @retval None
 */
void ATIM0_Mode23_Manual_PWM_Output_Enable(boolean_t bEnOutput)
{
    REG_MODIFY(HC_ATIM0MODE23->DTR, ATIM0MODE23_DTR_MO, (uint32_t)bEnOutput << ATIM0MODE23_DTR_MO_Pos);
}

/**
 * @brief  ATIM0 自动PWM输出使能/禁止(模式23)
 * @param  [in] bEnAutoOutput:        自动PWM输出 TRUE: 使能, FALSE: 禁止
 * @retval None
 */
void ATIM0_Mode23_Auto_PWM_Output_Enable(boolean_t bEnAutoOutput)
{
    REG_MODIFY(HC_ATIM0MODE23->DTR, ATIM0MODE23_DTR_AO, (uint32_t)bEnAutoOutput << ATIM0MODE23_DTR_AO_Pos);
}

/**
 * @brief  ATIM0 重载(周期)缓存使能(模式23)
 * @param  [in] bEnBuffer:        重载(周期)缓存 TRUE: 使能, FALSE: 禁止
 * @retval None
 */
void ATIM0_Mode23_ARR_Buffer_Enable(boolean_t bEnBuffer)
{
    REG_MODIFY(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_BUFP, (uint32_t)bEnBuffer << ATIM0MODE23_M23CR_BUFP_Pos);
}

/**
 * @brief  ATIM0 重载值设置(模式23)
 * @param  [in] u16Data:        16bits重载值
 * @retval None
 */
void ATIM0_Mode23_ARRSet(uint16_t u16Data)
{
    REG_WRITE(HC_ATIM0MODE23->ARR, (uint32_t)u16Data);
}

/**
 * @brief  ATIM0 重载值获取(模式23)
 * @param  None
 * @retval uint32_t: 16bit重载值
 */
uint32_t ATIM0_Mode23_GetARR(void)
{
    return ((REG_READ(HC_ATIM0MODE23->ARR)) & 0xFFFFu);
}

/**
 * @brief  ATIM0 16位计数器初值设置(模式23)
 * @param  [in] u16Data:        16位初值
 * @retval None
 */
void ATIM0_Mode23_Cnt16Set(uint16_t u16Data)
{
    REG_WRITE(HC_ATIM0MODE23->CNT, (uint32_t)u16Data);
}

/**
 * @brief  ATIM0 16位计数值获取(模式23)
 * @param  None
 * @retval uint32_t: 16bits计数值
 */
uint32_t ATIM0_Mode23_Cnt16Get(void)
{
    return ((REG_READ(HC_ATIM0MODE23->CNT)) & 0xFFFFu);
}

/**
 * @brief  ATIM0 通道CHxA/CHxB比较值设置(CCRxA/CCRxB)(模式23)
 * @param  [in] u32Channel:     ATIM0 通道 @ref ATim0_Mode23_CCRxx_Channel
 * @param  [in] u16Data:        CCRxA/CCRxB 16位比较值
 * @retval None
 */
void ATIM0_Mode23_Channel_Compare_Value_Set(uint32_t u32Channel, uint16_t u16Data)
{
    REG_WRITE(*(&HC_ATIM0MODE23->CCR0A + u32Channel), (uint32_t)u16Data);
}

/**
 * @brief  ATIM0 通道CHxA/CHxB捕获值读取、CCR3寄存器值读取(CCRxA/CCRxB)(模式23)
 * @param  [in] u32Channel:     ATIM0 通道 @ref ATim0_Mode23_CCRxx_Channel
 * @retval uint32_t:            16 bits CCRxA/CCRxB捕获值
 */
uint32_t ATIM0_Mode23_Channel_Capture_Value_Get(uint32_t u32Channel)
{
    return ((REG_READ(*(&HC_ATIM0MODE23->CCR0A + u32Channel))) & 0xFFFFu);
}

/**
 * @brief  ATIM0 PWM互补输出模式下，GATE功能选择,只有在PWM互补输出时有效(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_gate_cfg_t
 * @retval None
 */
void ATIM0_Mode23_GateFuncSel(stc_atim0_m23_gate_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_CSG | ATIM0MODE23_M23CR_CRG | ATIM0MODE23_M23CR_CFG,
        pstcCfg->u32GateFuncSel | pstcCfg->u32GateRiseCap | pstcCfg->u32GateFallCap);
}

/**
 * @brief  ATIM0 主从触发配置(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_master_slave_cfg_t
 * @retval None
 */
void ATIM0_Mode23_MasterSlave_Trig_Set(stc_atim0_m23_master_slave_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->MSCR,
        ATIM0MODE23_MSCR_MSM | ATIM0MODE23_MSCR_MMS | ATIM0MODE23_MSCR_SMS | ATIM0MODE23_MSCR_TS,
        pstcCfg->u32MasterSlaveSel | pstcCfg->u32MasterSrc | pstcCfg->u32SlaveModeSel | pstcCfg->u32TsSel);
}

/**
 * @brief  ATIM0 IA0输入选择(模式23)
 * @param  [in] u32Ia0Sel:     CH0A输入通道选择 @ref ATim0_Mode23_IA0_IN_Sel
 * @retval None
 */
void ATIM0_Mode23_MSCR_IA0_Sel(uint32_t u32Ia0Sel)
{
    REG_MODIFY(HC_ATIM0MODE23->MSCR, ATIM0MODE23_MSCR_IA0S, u32Ia0Sel);
}

/**
 * @brief  ATIM0 IB0输入选择(模式23)
 * @param  [in] u32Ib0Sel:     CH0B输入通道选择 @ref ATim0_Mode23_IB0_IN_Sel
 * @retval None
 */
void ATIM0_Mode23_MSCR_IB0_Sel(uint32_t u32Ib0Sel)
{
    REG_MODIFY(HC_ATIM0MODE23->MSCR, ATIM0MODE23_MSCR_IB0S, u32Ib0Sel);
}

/**
 * @brief  ATIM0 通道0/1/2 CHxA输出设置(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_compare_cfg_t
 * @retval None
 */
void ATIM0_Mode23_PortOutput_CHA_Cfg(stc_atim0_m23_compare_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CSA | ATIM0MODE23_CRCH0_BUFEA,
        pstcCfg->u32CHxCmpCap | pstcCfg->u32CHxCmpBufEn);

    REG_MODIFY(HC_ATIM0MODE23->FLTR, ATIM0MODE23_FLTR_OCMA0FLTA0 | ATIM0MODE23_FLTR_CCPA0,
        pstcCfg->u32CHxCmpModeCtrl | pstcCfg->u32CHxPolarity);

    REG_MODIFY(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_CIS, pstcCfg->u32CHxCmpIntSel);
}

/**
 * @brief  ATIM0 通道0/1/2 CHxB输出设置(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_compare_cfg_t
 * @retval None
 */
void ATIM0_Mode23_PortOutput_CHB_Cfg(stc_atim0_m23_compare_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CSB | ATIM0MODE23_CRCH0_BUFEB | ATIM0MODE23_CRCH0_CISB,
        (pstcCfg->u32CHxCmpCap << 1) | (pstcCfg->u32CHxCmpBufEn << 1) | pstcCfg->u32CHxCmpIntSel);

    REG_MODIFY(HC_ATIM0MODE23->FLTR, ATIM0MODE23_FLTR_OCMB0FLTB0 | ATIM0MODE23_FLTR_CCPB0,
        (pstcCfg->u32CHxCmpModeCtrl << ATIM0MODE23_FLTR_OCMB0FLTB0_Pos)
            | (pstcCfg->u32CHxPolarity << +ATIM0MODE23_FLTR_OCMB0FLTB0_Pos));
}

/**
 * @brief  ATIM0 通道0/1/2 CHxA输入设置(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_input_cfg_t
 * @retval None
 */
void ATIM0_Mode23_PortInput_CHA_Cfg(stc_atim0_m23_input_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CSA | ATIM0MODE23_CRCH0_BKSACFACRA,
        pstcCfg->u32CHxCmpCap | pstcCfg->u32CHxCapSel);

    REG_MODIFY(HC_ATIM0MODE23->FLTR, ATIM0MODE23_FLTR_OCMA0FLTA0 | ATIM0MODE23_FLTR_CCPA0,
        pstcCfg->u32CHxInFlt | pstcCfg->u32CHxPolarity);
}

/**
 * @brief  ATIM0 通道0/1/2 CHxB输入设置(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_input_cfg_t
 * @retval None
 */
void ATIM0_Mode23_PortInput_CHB_Cfg(stc_atim0_m23_input_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CSB | ATIM0MODE23_CRCH0_BKSBCFBCRB,
        (pstcCfg->u32CHxCmpCap << 1) | (pstcCfg->u32CHxCapSel << ATIM0MODE23_CRCH0_BKSBCFBCRB_Pos));

    REG_MODIFY(HC_ATIM0MODE23->FLTR, ATIM0MODE23_FLTR_OCMB0FLTB0 | ATIM0MODE23_FLTR_CCPB0,
        (pstcCfg->u32CHxInFlt << ATIM0MODE23_FLTR_OCMB0FLTB0_Pos)
            | (pstcCfg->u32CHxPolarity << ATIM0MODE23_FLTR_OCMB0FLTB0_Pos));
}

/**
 * @brief  ATIM0 ERT输入控制(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_etr_input_cfg_t
 * @retval None
 */
void ATIM0_Mode23_ETRInput_Cfg(stc_atim0_m23_etr_input_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->FLTR, ATIM0MODE23_FLTR_ETP | ATIM0MODE23_FLTR_FLTET,
        pstcCfg->u32ETRPolarity | (pstcCfg->u32ETRFlt << ATIM0MODE23_FLTR_FLTET_Pos));
}

/**
 * @brief  ATIM0 刹车BK输入控制(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_bk_input_cfg_t
 * @retval None
 */
void ATIM0_Mode23_BrakeInput_Cfg(stc_atim0_m23_bk_input_cfg_t* pstcBkCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->DTR, ATIM0MODE23_DTR_BK | ATIM0MODE23_DTR_VC | ATIM0MODE23_DTR_SAFE,
        pstcBkCfg->u32EnBrake | pstcBkCfg->u32EnVCBrake | pstcBkCfg->u32EnSafetyBk);

    REG_MODIFY(HC_ATIM0MODE23->FLTR, ATIM0MODE23_FLTR_BKP | ATIM0MODE23_FLTR_FLTBK,
        pstcBkCfg->u32BrakePolarity | (pstcBkCfg->u32BrakeFlt << ATIM0MODE23_FLTR_FLTBK_Pos));
}

/**
 * @brief  ATIM0 刹车BK端口状态控制(模式23)
 * @param  [in] u32ChxaStatus:     CHxA端口 @ref ATim0_Mode23_Brake_Port_Out_Level
 * @param  [in] u32ChxbStatus:     CHxB端口 @ref ATim0_Mode23_Brake_Port_Out_Level
 * @retval None
 */
void ATIM0_Mode23_Brake_Port_Status_Cfg(uint32_t u32ChxaStatus, uint32_t u32ChxbStatus)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_BKSACFACRA | ATIM0MODE23_CRCH0_BKSBCFBCRB,
        u32ChxaStatus | (u32ChxbStatus << ATIM0MODE23_CRCH0_BKSBCFBCRB_Pos));
}

/**
 * @brief  ATIM0 死区功能(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_dt_cfg_t
 * @retval None
 */
void ATIM0_Mode23_DT_Cfg(stc_atim0_m23_dt_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->DTR, ATIM0MODE23_DTR_DT | ATIM0MODE23_DTR_DTR,
        (((uint32_t)pstcCfg->bEnDeadTime) << ATIM0MODE23_DTR_DT_Pos) | (pstcCfg->u32DeadTimeValue & 0xFF));
}

/**
 * @brief  ATIM0 触发ADC控制(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_adc_trig_cfg_t
 * @retval None
 */
void ATIM0_Mode23_TrigADC_Cfg(stc_atim0_m23_adc_trig_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->ADTR,
        ATIM0MODE23_ADTR_ADT | ATIM0MODE23_ADTR_UEV | ATIM0MODE23_ADTR_CMA0 | ATIM0MODE23_ADTR_CMB0,
        ((uint32_t)pstcCfg->bEnTrigADC) << ATIM0MODE23_ADTR_ADT_Pos
            | ((uint32_t)pstcCfg->bEnUevTrigADC) << ATIM0MODE23_ADTR_UEV_Pos
            | ((uint32_t)pstcCfg->bEnCH0ACmpTrigADC) << ATIM0MODE23_ADTR_CMA0_Pos
            | ((uint32_t)pstcCfg->bEnCH0BCmpTrigADC) << ATIM0MODE23_ADTR_CMB0_Pos);
}

/**
 * @brief  ATIM0 重复周期设置(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_rcr_cfg_t
 * @retval None
 */
void ATIM0_Mode23_SetRepeatPeriod(stc_atim0_m23_rcr_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->RCR, ATIM0MODE23_RCR_UD | ATIM0MODE23_RCR_OV | ATIM0MODE23_RCR_RCR,
        pstcCfg->u32EnUnderFlowMask | pstcCfg->u32EnOverFLowMask | pstcCfg->u32RepeatCountNum);
}

/**
 * @brief  ATIM0 OCREF清除功能(模式23)
 * @param  [in] pstcCfg:     初始化配置结构体指针 @ref stc_atim0_m23_ocref_clr_cfg_t
 * @retval None
 */
void ATIM0_Mode23_OCRefClr(stc_atim0_m23_ocref_clr_cfg_t* pstcCfg)
{
    REG_MODIFY(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_OCC | ATIM0MODE23_M23CR_OCCS,
        ((uint32_t)pstcCfg->bOCSourceClrEn) << ATIM0MODE23_M23CR_OCC_Pos | pstcCfg->u32OCRefClrSrcSel);
}

/**
 * @brief  ATIM0 使能/禁止 UVE更新触发DMA传输(模式23)
 * @param  [in] bUevTrigDMA:     UEV更新触发DMA, FALSE: 禁止, TRUE: 使能
 * @retval None
 */
void ATIM0_Mode23_EnDisable_UEV_TrigDMA(boolean_t bUevTrigDMA)
{
    REG_MODIFY(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_UD, (uint32_t)bUevTrigDMA << ATIM0MODE23_M23CR_UD_Pos);
}

/**
 * @brief  ATIM0 使能/禁止 TRIGGER触发DMA传输(模式23)
 * @param  [in] bTITrigDMA:     Trigger触发DMA, FALSE: 禁止, TRUE: 使能
 * @retval None
 */
void ATIM0_Mode23_EnDisable_Trigger_TrigDMA(boolean_t bTITrigDMA)
{
    REG_MODIFY(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_TD, (uint32_t)bTITrigDMA << ATIM0MODE23_M23CR_TD_Pos);
}

/**
 * @brief  ATIM0 使能/禁止 CH0A捕获比较触发DMA传输(模式23)
 * @param  [in] bCH0ATrigDMA:     CHOA捕获比较触发DMA, FALSE: 禁止, TRUE: 使能
 * @retval None
 */
void ATIM0_Mode23_EnDisable_CH0A_TrigDMA(boolean_t bCH0ATrigDMA)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CDEA, (uint32_t)bCH0ATrigDMA << ATIM0MODE23_CRCH0_CDEA_Pos);
}

/**
 * @brief  ATIM0 使能/禁止 CH0B捕获比较触发DMA传输(模式23)
 * @param  [in] bCH0BTrigDMA:     CHOB捕获比较触发DMA, FALSE: 禁止, TRUE: 使能
 * @retval None
 */
void ATIM0_Mode23_EnDisable_CH0B_TrigDMA(boolean_t bCH0BTrigDMA)
{
    REG_MODIFY(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CDEB, (uint32_t)bCH0BTrigDMA << ATIM0MODE23_CRCH0_CDEB_Pos);
}

/**
 * @brief  ATIM0 比较模式下DMA比较触发选择(模式23)
 * @param  [in] u32CmpUevTrigDMA:     比较模式下DMA比较触发选择 @ref ATim0_Mode23_Comp_Trigger_DMA
 * @retval None
 */
void ATIM0_Mode23_Compare_Trig_DMA_Sel(uint32_t u32CmpUevTrigDMA)
{
    REG_MODIFY(HC_ATIM0MODE23->MSCR, ATIM0MODE23_MSCR_CCDS, u32CmpUevTrigDMA);
}

/**
 * @brief  ATIM0 CH0A通道0A捕获比较软件触发(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_Enable_CH0A_SwTrig_Capture_Compare(void)
{
    REG_SETBITS(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CCGA);
}

/**
 * @brief  ATIM0 CH0B通道0B捕获比较软件触发(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_Enable_CH0B_SwTrig_Capture_Compare(void)
{
    REG_SETBITS(HC_ATIM0MODE23->CRCH0, ATIM0MODE23_CRCH0_CCGB);
}

/**
 * @brief  ATIM0 软件更新使能(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_EnableSoftwareUev(void)
{
    REG_SETBITS(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_UG);
}

/**
 * @brief  ATIM0 软件触发使能(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_EnableSoftwareTrig(void)
{
    REG_SETBITS(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_TG);
}

/**
 * @brief  ATIM0 软件刹车使能(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_Mode23_EnableSoftwareBrake(void)
{
    REG_SETBITS(HC_ATIM0MODE23->M23CR, ATIM0MODE23_M23CR_BG);
}

/**
 * @brief  ATIM0 获取模式0/1/2/3 中断标志(模式23)
 * @param  u32InterruptFlagTypes ATIMx中断标志类型 @ref ATIM0_INT_Status_Flags
 * @retval uint32_t: 0或者1
 */
uint32_t ATIM0_GetIntFlag(uint32_t u32InterruptFlagTypes)
{
    return (REG_READBITS(HC_ATIM0MODE23->IFR, u32InterruptFlagTypes) == u32InterruptFlagTypes);
}

/**
 * @brief  ATIM0 清除模式0/1/2/3 中断标志(模式23)
 * @param  u32InterruptFlagTypes ATIMx中断标志类型 @ref ATIM0_INT_Clear_Flags
 * @retval None
 */
void ATIM0_ClearIrqFlag(uint32_t u32InterruptFlagTypes)
{
    REG_CLEARBITS(HC_ATIM0MODE23->ICLR, u32InterruptFlagTypes);
}

/**
 * @brief  ATIM0 中断所有标志清除(模式23)
 * @param  None
 * @retval None
 */
void ATIM0_ClearAllIrqFlag(void)
{
    REG_CLEARBITS(HC_ATIM0MODE23->ICLR, 0x7FFFDu);
}

/**
 * @brief  ATIM0 中断使能(模式0)
 * @param  None
 * @retval None
 */
void ATIM0_Mode0_EnableIrq(void)
{
    REG_SETBITS(HC_ATIM0MODE0->M0CR, ATIM0MODE0_M0CR_UI);
}

/**
 * @brief  ATIM0 中断禁止(模式0)
 * @param  None
 * @retval None
 */
void ATIM0_Mode0_DisableIrq(void)
{
    REG_CLEARBITS(HC_ATIM0MODE0->M0CR, ATIM0MODE0_M0CR_UI);
}

/**
 * @brief  ATIM0 中断使能(模式1)
 * @param  u32InterruptTypes 中断类型 @ref ATIM0_Mode1_INT_Request
 * @retval None
 */
void ATIM0_Mode1_EnableIrq(uint32_t u32InterruptTypes)
{
    if (u32InterruptTypes & ATIM0_M1_INT_UI)
    {
        REG_SETBITS(HC_ATIM0MODE1->M1CR, ATIM0MODE1_M1CR_UI);
    }
    if (u32InterruptTypes & ATIM0_M1_INT_CA0)
    {
        REG_SETBITS(HC_ATIM0MODE1->CR0, ATIM0MODE1_CR0_CIEA);
    }
}

/**
 * @brief  ATIM0 中断禁止(模式1)
 * @param  u32InterruptTypes 中断类型 @ref ATIM0_Mode1_INT_Request
 * @retval None
 */
void ATIM0_Mode1_DisableIrq(uint32_t u32InterruptTypes)
{
    if (u32InterruptTypes & ATIM0_M1_INT_UI)
    {
        REG_CLEARBITS(HC_ATIM0MODE1->M1CR, ATIM0MODE1_M1CR_UI);
    }
    if (u32InterruptTypes & ATIM0_M1_INT_CA0)
    {
        REG_CLEARBITS(HC_ATIM0MODE1->CR0, ATIM0MODE1_CR0_CIEA);
    }
}

/**
 * @brief  ATIM0 中断使能(模式23)
 * @param  u32InterruptTypes 中断类型 @ref ATIM0_Mode23_INT_Request
 * @retval None
 */
void ATIM0_Mode23_EnableIrq(uint32_t u32InterruptTypes)
{
    uint32_t u32Types = 0;

    if (_INTERRUPT_M23CR_ID & u32InterruptTypes)
    {
        u32Types = u32InterruptTypes & _INTERRUPT_M23CR_MASK;
        REG_SETBITS(HC_ATIM0MODE23->M23CR, u32Types);
    }

    if (_INTERRUPT_CRCH0_ID & u32InterruptTypes)
    {
        u32Types = u32InterruptTypes & _INTERRUPT_CRCH0_MASK;
        REG_SETBITS(HC_ATIM0MODE23->CRCH0, u32Types);
    }
}

/**
 * @brief  ATIM0 中断禁止(模式23)
 * @param  u32InterruptTypes 中断类型 @ref ATIM0_Mode23_INT_Request
 * @retval None
 */
void ATIM0_Mode23_DisableIrq(uint32_t u32InterruptTypes)
{
    uint32_t u32Types = 0;

    if (_INTERRUPT_M23CR_ID & u32InterruptTypes)
    {
        u32Types = u32InterruptTypes & _INTERRUPT_M23CR_MASK;
        REG_CLEARBITS(HC_ATIM0MODE23->M23CR, u32Types);
    }

    if (_INTERRUPT_CRCH0_ID & u32InterruptTypes)
    {
        u32Types = u32InterruptTypes & _INTERRUPT_CRCH0_MASK;
        REG_CLEARBITS(HC_ATIM0MODE23->CRCH0, u32Types);
    }
}
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
