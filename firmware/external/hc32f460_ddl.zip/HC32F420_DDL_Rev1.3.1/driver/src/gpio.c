/**
 *******************************************************************************
 * @file  gpio.c
 * @brief This file provides firmware functions to manage the GPIO.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "gpio.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_GPIO GPIO子模块驱动库
 * @brief GPIO Driver Library GPIO子模块驱动库
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup GPIO_Local_Macros GPIO局部宏定义
 * @{
 */
/**
 * @defgroup GPIO_Value_Define GPIO模式值设置
 * @{
 */
#define GPIO_MODE_MSK         (0x000FU) /*!<  端口模式Mask值     */
#define GPIO_MODE_OD_MSK      (0x00F0U) /*!<  端口模式Mask值     */
#define GPIO_MODE_EXT_INT_MSK (0x0F00U) /*!<  外部中断Mask值     */

#define GPIO_INPUT            (0x0001U) /*!<  端口模式_输入      */
#define GPIO_OUTPUT           (0x0002U) /*!<  端口模式_输出      */
#define GPIO_ANALOG           (0x0004U) /*!<  端口模式_模拟      */
#define GPIO_EXT_INT          (0x0F00U) /*!<  端口外部中断       */
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup GPIO_Global_Functions GPIO全局函数定义
 * @{
 */

/**
 * @brief  GPIO 初始化
 * @param  [in] GPIOx:        GPIO类型定义      @ref GPIO_TypeDef
 * @param  [in] pstcGpioInit: GPIO初始化结构体  @ref stc_gpio_init_t
 * @retval None
 */
void GPIO_Init(GPIO_TypeDef* GPIOx, stc_gpio_init_t* pstcGpioInit)
{
    /* ANALOG */
    if (GPIO_ANALOG == (pstcGpioInit->u32Mode & GPIO_MODE_MSK))
    {
        REG_SETBITS(GPIOx->ADS, pstcGpioInit->u32Pin);
    }
    else
    {
        REG_CLEARBITS(GPIOx->ADS, pstcGpioInit->u32Pin);
    }

    /* INPUT */
    if (GPIO_INPUT == (pstcGpioInit->u32Mode & GPIO_MODE_MSK))
    {
        REG_SETBITS(GPIOx->DIR, pstcGpioInit->u32Pin);
    }

    /* OUTPUT */
    if (GPIO_OUTPUT == (pstcGpioInit->u32Mode & GPIO_MODE_MSK))
    {
        REG_CLEARBITS(GPIOx->DIR, pstcGpioInit->u32Pin);

        /* OPENDRAIN or PUSH-PULL */
        if (pstcGpioInit->u32Mode & GPIO_MODE_OD_MSK)
        {
            REG_SETBITS(GPIOx->OPENDRAIN, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->OPENDRAIN, pstcGpioInit->u32Pin);
        }

        /* DRIVER ABILITY High or Low */
        if (GPIO_Driver_Level_L == pstcGpioInit->u32DriverLevel)
        {
            REG_SETBITS(GPIOx->DRIVER, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->DRIVER, pstcGpioInit->u32Pin);
        }
    }

    /* PUSH-PULL TYPE */
    if (GPIO_PULL_UP == pstcGpioInit->u32PullUpDn)
    {
        REG_SETBITS(GPIOx->PUPD, pstcGpioInit->u32Pin);
    }
    else if (GPIO_PULL_DOWN == pstcGpioInit->u32PullUpDn)
    {
        REG_SETBITS(GPIOx->PUPD, (pstcGpioInit->u32Pin << 0x10));
        REG_CLEARBITS(GPIOx->PUPD, pstcGpioInit->u32Pin);
    }
    else
    {
        REG_CLEARBITS(GPIOx->PUPD, pstcGpioInit->u32Pin);
        REG_CLEARBITS(GPIOx->PUPD, (pstcGpioInit->u32Pin << 0x10));
    }

    /* External Interrupt */
    if (GPIO_EXT_INT == (pstcGpioInit->u32Mode & GPIO_MODE_EXT_INT_MSK))
    {
        if (pstcGpioInit->u32ExtInt & GPIO_EXTI_RISING)
        {
            REG_SETBITS(GPIOx->RISEIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->RISEIE, pstcGpioInit->u32Pin);
        }

        if (pstcGpioInit->u32ExtInt & GPIO_EXTI_FALLING)
        {
            REG_SETBITS(GPIOx->FALLIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->FALLIE, pstcGpioInit->u32Pin);
        }

        if (pstcGpioInit->u32ExtInt & GPIO_EXTI_HIGH)
        {
            REG_SETBITS(GPIOx->HIGHIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->HIGHIE, pstcGpioInit->u32Pin);
        }

        if (pstcGpioInit->u32ExtInt & GPIO_EXTI_LOW)
        {
            REG_SETBITS(GPIOx->LOWIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->LOWIE, pstcGpioInit->u32Pin);
        }
    }
}

/**
 * @brief  GPIO PIN脚中断状态获取
 * @param  [in] GPIOx:  GPIO类型定义    @ref GPIO_TypeDef
 * @param  [in] u32Pin: GPIO引脚定义    @ref GPIO_PINs_Define
 * @retval uint32_t:
 *           - 0:   未发生中断
 *           - 非0: 产生中断
 */
uint32_t GPIO_ExtIrqStateGet(GPIO_TypeDef* GPIOx, uint32_t u32Pin)
{
    return (uint32_t)REG_READBITS(GPIOx->IFR, u32Pin);
}
/**
 * @brief  GPIO PIN脚中断状态清除
 * @param  [in] GPIOx:  GPIO类型定义    @ref GPIO_TypeDef
 * @param  [in] u32Pin: GPIO引脚定义    @ref GPIO_PINs_Define
 * @retval None
 */
void GPIO_ExtIrqStateClear(GPIO_TypeDef* GPIOx, uint32_t u32Pin)
{
    REG_CLEARBITS(GPIOx->ICR, u32Pin);
}
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
