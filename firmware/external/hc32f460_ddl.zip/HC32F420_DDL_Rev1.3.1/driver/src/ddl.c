/**
 *******************************************************************************
 * @file  ddl.c
 * @brief Common API of DDL.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2023-12-18       MADS            Modify delay functions
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"

#ifndef __DEBUG
#define __DEBUG
// #define __CC_ARM
#endif

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_DDL DDL子模块驱动库
 * @brief DDL Common API DDL共通API
 * @{
 */

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup DDL_Global_Functions DDL全局函数定义
 * @{
 */

/**
 * @brief  Log2 初始化
 * @param  [in] u32Val:        数据
 * @retval uint32_t:           Log2结果
 */
uint32_t Log2(uint32_t u32Val)
{
    uint32_t u32V1 = 0;

    if (0u == u32Val)
    {
        return 0;
    }

    while (u32Val > 1u)
    {
        u32V1++;
        u32Val /= 2;
    }

    return u32V1;
}

/**
 * @brief  Memory clear function for DDL_ZERO_STRUCT()
 * @param  [in] u32Count:      数据长度
 * @retval None
 */
void ddl_memclr(void* pu8Address, uint32_t u32Count)
{
    memset(pu8Address, 0, u32Count);
}

/**
 * @brief  delay approximately 1ms
 * @param  [in] u32Cnt:      计数次数
 * @retval None
 */
void delay1ms(uint32_t u32Cnt)
{   
	uint32_t ValNow,CNT = 0;
	uint32_t end = (u32Cnt*(SystemCoreClock/1000));
			   	 
	uint32_t StaVal = SysTick->VAL;        				    
	while(1)
	{
		ValNow=SysTick->VAL;	
		
		if(ValNow != StaVal)
		{			
			if(ValNow<StaVal)
            {
                CNT += StaVal -ValNow;
            }
			else
            {
                CNT += SysTick->LOAD - ValNow+StaVal;
            }				
			StaVal = ValNow;			
			if(CNT >= end ) 
            {
                break;
            }
		}
	}
}

/**
 * @brief  delay approximately 100us
 * @param  [in] u32Cnt:      计数次数
 * @retval None
 */
void delay100us(uint32_t u32Cnt)
{
    uint32_t ValNow,CNT = 0;
	uint32_t end = (u32Cnt*(SystemCoreClock/10000));
			   	 
	uint32_t StaVal = SysTick->VAL;        				    
	while(1)
	{
		ValNow=SysTick->VAL;	
		
		if(ValNow != StaVal)
		{			
			if(ValNow<StaVal)
            {
                CNT += StaVal -ValNow;
            }
			else
            {
                CNT += SysTick->LOAD - ValNow+StaVal;
            }
            
			StaVal = ValNow;
            
			if(CNT >=end)
            {
                break;
            }
		}
	}
}

/**
 * @brief  delay approximately 10us
 * @param  [in] u32Cnt:      计数次数
 * @retval None
 */
void delay10us(uint32_t u32Cnt)
{
    uint32_t ValNow,CNT = 0;
	   	 
	uint32_t StaVal = SysTick->VAL;        				    
	while(1)
	{
		ValNow=SysTick->VAL;	
		
		if(ValNow != StaVal)
		{			
			if(ValNow<StaVal)
            {
                CNT += StaVal -ValNow;
            }
			else
            {
                CNT += SysTick->LOAD - ValNow+StaVal;
            }
            
			StaVal = ValNow;
            
			if(CNT >=(u32Cnt*(SystemCoreClock/100000)))
            {
                break;
            }
		}
	}
}

/**
 * @brief  set register bit
 * @param  [in] addr:      地址
 * @param  [in] offset:    偏移量
 * @param  [in] bFlag:     值（TRUE、FALSE）
 * @retval None
 */
void SetBit(uint32_t addr, uint32_t offset, boolean_t bFlag)
{
    if (TRUE == bFlag)
    {
        *((volatile uint32_t*)(addr)) |= ((1UL) << (offset));
    }
    else
    {
        *((volatile uint32_t*)(addr)) &= (~(1UL << (offset)));
    }
}

/**
 * @brief  get register bit
 * @param  [in] addr:      地址
 * @param  [in] offset:    偏移量
 * @retval boolean_t：     值（TRUE、FALSE）
 */
boolean_t GetBit(uint32_t addr, uint32_t offset)
{
    return ((((*((volatile uint32_t*)(addr))) >> (offset)) & 1u) > 0) ? TRUE : FALSE;
}
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */
/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
