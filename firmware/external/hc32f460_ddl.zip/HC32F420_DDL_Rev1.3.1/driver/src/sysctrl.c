/**
 *******************************************************************************
 * @file  sysctrl.c
 * @brief This file provides firmware functions to manage the SYSCTRL.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2023-12-18       MADS            Add limitation of source input for PLL
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "sysctrl.h"
#include "board_stkhc32f420.h"
#include "flash.h"
#include "hc32f420.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_SYSCTRL SYSCTRL子模块驱动库
 * @brief SYSCTRL Driver Library SYSCTRL子模块驱动库
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
/**
 * @defgroup SYSCTRL_Local_Macros SYSCTRL局部宏定义
 * @{
 */

/**
 * @defgroup SYSCTRL_RCH_RCL_Para_Size RCH/RCL相关配置位宽度
 * @{
 */
#define RCH_DIV_WIDTH (0x0Fu)
#define RCH_TRIM_WIDTH (0x1FFu)
#define RCH_WAIT_CYCLE_WIDTH (0x03u)
#define RCL_TRIM_WIDTH (0x3FFu)

/**
 * @}
 */

/**
 * @defgroup SYSCTRL_RCH_RCL_Value_Define RCH/RCL频率配置
 * @{
 */
#define SYSCTRL_RCH_24M (24000000u)
#define SYSCTRL_RCL_32K7 (32768u)

/**
 * @}
 */

/**
 * @defgroup SYSCTRL_Value_Define SYSCTRL PLL参数设置
 * @{
 */
#define SYSCTRL_PLL_MULM_MIN (2u)                      /*!< PLL最小倍频系数 */
#define SYSCTRL_PLL_MULM_MAX (63u)                     /*!< PLL最大倍频系数 */
#define SYSCTRL_PLL_DIVN_MIN (1u)                      /*!< PLL最小分频系数 */
#define SYSCTRL_PLL_DIVN_MAX (63u)                     /*!< PLL最小分频系数 */
#define SYSCTRL_PLL_FIN_MIN (4000000u)                 /*!< PLL输入最小频率 */
#define SYSCTRL_PLL_FIN_MAX (32000000u)                /*!< PLL输入最大频率 */
#define SYSCTRL_PLL_FIN_DIVN_OUT_MIN (4000000u)        /*!< FIN/DIVN最小值 */
#define SYSCTRL_PLL_FIN_DIVN_OUT_MAX (16000000u)       /*!< FIN/DIVN最大值 */
#define SYSCTRL_PLL_FIN_MULM_DIVN_OUT_MIN (120000000u) /*!< (FIN*MULM)/DIVN最小值 */
#define SYSCTRL_PLL_FIN_MULM_DIVN_OUT_MAX (200000000u) /*!< (FIN*MULM)/DIVN最大值 */
#define SYSCTRL_PLL_FOUT_MIN (15000000u)               /*!< PLL输出最小频率 */
#define SYSCTRL_PLL_FOUT_MAX (84000000u)               /*!< PLL输出最大频率 */
/**
 * @}
 */

/**
 * @defgroup Sysctrl解锁 Sysctrl 控制器解锁
 * @{
 */
#define SysctrlUnlock()                     \
    do                                      \
    {                                       \
        HC_SYSCTRL->CR3 = (uint32_t)0x5A5A; \
        HC_SYSCTRL->CR3 = (uint32_t)0xA5A5; \
    } while (0)
/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
/**
 * @defgroup SYSCTRL_Local_Variables SYSCTRL局部变量定义
 * @{
 */
static const uint32_t au32RCHFreqTable[9] = {
    2u,
    4u,
    6u,
    8u,
    10u,
    12u,
    14u,
    16u,
    1u}; /* RCH分频系数表 */

/**
 * @}
 */

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @defgroup SYSCTRL_Local_Functions SYSCTRL局部函数定义
 * @{
 */

/**
 * @brief  检查PLL时钟配置参数是否合理: 1).若时钟源为RCHCLKD，则禁止RCH_DIV为8(1分频);2).参数取值范围：Fin[4,32M],Fout[15M,84M],FIN/DIVN[4M,16M],FIN*MULM/DIVN[120M,200M],MULM[2,63],DIVN[1,63]
 * @param  [in]  pstcPLLCfg PLL配置结构体指针 @ref stc_sysctrl_pll_cfg_t
 * @retval en_result_t:
 *         - Ok: 初始化正常
 *         - Error： 初始化异常
 */
static en_result_t Sysctrl_PLL_Para_Check(stc_sysctrl_pll_cfg_t *pstcPLLCfg)
{
    en_result_t enRet = Ok;
    uint32_t u32Fin, u32Fin_divn, u32Fin_divn_mulm, u32Pll_out;

    if (pstcPLLCfg->u8Source == SYSCTRL_PLL_SRC_RCH)
    {
        if (HC_SYSCTRL->RCH_f.DIV == SYSCTRL_RCH_DIV1)
        {
            return ErrorInvalidParameter;
        }
    }

    if ((pstcPLLCfg->u8MulM < SYSCTRL_PLL_MULM_MIN) || (pstcPLLCfg->u8MulM > SYSCTRL_PLL_MULM_MAX))
    {
        return ErrorInvalidParameter;
    }

    if ((pstcPLLCfg->u8DIVN < SYSCTRL_PLL_DIVN_MIN) || (pstcPLLCfg->u8DIVN > SYSCTRL_PLL_DIVN_MAX))
    {
        return ErrorInvalidParameter;
    }

    if (SYSCTRL_PLL_SRC_RCH == pstcPLLCfg->u8Source)
    {
        u32Fin = SYSCTRL_RCH_24M;
        u32Fin = u32Fin / au32RCHFreqTable[REG_READBITS(HC_SYSCTRL->RCH, SYSCTRL_RCH_DIV) >> SYSCTRL_RCH_DIV_Pos];
    }
    else
    {
        u32Fin = SYSTEM_XTH;
    }

    if ((u32Fin < SYSCTRL_PLL_FIN_MIN) || (u32Fin > SYSCTRL_PLL_FIN_MAX))
    {
        return ErrorInvalidParameter;
    }

    u32Fin_divn = u32Fin / pstcPLLCfg->u8DIVN;

    if ((u32Fin_divn < SYSCTRL_PLL_FIN_DIVN_OUT_MIN) || (u32Fin_divn > SYSCTRL_PLL_FIN_DIVN_OUT_MAX))
    {
        return ErrorInvalidParameter;
    }

    u32Fin_divn_mulm = (u32Fin_divn * pstcPLLCfg->u8MulM);

    if ((u32Fin_divn_mulm < SYSCTRL_PLL_FIN_MULM_DIVN_OUT_MIN) || (u32Fin_divn_mulm > SYSCTRL_PLL_FIN_MULM_DIVN_OUT_MAX))
    {
        return ErrorInvalidParameter;
    }

    u32Pll_out = u32Fin_divn_mulm >> (pstcPLLCfg->u8OutputDiv);

    if ((u32Pll_out < SYSCTRL_PLL_FOUT_MIN) || (u32Pll_out > SYSCTRL_PLL_FOUT_MAX))
    {
        return ErrorInvalidParameter;
    }

    return enRet;
}

/**
 * @}
 */

/**
 * @defgroup SYSCTRL_Global_Functions SYSCTRL全局函数定义
 * @{
 */

/**
 * @brief  系统时钟计算.
 * @retval None
 */
uint32_t SystemClockUpdate(void)
{
    uint8_t u8ValDivn = 0x00u;
    uint8_t u8ValMulm = 0x00u;
    uint8_t u8ValOd = 0x00u;
    uint8_t u8RchDiv = 0x00u;
    uint32_t u32ValHclk = 0x00000000u;

    if (SYSCTRL_SYSCLK_SOURCE_XTH == REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_CLKSRC))
    {
        u32ValHclk = SYSTEM_XTH;
    }

    if (SYSCTRL_SYSCLK_SOURCE_RCL == REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_CLKSRC))
    {
        u32ValHclk = SYSCTRL_RCL_32K7;
    }

    if (SYSCTRL_SYSCLK_SOURCE_PLL == REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_CLKSRC))
    {
        if (SYSCTRL_PLL_SRC_RCH == REG_READBITS(HC_SYSCTRL->PLL, SYSCTRL_PLL_SRC))
        {
            u32ValHclk = SYSCTRL_RCH_24M;

            u8RchDiv = au32RCHFreqTable[REG_READBITS(HC_SYSCTRL->RCH, SYSCTRL_RCH_DIV) >> SYSCTRL_RCH_DIV_Pos];
            u32ValHclk = u32ValHclk / u8RchDiv;
        }
        else
        {
            u32ValHclk = SYSTEM_XTH;
        }

        u8ValDivn = (REG_READBITS(HC_SYSCTRL->PLL, SYSCTRL_PLL_DIVN) >> SYSCTRL_PLL_DIVN_Pos);
        u8ValMulm = (REG_READBITS(HC_SYSCTRL->PLL, SYSCTRL_PLL_MULM) >> SYSCTRL_PLL_MULM_Pos);
        u8ValOd = (REG_READBITS(HC_SYSCTRL->PLL, SYSCTRL_PLL_OD) >> SYSCTRL_PLL_OD_Pos);

        u32ValHclk /= u8ValDivn;
        u32ValHclk *= u8ValMulm;
        u32ValHclk >>= u8ValOd;
    }

    if (SYSCTRL_SYSCLK_SOURCE_RCH == REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_CLKSRC))
    {
        u32ValHclk = SYSCTRL_RCH_24M;

        u8RchDiv = au32RCHFreqTable[REG_READBITS(HC_SYSCTRL->RCH, SYSCTRL_RCH_DIV) >> SYSCTRL_RCH_DIV_Pos];
        u32ValHclk = u32ValHclk / u8RchDiv;
    }

    u32ValHclk = u32ValHclk >> (REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_HCLKPRS) >> SYSCTRL_CR0_HCLKPRS_Pos);

    return u32ValHclk;
}

/**
 * @brief  系统时钟源初始化
 * @param  [in]  pstcSysClkSrc 系统时钟源配置结构体指针 @ref stc_sysctrl_sysclk_source_init_t
 * @retval en_result_t:
 *         - Ok: 初始化正常
 *         - Error： 初始化异常
 */
en_result_t SYSCTRL_SysClkSrcInit(stc_sysctrl_sysclk_source_init_t *pstcSysClkSrc)
{
    en_result_t enRet = Ok;
    uint32_t rch_div_value = 0, rch_trim_value = 0, rcl_waitcycle_value = 0, rcl_trim_value = 0;
    stc_sysctrl_pll_cfg_t pll_cfg = {0};

    /* RCH Configuration */
    if (pstcSysClkSrc->u32SysClkSourceType & SYSCTRL_SYSCLK_SOURCE_TYPE_RCH)
    {
        rch_div_value = (pstcSysClkSrc->u32RCHState) & RCH_DIV_WIDTH;
        rch_trim_value = (pstcSysClkSrc->u32RCHState >> SYSCTRL_RCH_DIV_BIT_SIZE) & RCH_TRIM_WIDTH;

        REG_WRITE(HC_SYSCTRL->RCH, rch_div_value);
        REG_WRITE(HC_SYSCTRL->RCHTRIM, rch_trim_value);

        SysctrlUnlock();
        REG_SETBITS(HC_SYSCTRL->CR2, SYSCTRL_CR2_RCH);
        while (FALSE == !!REG_READBITS(HC_SYSCTRL->STATE, SYSCTRL_STATE_RCH))
        {
        }
    }

    /* XTH Configuration */
    if (pstcSysClkSrc->u32SysClkSourceType & SYSCTRL_SYSCLK_SOURCE_TYPE_XTH)
    {
        REG_WRITE(HC_SYSCTRL->XTH, pstcSysClkSrc->u32XTHState);
        SysctrlUnlock();
        REG_SETBITS(HC_SYSCTRL->CR2, SYSCTRL_CR2_XTH);
        while (FALSE == !!REG_READBITS(HC_SYSCTRL->STATE, SYSCTRL_STATE_XTH))
        {
        }
    }

    /* RCL Configuration */
    if (pstcSysClkSrc->u32SysClkSourceType & SYSCTRL_SYSCLK_SOURCE_TYPE_RCL)
    {
        rcl_waitcycle_value = (pstcSysClkSrc->u32RCLState) & RCH_WAIT_CYCLE_WIDTH;
        rcl_trim_value = (pstcSysClkSrc->u32RCLState >> SYSCTRL_RCL_WAITCYCLE_BIT_SIZE) & RCL_TRIM_WIDTH;

        REG_WRITE(HC_SYSCTRL->RCL, rcl_waitcycle_value);
        REG_WRITE(HC_SYSCTRL->RCLTRIM, rcl_trim_value);

        SysctrlUnlock();
        REG_SETBITS(HC_SYSCTRL->CR2, SYSCTRL_CR2_RCL);
        while (FALSE == !!REG_READBITS(HC_SYSCTRL->STATE, SYSCTRL_STATE_RCL))
        {
        }
    }

    /* PLL Configuration */
    if (pstcSysClkSrc->u32SysClkSourceType & SYSCTRL_SYSCLK_SOURCE_TYPE_PLL)
    {
        pll_cfg.u8Source = ((pstcSysClkSrc->u32PLLState & SYSCTRL_PLL_SRC_Msk) >> SYSCTRL_PLL_SRC_Pos);
        pll_cfg.u8OutputDiv = ((pstcSysClkSrc->u32PLLState & SYSCTRL_PLL_OD_Msk) >> SYSCTRL_PLL_OD_Pos);
        pll_cfg.u8DIVN = ((pstcSysClkSrc->u32PLLState & SYSCTRL_PLL_DIVN_Msk) >> SYSCTRL_PLL_DIVN_Pos);
        pll_cfg.u8MulM = ((pstcSysClkSrc->u32PLLState & SYSCTRL_PLL_MULM_Msk) >> SYSCTRL_PLL_MULM_Pos);

        if (ErrorInvalidParameter == Sysctrl_PLL_Para_Check(&pll_cfg))
        {
            enRet = Error;
            return enRet;
        }

        REG_WRITE(HC_SYSCTRL->PLL, pstcSysClkSrc->u32PLLState);
        SysctrlUnlock();
        REG_SETBITS(HC_SYSCTRL->CR2, SYSCTRL_CR2_PLL);
        while (FALSE == !!REG_READBITS(HC_SYSCTRL->STATE, SYSCTRL_STATE_PLL))
        {
        }
    }

    return enRet;
}

/**
 * @brief  系统时钟初始化
 * @param  [in]  pstcSysClk 系统时钟配置结构体指针 @ref stc_sysctrl_clk_init_t
 * @retval en_result_t:
 *         - Ok: 初始化正常
 *         - Error： 初始化异常
 */
en_result_t SYSCTRL_SysClkInit(stc_sysctrl_clk_init_t *pstcSysClk)
{
    /* HCLK = SYSCLK / DIV */
    if (pstcSysClk->u32ClockType & SYSCTRL_CLOCKTYPE_HCLK)
    {
        SysctrlUnlock();
        REG_MODIFY(HC_SYSCTRL->CR0, SYSCTRL_CR0_HCLKPRS, pstcSysClk->u32HClkDiv);
    }

    /* PCLK0 = HCLK / DIV0 */
    if (pstcSysClk->u32ClockType & SYSCTRL_CLOCKTYPE_PCLK0)
    {
        SysctrlUnlock();
        REG_MODIFY(HC_SYSCTRL->CR0, SYSCTRL_CR0_PCLK0PRS, pstcSysClk->u32PClk0Div);
    }

    /* PCLK1 = HCLK / DIV1 */
    if (pstcSysClk->u32ClockType & SYSCTRL_CLOCKTYPE_PCLK1)
    {
        SysctrlUnlock();
        REG_MODIFY(HC_SYSCTRL->CR0, SYSCTRL_CR0_PCLK1PRS, pstcSysClk->u32PClk1Div);
    }

    if (pstcSysClk->u32WaitCycle >= (REG_READBITS(HC_FLASH->WAIT, FLASH_WAIT_WAIT) >> FLASH_WAIT_WAIT_Pos))
    {
        Flash_WaitCycle((en_flash_waitcycle_t)pstcSysClk->u32WaitCycle);
    }

    /* System Clock Source */
    if (pstcSysClk->u32ClockType & SYSCTRL_CLOCKTYPE_SYSCLK)
    {
        SysctrlUnlock();
        REG_MODIFY(HC_SYSCTRL->CR0, SYSCTRL_CR0_CLKSRC, pstcSysClk->u32SysClkSource);
    }

    if (pstcSysClk->u32WaitCycle < (REG_READBITS(HC_FLASH->WAIT, FLASH_WAIT_WAIT) >> FLASH_WAIT_WAIT_Pos))
    {
        Flash_WaitCycle((en_flash_waitcycle_t)pstcSysClk->u32WaitCycle);
    }

    SystemHCLK = SystemClockUpdate();

    SystemCoreClock = SystemHCLK;

    return Ok;
}

/**
 * @brief  系统时钟 HCLK 频率获取
 * @retval uint32_t:
 *         - HCLK频率值(Hz)
 */
uint32_t Sysctrl_GetHClk(void)
{
    uint32_t u32ValHclk;

    u32ValHclk = SystemClockUpdate();

    return u32ValHclk;
}

/**
 * @brief  系统时钟 PCLK0 频率获取
 * @retval uint32_t:
 *         - PCLK0频率值(Hz)
 */
uint32_t SYSCTRL_GetPCLK0(void)
{
    uint32_t u32ValHclk, u32ValPclk0;

    u32ValHclk = SystemClockUpdate();
    u32ValPclk0 = u32ValHclk >> (REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_PCLK0PRS) >> SYSCTRL_CR0_PCLK0PRS_Pos);

    return u32ValPclk0;
}

/**
 * @brief  系统时钟 PCLK1 频率获取
 * @retval uint32_t:
 *         - PCLK1频率值(Hz)
 */
uint32_t SYSCTRL_GetPCLK1(void)
{
    uint32_t u32ValHclk, u32ValPclk1;

    u32ValHclk = SystemClockUpdate();
    u32ValPclk1 = u32ValHclk >> (REG_READBITS(HC_SYSCTRL->CR0, SYSCTRL_CR0_PCLK1PRS) >> SYSCTRL_CR0_PCLK1PRS_Pos);

    return u32ValPclk1;
}

/**
 * @brief  系统功能开关控制
 * @param  [in]  enFunc     系统功能枚举类型 @ref en_sysctrl_func_t
 * @retval en_result_t:
 *         - Ok: 设定成功
 *         - Error： 设定失败
 */
en_result_t SYSCTRL_Func_Ctrl(en_sysctrl_func_t enFunc, boolean_t bFlag)
{
    if (enFunc & _SYSCTRL_FUNC_MSK)
    {
        enFunc &= ~_SYSCTRL_FUNC_MSK;
        SysctrlUnlock();
        REG_MODIFY(HC_SYSCTRL->CR2, 1u << ((uint32_t)enFunc), ((uint32_t)bFlag) << ((uint32_t)enFunc));
    }
    else
    {
        SysctrlUnlock();
        REG_MODIFY(HC_SYSCTRL->CR1, 1u << ((uint32_t)enFunc), ((uint32_t)bFlag) << ((uint32_t)enFunc));
    }
    return Ok;
}

/**
 * @brief  设置外设时钟门控使能
 * @param  [in]   enPeripheral   目标外设  @ref en_sysctrl_peripheral_gate_t
 * @retval en_result_t:
 *         - Ok: 设定成功
 *         - Error： 设定失败
 */
en_result_t SYSCTRL_PeriphClkEnable(en_sysctrl_peripheral_gate_t enPeripheral)
{
    boolean_t bFlag = TRUE;

    if (enPeripheral & _PERICLK_REG3_MSK)
    {
        enPeripheral &= ~_PERICLK_REG3_MSK;
        REG_MODIFY(HC_SYSCTRL->AHB1EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }
    else if (enPeripheral & _PERICLK_REG2_MSK)
    {
        enPeripheral &= ~_PERICLK_REG2_MSK;
        REG_MODIFY(HC_SYSCTRL->AHB0EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }
    else if (enPeripheral & _PERICLK_REG1_MSK)
    {
        enPeripheral &= ~_PERICLK_REG1_MSK;
        REG_MODIFY(HC_SYSCTRL->APB1EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }
    else
    {
        REG_MODIFY(HC_SYSCTRL->APB0EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }

    return Ok;
}

/**
 * @brief  设置外设时钟门控关闭
 * @param  [in]   enPeripheral   目标外设  @ref en_sysctrl_peripheral_gate_t
 * @retval en_result_t:
 *         - Ok: 设定成功
 *         - Error： 设定失败
 */
en_result_t SYSCTRL_PeriphClkDisable(en_sysctrl_peripheral_gate_t enPeripheral)
{
    boolean_t bFlag = FALSE;

    if (enPeripheral & _PERICLK_REG3_MSK)
    {
        enPeripheral &= ~_PERICLK_REG3_MSK;
        REG_MODIFY(HC_SYSCTRL->AHB1EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }
    else if (enPeripheral & _PERICLK_REG2_MSK)
    {
        enPeripheral &= ~_PERICLK_REG2_MSK;
        REG_MODIFY(HC_SYSCTRL->AHB0EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }
    else if (enPeripheral & _PERICLK_REG1_MSK)
    {
        enPeripheral &= ~_PERICLK_REG1_MSK;
        REG_MODIFY(HC_SYSCTRL->APB1EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }
    else
    {
        REG_MODIFY(HC_SYSCTRL->APB0EN, 1u << ((uint32_t)enPeripheral), ((uint32_t)bFlag) << ((uint32_t)enPeripheral));
    }

    return Ok;
}

/**
 * @brief  系统外设复位
 * @param  [in]   u32PeriphReset 系统外设复位 @ref SYSCTRL_PRI_RESET
 * @retval en_result_t:
 *         - Ok: 设定成功
 *         - Error： 设定失败
 */
en_result_t SYSCTRL_PeriphReset(uint32_t u32PeriphReset)
{
    if (u32PeriphReset & _PERICLK_REG3_MSK)
    {
        u32PeriphReset &= ~_PERICLK_REG3_MSK;
        REG_CLEARBITS(HC_SYSCTRL->AHB1RST, 1u << ((uint32_t)u32PeriphReset));
        REG_SETBITS(HC_SYSCTRL->AHB1RST, 1u << ((uint32_t)u32PeriphReset));
    }
    else if (u32PeriphReset & _PERICLK_REG2_MSK)
    {
        u32PeriphReset &= ~_PERICLK_REG2_MSK;
        REG_CLEARBITS(HC_SYSCTRL->AHB0RST, 1u << ((uint32_t)u32PeriphReset));
        REG_SETBITS(HC_SYSCTRL->AHB0RST, 1u << ((uint32_t)u32PeriphReset));
    }
    else if (u32PeriphReset & _PERICLK_REG1_MSK)
    {
        u32PeriphReset &= ~_PERICLK_REG1_MSK;
        REG_CLEARBITS(HC_SYSCTRL->APB1RST, 1u << ((uint32_t)u32PeriphReset));
        REG_SETBITS(HC_SYSCTRL->APB1RST, 1u << ((uint32_t)u32PeriphReset));
    }
    else
    {
        REG_CLEARBITS(HC_SYSCTRL->APB0RST, 1u << ((uint32_t)u32PeriphReset));
        REG_SETBITS(HC_SYSCTRL->APB0RST, 1u << ((uint32_t)u32PeriphReset));
    }

    return Ok;
}

/**
 * @brief  系统复位标志清除
 * @param  [in]   u32ResetFlag 系统复位标志 @ref Sysctrl_Reset_Flag
 * @retval None
 */
void SYSCTRL_ResetFlagClear(uint32_t u32ResetFlag)
{
    REG_CLEARBITS(HC_SYSCTRL->RESETFLAG, u32ResetFlag);
}

/**
 * @brief  系统复位标志获取
 * @param  [in]   u32ResetFlag 系统复位标志
 * @retval uint32_t:
 *         - 复位标志
 */
uint32_t SYSCTRL_ResetFlagGet(uint32_t u32ResetFlag)
{
    return REG_READBITS(HC_SYSCTRL->RESETFLAG, u32ResetFlag);
}

/**
 * @brief  系统调试功能控制使能
 * @param  [in]   u32DebugModule 系统复位标志  @ref Sysctrl_Debug_Module
 * @retval None
 */
void SYSCTRL_DebugEnable(uint32_t u32DebugModule)
{
    REG_SETBITS(HC_SYSCTRL->DEBUG, u32DebugModule);
}

/**
 ** \brief 系统调试功能控制禁止
 ** \param [in]  u32DebugModule 系统复位标志 @ref Sysctrl_Debug_Module
 ** \retval None
 */
void SYSCTRL_DebugDisable(uint32_t u32DebugModule)
{
    REG_CLEARBITS(HC_SYSCTRL->DEBUG, u32DebugModule);
}

/**
 ** \brief 获取芯片相关信息
 ** \param [in]  pstcChipInfo 芯片信息结构体指针 @ref stc_sysctrl_chip_info_t
 ** \retval None
 */
void SYSCTRL_GetChipInfo(stc_sysctrl_chip_info_t *pstcChipInfo)
{
    memcpy((void *)(&pstcChipInfo->u8UID[0]), (uint8_t *)0x010014E0, 0x06);
    pstcChipInfo->pcProductNumber = (char_t *)0x01001140;
    pstcChipInfo->u32FlashSize = *((uint32_t *)0x01001160);
    pstcChipInfo->u32RamSize = *((uint32_t *)0x01001164);
    pstcChipInfo->u16PinCount = *((uint16_t *)0x0100116A);
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
