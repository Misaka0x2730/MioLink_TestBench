/**
 *******************************************************************************
 * @file  lvd.c
 * @brief This file provides firmware functions to manage the LVD.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2024-10-25       MADS            Delete local pre-processor macros
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "lvd.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_LVD LVD子模块驱动库
 * @brief LVD Driver Library LVD子模块驱动库
 * @{
 */

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')        *
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 *****************************************************************************/
/**
 * @defgroup LVD_Global_Functions LVD全局函数定义
 * @{
 */

/**
 * @brief  LVD初始化.
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @param  [in] pstcInitCfg: LVD配置指针 @ref stc_lvd_init_t
 * @retval en_result_t:
 *         - ErrorInvalidParameter: 非法参数
 *         - Ok: 初始化成功
 */
en_result_t LVD_Init(LVD_TypeDef* LVDx, stc_lvd_init_t* pstcInitCfg)
{
    if (NULL == pstcInitCfg)
    {
        return ErrorInvalidParameter;
    }

    REG_MODIFY(LVDx->CR, LVD_CR_ACT | LVD_CR_HTEN | LVD_CR_RTEN | LVD_CR_FTEN | LVD_CR_SOURCE | LVD_CR_VTDS | LVD_CR_FLTEN | LVD_CR_FLTTIME, pstcInitCfg->u32TriggerAction | pstcInitCfg->u32TriggerMode | pstcInitCfg->u32InputSource | pstcInitCfg->u32ThresholdVolt | pstcInitCfg->u32Filter);

    return Ok;
}

/**
 * @brief  开启LVD模块.
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_Enable(LVD_TypeDef* LVDx)
{
    REG_SETBITS(LVDx->CR, LVD_CR_EN);
}

/**
 * @brief  关闭LVD模块.
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_Disable(LVD_TypeDef* LVDx)
{
    REG_CLEARBITS(LVDx->CR, LVD_CR_EN);
}

/**
 * @brief  检查LVD模块 是否已开启.
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval en_result_t:
 *         - 0:未开启
 *         - 非0:已开启
 */
uint32_t LVD_IsEnable(LVD_TypeDef* LVDx)
{
    int temp = (REG_READBITS(LVDx->CR, LVD_CR_EN) == LVD_CR_EN);
    return (uint32_t)temp;
}

/**
 * @brief  LVD触发动作选择
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @param  [in] u32TriggerAction: 触发动作选择 @ref LVD_TRIGGER_ACTION_SELECTION
 * @retval None
 */
void LVD_SetTriggerAction(LVD_TypeDef* LVDx, uint32_t u32TriggerAction)
{
    REG_MODIFY(LVDx->CR, LVD_CR_ACT, u32TriggerAction);
}

/**
 * @brief  获取LVD触发动作
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t:触发动作选择 @ref LVD_TRIGGER_ACTION_SELECTION
 */
uint32_t LVD_GetTriggerAction(LVD_TypeDef* LVDx)
{
    return (uint32_t)(REG_READBITS(LVDx->CR, LVD_CR_ACT));
}

/**
 * @brief  LVD 中断触发模式配置
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @param  [in] u32TriggerMode: 中断触发模式选择: 下述单个值或者多个值相或 @ref LVD_TRIGGER_MODE_SELECTION
 * @retval None
 */
void LVD_SetTriggerMode(LVD_TypeDef* LVDx, uint32_t u32TriggerMode)
{
    REG_MODIFY(LVDx->CR, (LVD_CR_HTEN | LVD_CR_RTEN | LVD_CR_FTEN), u32TriggerMode);
}

/**
 * @brief  获取 LVD中断触发模式
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t:中断触发模式: 下述单个值或者多个值相或 @ref LVD_TRIGGER_MODE_SELECTION
 */
uint32_t LVD_GetTriggerMode(LVD_TypeDef* LVDx)
{
    return (uint32_t)(REG_READBITS(LVDx->CR, (LVD_CR_HTEN | LVD_CR_RTEN | LVD_CR_FTEN)));
}

/**
 * @brief  LVD输入监测源配置
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @param  [in] u32InputSource: 输入监测源选择 @ref LVD_INPUT_SELECTION
 * @retval None
 */
void LVD_SetInputSource(LVD_TypeDef* LVDx, uint32_t u32InputSource)
{
    REG_MODIFY(LVDx->CR, LVD_CR_SOURCE, u32InputSource);
}

/**
 * @brief  获取LVD输入监测源
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t: 输入监测源选择 @ref LVD_INPUT_SELECTION
 */
uint32_t LVD_GetInputSource(LVD_TypeDef* LVDx)
{
    return (uint32_t)(REG_READBITS(LVDx->CR, LVD_CR_SOURCE));
}

/**
 * @brief  LVD阈值电压选择
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @param  [in] u32ThresholdVolt: 阈值电压选择 @ref LVD_THRESHOLD_VOLT_SELECTION
 * @retval None
 */
void LVD_SetThresholdVolt(LVD_TypeDef* LVDx, uint32_t u32ThresholdVolt)
{
    REG_MODIFY(LVDx->CR, LVD_CR_VTDS, u32ThresholdVolt);
}

/**
 * @brief  获取LVD阈值电压
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t: 阈值电压选择 @ref LVD_THRESHOLD_VOLT_SELECTION
 */
uint32_t LVD_GetThresholdVolt(LVD_TypeDef* LVDx)
{
    return (uint32_t)(REG_READBITS(LVDx->CR, LVD_CR_VTDS));
}

/**
 * @brief  LVD数字滤波使能
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_EnableFilter(LVD_TypeDef* LVDx)
{
    REG_SETBITS(LVDx->CR, LVD_CR_FLTEN);
}

/**
 * @brief  LVD数字滤波禁止
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_DisableFilter(LVD_TypeDef* LVDx)
{
    REG_CLEARBITS(LVDx->CR, LVD_CR_FLTEN);
}

/**
 * @brief  检查LVD数字滤波 是否已开启
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t:
 *         - 0:未开启
 *         - 非0:已开启
 */
uint32_t LVD_IsEnableFilter(LVD_TypeDef* LVDx)
{
    int temp = (REG_READBITS(LVDx->CR, LVD_CR_FLTEN) == LVD_CR_FLTEN);
    return (uint32_t)temp;
}

/**
 * @brief  电压比较器滤波配置
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @param  [in] u32Filter: 数字滤波时间配置 @ref LVD_FILTER_SELECTION
 * @retval None
 */
void LVD_SetFilter(LVD_TypeDef* LVDx, uint32_t u32Filter)
{
    REG_MODIFY(LVDx->CR, (LVD_CR_FLTTIME | LVD_CR_FLTEN), u32Filter);
}

/**
 * @brief  获取 电压比较器滤波时间
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t: 数字滤波时间配置 @ref LVD_FILTER_SELECTION
 */
uint32_t LVD_GetFilter(LVD_TypeDef* LVDx)
{
    return (uint32_t)(REG_READBITS(LVDx->CR, (LVD_CR_FLTTIME | LVD_CR_FLTEN)));
}

/**
 * @brief  获取 滤波后的信号电平
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t: 滤波后的信号电平
 *         - 0:滤波后的信号电平为低
 *         - 1:滤波后的信号电平为高
 */
uint32_t LVD_GetFilterOutput(LVD_TypeDef* LVDx)
{
    return (uint32_t)(REG_READBITS(LVDx->SR, LVD_SR_FLTV));
}

/**
 * @brief  LVD中断使能
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_EnableIT(LVD_TypeDef* LVDx)
{
    REG_SETBITS(LVDx->CR, LVD_CR_IE);
}

/**
 * @brief  LVD中断禁止
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_DisableIT(LVD_TypeDef* LVDx)
{
    REG_CLEARBITS(LVDx->CR, LVD_CR_IE);
}

/**
 * @brief  检查LVD中断 是否已使能
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t:
 *         - 0:未开启
 *         - 1:已开启
 */
uint32_t LVD_IsEnableIT(LVD_TypeDef* LVDx)
{
    int temp = (REG_READBITS(LVDx->CR, LVD_CR_IE) == LVD_CR_IE);
    return (uint32_t)temp;
}

/**
 * @brief  获取 中断标志
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval uint32_t:
 *         - 0:中断事件未发生
 *         - 1:中断事件发生
 */
uint32_t LVD_IsActiveFlag_IT(LVD_TypeDef* LVDx)
{
    int temp = (REG_READBITS(LVDx->SR, LVD_SR_INTF) == LVD_SR_INTF);
    return (uint32_t)temp;
}

/**
 * @brief  清除 中断标志
 * @param  [in] LVDx: LVD结构体 @ref LVD_TypeDef
 * @retval None
 */
void LVD_ClearFlag_IT(LVD_TypeDef* LVDx)
{
    REG_CLEARBITS(LVDx->SR, LVD_SR_INTF);
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 * EOF (not truncated)
 *****************************************************************************/
