/**
 *******************************************************************************
 * @file  vc.c
 * @brief This file provides firmware functions to manage the VC.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2024-10-24       MADS            Modify comments of VC_GetFilterOutput()
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "vc.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_VC VC子模块驱动库
 * @brief VC Driver Library VC子模块驱动库
 * @{
 */

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 *****************************************************************************/

/**
 * @defgroup VC_Global_Variables VC全局变量定义
 * @{
 */

/**
 * @brief  VC初始化.
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  pstcInitCfg : VC 初始化结构体变量 @ref stc_vc_init_cfg_t
 * @retval en_result_t:
 *           - ErrorInvalidParameter: 参数不合理
 *           - Ok: 初始化成功
 */
en_result_t VC_Init(VC_TypeDef *VCx, stc_vc_init_cfg_t *pstcInitCfg)
{
    if (NULL == pstcInitCfg)
    {
        return ErrorInvalidParameter;
    }

    REG_MODIFY(VCx->CR0,
               VC_CR0_BIAS | VC_CR0_HYS,
               pstcInitCfg->u32VcBiasCurrent | pstcInitCfg->u32VcCmpDly);

    REG_MODIFY(VCx->CR1,
               VC_CR1_PSEL | VC_CR1_NSEL | VC_CR1_FLTEN | VC_CR1_FLTTIME | VC_CR1_FLTCLK,
               pstcInitCfg->u32VcInPin_P | pstcInitCfg->u32VcInPin_N | pstcInitCfg->u32VcFilter);

    REG_MODIFY(VCx->CR2, VC_CR2_POL, pstcInitCfg->u32VcOutCfg);

    return Ok;
}

/**
 * @brief  VC 内置电阻分压配置，作为电压比较器“-”端输入时，使用此函数
 *         配置相关参数
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  pstcResVoltDivCfg : VC 电阻分压配置结构体变量 @ref stc_vc_res_volt_div_cfg_t
 * @retval en_result_t:
 *           - ErrorInvalidParameter: 参数不合理
 *           - Ok: 初始化成功
 */
en_result_t VC_ResVoltDivConfig(VC_TypeDef *VCx, stc_vc_res_volt_div_cfg_t *pstcResVoltDivCfg)
{
    if (NULL == pstcResVoltDivCfg)
    {
        return ErrorInvalidParameter;
    }

    REG_MODIFY(VCx->CR0,
               VC_CR0_DIV | VC_CR0_DIVEN | VC_CR0_REF,
               (pstcResVoltDivCfg->u32VcRefVoltDiv << VC_CR0_DIV_Pos) | (VC_CR0_DIVEN) | (pstcResVoltDivCfg->u32VcRefVolt << VC_CR0_REF_Pos));

    return Ok;
}

/**
 * @brief  设定VC 参考电压的分压比例
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32RefVoltDiv : 分压比例 u32RefVoltDiv/64
 * @retval None
 */

void VC_SetRefVoltDiv(VC_TypeDef *VCx, uint32_t u32RefVoltDiv)
{
    REG_MODIFY(VCx->CR0, VC_CR0_DIV, (u32RefVoltDiv - 1));
}

/**
 * @brief  获取VC 参考电压的分压比例
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t : 分压比例的分子值，分母固定64，比如返回值为10，则分压比例是10/64
 */
uint32_t VC_GetRefVoltDiv(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR0, VC_CR0_DIV));
}

/**
 * @brief  开启VC 参考电压电路使能控制
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_EnableRefVoltDiv(VC_TypeDef *VCx)
{
    REG_SETBITS(VCx->CR0, VC_CR0_DIVEN);
}

/**
 * @brief  关闭VC 参考电压电路使能控制
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_DisableRefVoltDiv(VC_TypeDef *VCx)
{
    REG_CLEARBITS(VCx->CR0, VC_CR0_DIVEN);
}

/**
 * @brief  检查VC 参考电压电路 是否已开启
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:
 *         - 0：未开启
 *         - 非0：已开启
 */
uint32_t VC_IsEnableRefVoltDiv(VC_TypeDef *VCx)
{
    int temp = (REG_READBITS(VCx->CR0, VC_CR0_DIVEN) == VC_CR0_DIVEN);
    return (uint32_t)temp;
}

/**
 * @brief  设定VC 电阻分压电路参考电压选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32RefVolt :  参考电压选择 @ref VC_REF_VOLT_SELECTION
 * @retval None
 */
void VC_SetRefVolt(VC_TypeDef *VCx, uint32_t u32RefVolt)
{
    REG_MODIFY(VCx->CR0, VC_CR0_REF, u32RefVolt);
}

/**
 * @brief  获取VC 电阻分压电路参考电压选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:参考电压选择 @ref VC_REF_VOLT_SELECTION
 */
uint32_t VC_GetRefVolt(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR0, VC_CR0_REF));
}

/**
 * @brief  设定VC 偏置电流
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32BiasCurrent :  VC 偏置电流选择 @ref VC_BIAS_SELECTION
 * @retval None
 */
void VC_SetBiasCurrent(VC_TypeDef *VCx, uint32_t u32BiasCurrent)
{
    REG_MODIFY(VCx->CR0, VC_CR0_BIAS, u32BiasCurrent);
}

/**
 * @brief  获取VC 偏置电流
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :  VC 偏置电流选择 @ref VC_BIAS_SELECTION
 */
uint32_t VC_GetBiasCurrent(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR0, VC_CR0_BIAS));
}

/**
 * @brief  设定VC 迟滞电压
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32HysVolt :  VC 迟滞电压选择 @ref VC_HYSTERESIS_VOLT_SELECTION
 * @retval None
 */
void VC_SetHysteresisVolt(VC_TypeDef *VCx, uint32_t u32HysVolt)
{
    REG_MODIFY(VCx->CR0, VC_CR0_HYS, u32HysVolt);
}

/**
 * @brief  获取VC 迟滞电压
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :  VC 迟滞电压选择 @ref VC_HYSTERESIS_VOLT_SELECTION
 */
uint32_t VC_GetHysteresisVolt(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR0, VC_CR0_HYS));
}

/**
 * @brief  电压比较器“+”端输入信号选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32InputPlus :  VC “+”端输入信号选择 @ref VC_INPUT_PLUS_SELECTION
 * @retval None
 */
void VC_SetInputPlus(VC_TypeDef *VCx, uint32_t u32InputPlus)
{
    REG_MODIFY(VCx->CR1, VC_CR1_PSEL, u32InputPlus);
}

/**
 * @brief  获取电压比较器“+”端输入信号选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t: VC “+”端输入信号选择 @ref VC_INPUT_PLUS_SELECTION
 */
uint32_t VC_GetInputPlus(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR1, VC_CR1_PSEL));
}

/**
 * @brief  电压比较器“-”端输入信号选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32InputMinus :  VC “—”端输入信号选择 @ref VC_INPUT_MINUS_SELECTION
 * @retval None
 */
void VC_SetInputMinus(VC_TypeDef *VCx, uint32_t u32InputMinus)
{
    REG_MODIFY(VCx->CR1, VC_CR1_NSEL, u32InputMinus);
}

/**
 * @brief  获取电压比较器“-”端输入信号选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :  VC “—”端输入信号选择 @ref VC_INPUT_MINUS_SELECTION
 */
uint32_t VC_GetInputMinus(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR1, VC_CR1_NSEL));
}

/**
 * @brief  开启VC 滤波功能
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_EnableFilter(VC_TypeDef *VCx)
{
    REG_SETBITS(VCx->CR1, VC_CR1_FLTEN);
}

/**
 * @brief  关闭VC 滤波功能
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_DisableFilter(VC_TypeDef *VCx)
{
    REG_CLEARBITS(VCx->CR1, VC_CR1_FLTEN);
}

/**
 * @brief  检查VC 滤波功能 是否已开启
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:
 *         - 0：未开启
 *         - 非0：已开启
 */
uint32_t VC_IsEnableFilter(VC_TypeDef *VCx)
{
    int temp = (REG_READBITS(VCx->CR1, VC_CR1_FLTEN) == VC_CR1_FLTEN);
    return (uint32_t)temp;
}

/**
 * @brief  电压比较器 滤波时间配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32FilterTime :  VC 滤波时间选择 @ref VC_FILTER_TIME_SELECTION
 * @retval None
 */
void VC_SetFilterTime(VC_TypeDef *VCx, uint32_t u32FilterTime)
{
    REG_MODIFY(VCx->CR1, VC_CR1_FLTTIME, u32FilterTime);
}

/**
 * @brief  获取 电压比较器滤波时间
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:滤波时间 @ref VC_FILTER_TIME_SELECTION
 */
uint32_t VC_GetFilterTime(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR1, VC_CR1_FLTTIME));
}

/**
 * @brief  开启VC 中断使能
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32IT :  VC中断配置,下列值或下列值相或的组合 @ref VC_IT_SELECTION
 * @retval None
 */
void VC_EnableIT(VC_TypeDef *VCx, uint32_t u32IT)
{
    REG_SETBITS(VCx->CR1, (VC_CR1_IE | u32IT));
}

/**
 * @brief  关闭VC 中断使能
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32IT :  VC中断配置,下列值或下列值相或的组合 @ref VC_IT_SELECTION
 * @retval None
 */
void VC_DisableIT(VC_TypeDef *VCx, uint32_t u32IT)
{
    REG_CLEARBITS(VCx->CR1, u32IT);
}

/**
 * @brief  关闭所有VC 中断使能
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_DisableIT_ALL(VC_TypeDef *VCx)
{
    REG_CLEARBITS(VCx->CR1, (VC_CR1_IE | VC_CR1_LEVEL | VC_CR1_RISING | VC_CR1_FALLING));
}

/**
 * @brief  检查VC 中断使能 是否已开启
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32IT :  VC中断配置位 @ref VC_IT_SELECTION
 * @retval uint32_t :  VC中断配置, @ref VC_IT_SELECTION
 *         - 0：未开启
 *         - 非0：已开启
 */
uint32_t VC_IsEnableIT(VC_TypeDef *VCx, uint32_t u32IT)
{
    int temp = (REG_READBITS(VCx->CR1, (VC_CR1_IE | u32IT)) == (VC_CR1_IE | u32IT));
    return (uint32_t)temp;
}

/**
 * @brief  开启VC 模块
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_Enable(VC_TypeDef *VCx)
{
    REG_SETBITS(VCx->CR1, VC_CR1_EN);
}

/**
 * @brief  关闭VC 模块
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_Disable(VC_TypeDef *VCx)
{
    REG_CLEARBITS(VCx->CR1, VC_CR1_EN);
}

/**
 * @brief  检查VC模块 是否已开启
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:
 *         - 0：未开启
 *         - 非0：已开启
 */
uint32_t VC_IsEnable(VC_TypeDef *VCx)
{
    int temp = (REG_READBITS(VCx->CR1, VC_CR1_EN) == VC_CR1_EN);
    return (uint32_t)temp;
}

/**
 * @brief  VC滤波时钟选择
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32FilterClk :  VC 滤波时钟选择 @ref VC_FILTER_CLK_SELECTION
 * @retval None
 */
void VC_SetFilterClk(VC_TypeDef *VCx, uint32_t u32FilterClk)
{
    REG_MODIFY(VCx->CR1, VC_CR1_FLTCLK, u32FilterClk);
}

/**
 * @brief  获取VC滤波时钟
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:  VC滤波时钟 @ref VC_FILTER_CLK_SELECTION
 */
uint32_t VC_GetFilterClk(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR1, VC_CR1_FLTCLK));
}

/**
 * @brief  VCx_OUTP信号极性配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32OutputPolarity :  VC 极性配置 @ref VC_OUTPUT_POLARITY_SELECTION
 * @retval None
 */
void VC_SetOutputPolarity(VC_TypeDef *VCx, uint32_t u32OutputPolarity)
{
    REG_MODIFY(VCx->CR2, VC_CR2_POL, u32OutputPolarity);
}

/**
 * @brief  获取VCx_OUTP信号极性配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t:  VCx_OUTP信号极性 @ref VC_OUTPUT_POLARITY_SELECTION
 */
uint32_t VC_GetOutputPolarity(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR2, VC_CR2_POL));
}

/**
 * @brief  VCx滤波后信号输出到ATIM使能配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32OutputAtim :  输出到ATIM；下面单个值或多个值相或 @ref VC_OUTPUT_ATIM_SELECTION
 * @retval None
 */
void VC_SetOutputAtim(VC_TypeDef *VCx, uint32_t u32OutputAtim)
{
    REG_MODIFY(VCx->CR2, (VC_CR2_ATIM0CLR | VC_CR2_ATIM3CLR | VC_CR2_ATIMBK), u32OutputAtim);
}

/**
 * @brief  获取VCx 输出到ATIM的配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :  输出到ATIM；下面单个值或多个值相或 @ref VC_OUTPUT_ATIM_SELECTION
 */
uint32_t VC_GetOutputAtim(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR2, (VC_CR2_ATIM0CLR | VC_CR2_ATIM3CLR | VC_CR2_ATIMBK)));
}

/**
 * @brief  VC 窗口比较功能配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @param  u32WindowMode :  设置窗口比较模式； @ref VC_WINDOWMODE_CONFIG
 * @retval None
 */
void VC_SetWindowMode(VC_TypeDef *VCx, uint32_t u32WindowMode)
{
    REG_MODIFY(VCx->CR2, VC_CR2_WINDOW, u32WindowMode);
}

/**
 * @brief  获取 VC 窗口比较功能配置
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :  设置窗口比较模式； @ref VC_WINDOWMODE_CONFIG
 */
uint32_t VC_GetWindowMode(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->CR2, VC_CR2_WINDOW));
}

/**
 * @brief  获取 滤波后的信号电平
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :
 *         - 0 :      滤波后的信号电平为低
 **        - 非0 :      滤波后的信号电平为高
 */
uint32_t VC_GetFilterOutput(VC_TypeDef *VCx)
{
    return (uint32_t)(REG_READBITS(VCx->SR, VC_SR_FLTV));
}

/**
 * @brief  获取 中断标志
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval uint32_t :
 *         - 0 : 未发生中断
 **        - 1 : 发生中断
 */
uint32_t VC_IsActiveFlag_IT(VC_TypeDef *VCx)
{
    int temp = (REG_READBITS(VCx->SR, VC_SR_INTF) == VC_SR_INTF);
    return (uint32_t)temp;
}

/**
 * @brief  清除 中断标志
 * @param  VCx :  VC 结构体变量 @ref VC_TypeDef
 * @retval None
 */
void VC_ClearFlag_IT(VC_TypeDef *VCx)
{
    REG_CLEARBITS(VCx->SR, VC_SR_INTF);
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
