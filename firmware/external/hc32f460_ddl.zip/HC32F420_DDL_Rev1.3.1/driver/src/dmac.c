/**
 *******************************************************************************
 * @file  dmac.c
 * @brief This file provides firmware functions to manage the DMAC.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "dmac.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_DMAC DMAC子模块驱动库
 * @brief DMAC Driver Library DMAC子模块驱动库
 * @{
 */

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup DMAC_Global_Functions DMAC全局函数定义
 * @{
 */

/**
 * @brief  初始化DMA通道
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] pstcDmacChInit: DMA通道初始化配置结构体指针 @ref stc_dmac_channel_init_t
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval en_result_t:
 *           - Ok: 初始化成功
 *           - ErrorInvalidParameter: pstcCfg是空指针
 */

en_result_t DMACCH_Init(DMAC_TypeDef *pstcDmacChx, en_dma_channel_t channel_id,stc_dmac_channel_init_t *pstcDmacChInit)
{
    /*!< 检查通道值有效性和pstcCfg是否空指针 */
    if (NULL == pstcDmacChInit)
    {
        return ErrorInvalidParameter;
    } 

    uint32_t confa0  = (uint32_t)pstcDmacChx + CONFA_OFFSET + (((uint32_t) channel_id)<<4);
    uint32_t confb0  = (uint32_t)pstcDmacChx + CONFB_OFFSET + (((uint32_t) channel_id)<<4);
    uint32_t srcadr0 = (uint32_t)pstcDmacChx + SRCADR_OFFSET + (((uint32_t) channel_id)<<4);
    uint32_t dstadr0 = (uint32_t)pstcDmacChx + DSTADR_OFFSET + (((uint32_t) channel_id)<<4);   
    
    REG_CLEAR(*((uint32_t*)confa0));
    REG_CLEAR(*((uint32_t*)confb0));
    REG_CLEAR(*((uint32_t*)srcadr0));
    REG_CLEAR(*((uint32_t*)dstadr0));
    
    REG_WRITE(*((uint32_t*)confa0), pstcDmacChInit->u32TrigSrc|\
                                    ((pstcDmacChInit->u32BlockCnt - 1) << DMAC_CONFA0_BC_Pos) |\
                                    ((pstcDmacChInit->u32TransferCnt - 1)<< DMAC_CONFA0_TC_Pos) );

    REG_WRITE(*((uint32_t*)confb0), (uint32_t)pstcDmacChInit->u32TransferMode  |\
                                    (uint32_t)pstcDmacChInit->u32DataSize      |\
                                    (uint32_t)pstcDmacChInit->u32SrcAddrFix    |\
                                    (uint32_t)pstcDmacChInit->u32DstAddrFix    |\
                                    (uint32_t)pstcDmacChInit->u32BTCntReload   |\
                                    (uint32_t)pstcDmacChInit->u32SrcAddrReload |\
                                    (uint32_t)pstcDmacChInit->u32DstAddrReload |\
                                    (uint32_t)pstcDmacChInit->u32ChanelEnMsk);

    REG_WRITE(*((uint32_t*)srcadr0), pstcDmacChInit->u32SrcAddr);
    REG_WRITE(*((uint32_t*)dstadr0), pstcDmacChInit->u32DstAddr);

    return Ok;
}

/**
 * @brief  DMA模块使能函数，使能所有通道的操作，每个通道按照各自设置工作
 * @retval None
 */
void DMAC_Enable(void)
{
    REG_SETBITS(HC_DMAC->CONF, DMAC_CONF_EN);
}

/**
 * @brief  DMA模块功能禁止函数，所有通道禁止工作
 * @retval None
 */
void DMAC_Disable(void)
{
    REG_CLEARBITS(HC_DMAC->CONF, DMAC_CONF_EN);
}

/**
 * @brief  DMAC通道固定优先级.
 * @retval None
 */
void DMAC_PRIO_FIX(void)
{
    REG_CLEARBITS(HC_DMAC->CONF, DMAC_CONF_PRIO);
}

/**
 * @brief  DMAC通道循环优先级
 * @retval None
 */
void DMAC_PRIO_LOOP(void)
{
    REG_SETBITS(HC_DMAC->CONF, DMAC_CONF_PRIO);
}

/**
 * @brief  DMAC暂停传输(所有通道).
 * @retval None
 */
void DMAC_Pause(void)
{
    REG_SETBITS(HC_DMAC->CONF, DMAC_CONF_HALT);
}

/**
 * @brief  DMAC恢复传输(所有通道).
 * @retval None
 */
void DMAC_Resume(void)
{
    REG_CLEARBITS(HC_DMAC->CONF, DMAC_CONF_HALT);
}

/**
 * @brief  DMAC通道使能.
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_Enable(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confa0 = (uint32_t)pstcDmacChx + CONFA_OFFSET + (channel_id << 4);

    REG_SETBITS(*((uint32_t*)confa0), DMAC_CONFA1_ENS);
}

/**
 * @brief  关闭DMAC通道.
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_Disable(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confa0 = (uint32_t)pstcDmacChx + CONFA_OFFSET + (channel_id << 4);
    REG_CLEARBITS(*((uint32_t*)confa0), DMAC_CONFA1_ENS);
}

/**
 * @brief  DMAC通道软件触发传输启动.
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_Soft_Start(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confa0 = (uint32_t)pstcDmacChx + CONFA_OFFSET + (channel_id << 4);

    REG_SETBITS(*((uint32_t*)confa0), DMAC_CONFA1_ST);
}

/**
 * @brief  ：DMA通道软件 Block / Burst传输停止.
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_Soft_Stop(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confa0 = (uint32_t)pstcDmacChx + CONFA_OFFSET + (channel_id << 4);
    REG_CLEARBITS(*((uint32_t*)confa0), DMAC_CONFA1_ST);
}

/**
 * @brief  ：暂停DMA通道数据传输
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_Pause(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confa0 = (uint32_t)pstcDmacChx + CONFA_OFFSET + (channel_id << 4);
    REG_SETBITS(*((uint32_t*)confa0), DMAC_CONFA1_PAS);
}

/**
 * @brief  ：恢复DMA通道数据传输
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_Resume(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confa0 = (uint32_t)pstcDmacChx + CONFA_OFFSET + (channel_id << 4);
    REG_CLEARBITS(*((uint32_t*)confa0), DMAC_CONFA1_PAS);
}

/**
 * @brief  ：DMAC通道中断使能
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] u32IrqType: DMA中断位 @ref DMA_Irq_Type
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_EnableIrq(DMAC_TypeDef* pstcDmacChx, uint32_t u32IrqType, en_dma_channel_t channel_id)
{
    uint32_t confb0 = (uint32_t)pstcDmacChx + CONFB_OFFSET + (channel_id << 4);
    REG_SETBITS(*((uint32_t*)confb0), u32IrqType);
}

/**
 * @brief  ：DMAC通道中断禁止
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] u32IrqType: DMA中断位 @ref DMA_Irq_Type
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_DisableIrq(DMAC_TypeDef* pstcDmacChx, uint32_t u32IrqType, en_dma_channel_t channel_id)
{
    uint32_t confb0 = (uint32_t)pstcDmacChx + CONFB_OFFSET + (channel_id << 4);
    REG_CLEARBITS(*((uint32_t*)confb0), u32IrqType);
}

/**
 * @brief  ：DMAC通道状态类型获取
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval uint32_t:dma中断状态 @ref DMA_Status
 */
uint32_t DMACCH_GetStatus(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t dma_irq = 0U;
    uint32_t confb0  = (uint32_t)pstcDmacChx + CONFB_OFFSET + (channel_id << 4);

    dma_irq = (REG_READBITS(*((uint32_t*)confb0), DMAC_CONFB1_STAT));
    return (uint32_t)dma_irq;
}

/**
 * @brief  ：DMAC通道状态清除
 * @param  [in] pstcDmacChx: DMA通道寄存器 @ref DMAC_TypeDef
 * @param  [in] channel_id: 指定DMA通道 @ref en_dma_channel_t
 * @retval None
 */
void DMACCH_ClrStatus(DMAC_TypeDef* pstcDmacChx, en_dma_channel_t channel_id)
{
    uint32_t confb0 = (uint32_t)pstcDmacChx + CONFB_OFFSET + (channel_id << 4);
    REG_CLEARBITS(*((uint32_t*)confb0), DMAC_CONFB1_STAT);
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 * EOF (not truncated)
 *****************************************************************************/
