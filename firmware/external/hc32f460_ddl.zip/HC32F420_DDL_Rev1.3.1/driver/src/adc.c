/**
 *******************************************************************************
 * @file  adc.c
 * @brief This file provides firmware functions to manage the ADC.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2024-05-08       MADS            Modify u32ChCnt range to 1~16 for
                                    ADC_Set_SQR_ChCnt()
   2024-12-23       MADS            Modify ADC_Threshold_Cmp_Cfg()
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_ADC ADC子模块驱动库
 * @brief ADC Driver Library ADC子模块驱动库
 * @{
 */

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup ADC_Global_Functions ADC全局函数定义
 * @{
 */

/**
 * @brief  ADC初始化.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] pstcAdcCfg: 初始化参数 @ref stc_adc_cfg_t
 * @retval en_result_t:
 *           - ErrorInvalidParameter: 参数不合理
 *           - Ok: 执行成功
 */
en_result_t ADC_Init(ADC_TypeDef* ADCx, stc_adc_cfg_t* pstcAdcCfg)
{
    if (NULL == pstcAdcCfg)
    {
        return ErrorInvalidParameter;
    }

    REG_SETBITS(ADCx->CR0, ADC_CR0_EN);
    delay10us(2u); /* ADC使能 */

    REG_MODIFY(ADCx->CR0, ADC_CR0_CKDIV | ADC_CR0_REF | ADC_CR0_BUF | ADC_CR0_SAM, pstcAdcCfg->AdcClkDiv | pstcAdcCfg->AdcRefVolSel | pstcAdcCfg->AdcOpBuf | pstcAdcCfg->AdcSampCycleSel);

    REG_MODIFY(ADCx->CR1, ADC_CR1_MODE | ADC_CR1_ALIGN | ADC_CR1_OVMD | ADC_CR1_RACCEN, pstcAdcCfg->AdcMode | pstcAdcCfg->AdcAlign | pstcAdcCfg->OvMode | pstcAdcCfg->RaccEn);

    return Ok;
}

/**
 * @brief  ADC比较配置.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] adc_th_cfg: adc比较配置 @ref stc_adc_threshold_cfg_t
 * @retval None
 */
void ADC_Threshold_Cmp_Cfg(ADC_TypeDef* ADCx, stc_adc_threshold_cfg_t* adc_th_cfg)
{
    uint32_t Cmp_temp = (adc_th_cfg->bAdcLtCmp << ADC_CR1_LTCMP_Pos) | (adc_th_cfg->bAdcHtCmp << ADC_CR1_HTCMP_Pos) | (adc_th_cfg->bAdcRegCmp << ADC_CR1_REGCMP_Pos);

    ADC_SetThresholdCh(ADCx, (adc_th_cfg->SampChSel));
    ADC_SetThresholdCompare(ADCx, (Cmp_temp));
    ADC_SetHighThreshold(ADCx, adc_th_cfg->u32AdcHighThd);
    ADC_SetLowThreshold(ADCx, adc_th_cfg->u32AdcLowThd);
}

/**
 * @brief  ADC TS(温度传感器)模块使能.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_TS_Enable(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->BGR, ADC_BGR_TSEN);
}

/**
 * @brief  ADC TS(温度传感器)模块关闭.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_TS_Disable(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->BGR, ADC_BGR_TSEN);
}

/**
 * @brief  查询ADC TS(温度传感器)模块状态
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *         - 0: TS模块关闭
 *         - 1: TS模块使能
 */
uint32_t ADC_IsEnable_TS(ADC_TypeDef* ADCx)
{
    int temp = (REG_READBITS(ADCx->BGR, ADC_BGR_TSEN) == ADC_BGR_TSEN);
    return (uint32_t)temp;
}

/**
 * @brief  ADC BGR模块使能.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_BGR_Enable(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->BGR, ADC_BGR_BGREN);
    delay10us(2u);
}

/**
 * @brief  ADC BGR模块关闭.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_BGR_Disable(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->BGR, ADC_BGR_BGREN);
}

/**
 * @brief  查询ADC BGR模块状态
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *         - 0: BGR模块关闭
 *         - 1: BGR模块使能
 */
uint32_t ADC_IsEnable_BGR(ADC_TypeDef* ADCx)
{
    int temp = (REG_READBITS(ADCx->BGR, ADC_BGR_BGREN) == ADC_BGR_BGREN);
    return (uint32_t)temp;
}

/**
 * @brief  ADC使能.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Enable(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->CR0, ADC_CR0_EN);
    delay10us(2u);
}

/**
 * @brief  ADC关闭.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Disable(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->CR0, ADC_CR0_EN);
}

/**
 * @brief  查询ADC模块使能状态
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *         - 0: ADC模块关闭
 *         - 1: ADC模块使能
 */
uint32_t ADC_IsEnable(ADC_TypeDef* ADCx)
{
    int temp = (REG_READBITS(ADCx->CR0, ADC_CR0_EN) == ADC_CR0_EN);
    return (uint32_t)temp;
}

/**
 * @brief  ADC时钟分频.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32ClockDiv: ADC Clock 分频系数 @ref ADC_CLOCK_SELECTION
 * @retval None
 */
void ADC_SetClockDiv(ADC_TypeDef* ADCx, uint32_t u32ClockDiv)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_CKDIV, u32ClockDiv);
}

/**
 * @brief  ADC参考电压选择.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: ADC Clock 分频系数 @ref ADC_CLOCK_SELECTION
 */
uint32_t ADC_GetClockDiv(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_CKDIV));
}

/**
 * @brief  ADC单通道采集转换通道选择.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32sglmux: ADC 单通道转换通道选择 @ref ADC_SGLMUX_SELECTION
 * @retval None
 */
void ADC_SetSglMux(ADC_TypeDef* ADCx, uint32_t u32sglmux)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_SGLMUX, (u32sglmux << ADC_CR0_SGLMUX_Pos));
}

/**
 * @brief  获取ADC单通道采集转换所选通道.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: ADC 单通道转换通道选择 @ref ADC_SGLMUX_SELECTION
 */
uint32_t ADC_GetSglMux(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_SGLMUX));
}

/**
 * @brief  ADC参考电压选择.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32RefVol: 参考电压 @ref ADC_REF_VOLTAGE_SELECTION
 * @retval None
 */
void ADC_SetRefVol(ADC_TypeDef* ADCx, uint32_t u32RefVol)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_REF, u32RefVol);
}

/**
 * @brief  查询ADC参考电压.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:参考电压 @ref ADC_REF_VOLTAGE_SELECTION
 */
uint32_t ADC_GetRefVol(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_REF));
}

/**
 * @brief  开启ADC BUF.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_EnableBuf(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->CR0, ADC_BUFF_ENABLE);
}

/**
 * @brief  关闭ADC BUF.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_DisableBuf(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->CR0, ADC_BUFF_ENABLE);
}

/**
 * @brief  查询ADC BUF状态
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *         - 0: ADC BUF关闭
 *         - 1: ADC BUF使能
 */
uint32_t ADC_IsEnableBuf(ADC_TypeDef* ADCx)
{
    int temp = (REG_READBITS(ADCx->CR0, ADC_BUFF_ENABLE) == ADC_BUFF_ENABLE);
    return (uint32_t)temp;
}

/**
 * @brief  设定ADC采样周期.
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] uint32_t: 采样周期 @ref ADC_SAMPLINGTIME_CYCLE_SELECTION
 * @retval None
 */
void ADC_SetSampCycle(ADC_TypeDef* ADCx, uint32_t u32SampCycle)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_SAM, u32SampCycle);
}

/**
 * @brief  获取ADC采样周期
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:采样周期 @ref ADC_SAMPLINGTIME_CYCLE_SELECTION
 */
uint32_t ADC_GetSampCycle(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_SAM));
}

/**
* @brief  设定ADC阈值比较通道
* @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
  @param  [in] uint32_t: ADC阈值比较通道 @ref ADC_THRESHOLD_CHANNEL_SELECTION
* @retval None
*/
void ADC_SetThresholdCh(ADC_TypeDef* ADCx, uint32_t u32ThresholdCh)
{
    REG_MODIFY(ADCx->CR1, ADC_CR1_THCH, u32ThresholdCh);
}

/**
 * @brief  获取 ADC比较通道
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: 获取ADC用于进行阈值比较的通道
 */
uint32_t ADC_GetThresholdCh(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR1, ADC_CR1_THCH));
}

/**
* @brief  设定 ADC 阈值比较使能控制
* @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
  @param  [in] u32ThresholdCompare: 阈值比较使能配置
* @retval None
*/
void ADC_SetThresholdCompare(ADC_TypeDef* ADCx, uint32_t u32ThresholdCompare)
{
    REG_MODIFY(ADCx->CR1, (ADC_CR1_REGCMP | ADC_CR1_HTCMP | ADC_CR1_LTCMP), u32ThresholdCompare);
}

/**
 * @brief  获取  ADC 阈值比较配置
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: ADC 阈值比较使能配置
 */
uint32_t ADC_GetThresholdCompare(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR1, (ADC_CR1_REGCMP | ADC_CR1_HTCMP | ADC_CR1_LTCMP)));
}

/**
 * @brief  设定ADC转换模式
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32ConversionMode: ADC转换模式 @ref ADC_CONVERSION_MODE
 * @retval None
 */
void ADC_SetConversionMode(ADC_TypeDef* ADCx, uint32_t u32ConversionMode)
{
    REG_MODIFY(ADCx->CR1, ADC_CR1_MODE, u32ConversionMode);
}

/**
 * @brief  获取ADC转换模式
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: ADC转换模式 @ref ADC_CONVERSION_MODE
 */
uint32_t ADC_GetConversionMode(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR1, ADC_CR1_MODE));
}

/**
 * @brief  设定ADC转换数据对齐模式
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32DataAlignment: ADC转换数据对齐模式 @ref ADC_ALIGN
 * @retval None
 */
void ADC_SetDataAlignment(ADC_TypeDef* ADCx, uint32_t u32DataAlignment)
{
    REG_MODIFY(ADCx->CR1, ADC_CR1_ALIGN, u32DataAlignment);
}

/**
 * @brief  获取ADC转换数据对齐模式
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: ADC转换数据对齐模式 @ref ADC_ALIGN
 */
uint32_t ADC_GetDataAlignment(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR1, ADC_CR1_ALIGN));
}

/**
 * @brief  设定ADC过转换时ADC_Result存储方式
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32Overrun: ADC转换数据对齐模式 @ref ADC_OVMD
 * @retval None
 */
void ADC_SetRegOverrun(ADC_TypeDef* ADCx, uint32_t u32Overrun)
{
    REG_MODIFY(ADCx->CR1, ADC_CR1_OVMD, u32Overrun);
}

/**
 * @brief  获取ADC过转换时ADC_Result存储方式
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t: ADC过转换时ADC_Result存储方式 @ref ADC_OVMD
 */
uint32_t ADC_GetRegOverrun(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR1, ADC_CR1_OVMD));
}

/**
 * @brief  使能ADC转换结果自动累加功能
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_EnableResultAcc(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->CR1, ADC_RACCEN_ENABLE);
}

/**
 * @brief  禁止ADC转换结果自动累加功能
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_DisableResultAcc(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->CR1, ADC_RACCEN_ENABLE);
}

/**
 * @brief  检查 ADC转换结果自动累加功能 是否已开启
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *         - 0: ADC转换结果自动累加功能关闭
 *         - 1: ADC转换结果自动累加功能使能
 */
uint32_t ADC_IsEnableResultAcc(ADC_TypeDef* ADCx)
{
    int temp = (REG_READBITS(ADCx->CR1, ADC_RACCEN_ENABLE) == ADC_RACCEN_ENABLE);
    return (uint32_t)temp;
}

/**
 * @brief  ADC转换结果累加寄存器（ADC_ResultAcc）清零
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_ClearResultAccReg(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->CR1, ADC_CR1_RACCCLR);
}

/**
 * @brief  配置ADC SQR转换通道
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] sqr_u32Channel_num: SQR转换通道索引 @ref ADC_SQR_CHANNEL_SELECTION
 * @param  [in] u32AdcSampInput: 对应SQR通道的ADC输入选择 @ref ADC_SGLMUX_SELECTION
 * @retval None
 */
void ADC_SetChannelInputSource(ADC_TypeDef* ADCx, uint32_t sqr_u32Channel_num, uint32_t u32AdcSampInput)
{
    uint32_t adc_sqr_addr    = (uint32_t)(&ADCx->SQR2);
    uint32_t sqr_data_offset = ((sqr_u32Channel_num % 6) << 2) + (sqr_u32Channel_num % 6);

    if (sqr_u32Channel_num <= ADC_SQRCH5MUX)
    {
        adc_sqr_addr = (uint32_t)(&ADCx->SQR0);
    }
    else if (sqr_u32Channel_num <= ADC_SQRCH11MUX)
    {
        adc_sqr_addr = (uint32_t)(&ADCx->SQR1);
    }

    REG_MODIFY((*((uint32_t*)adc_sqr_addr)), ADC_SQR0_CH0MUX << sqr_data_offset, u32AdcSampInput << sqr_data_offset);
}

/**
 * @brief  获取 指定通道的输入选择
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] sqr_u32Channel_num: SQR转换通道索引 @ref ADC_SQR_CHANNEL_SELECTION
 * @retval en_adc_samp_ch_sel_t:  对应SQR通道的ADC输入选择 @ref ADC_SGLMUX_SELECTION
 */
uint32_t ADC_GetChannelInputSource(ADC_TypeDef* ADCx, uint32_t sqr_u32Channel_num)
{
    uint32_t adc_sqr_addr    = (uint32_t)(&ADCx->SQR2);
    uint32_t sqr_data_offset = ((sqr_u32Channel_num % 6) << 2) + (sqr_u32Channel_num % 6);

    if (sqr_u32Channel_num <= ADC_SQRCH5MUX)
    {
        adc_sqr_addr = (uint32_t)(&ADCx->SQR0);
    }
    else if (sqr_u32Channel_num <= ADC_SQRCH11MUX)
    {
        adc_sqr_addr = (uint32_t)(&ADCx->SQR1);
    }

    return (uint32_t)(REG_READBITS((*((uint32_t*)adc_sqr_addr)), (ADC_SQR0_CH0MUX << sqr_data_offset)));
}

/**
 * @brief  设定 转换通道数目
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32ChCnt:通道数目,取值范围: 1~16
 * @retval None
 */
void ADC_Set_SQR_ChCnt(ADC_TypeDef* ADCx, uint32_t u32ChCnt)
{
    REG_MODIFY(ADCx->SQR2, ADC_SQR2_CNT, ((u32ChCnt - 1) << ADC_SQR2_CNT_Pos));
}

/**
 * @brief  获取 转换通道数目
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:通道数目,取值范围: 0~15
 */
uint32_t ADC_Get_SQR_ChCnt(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->SQR2, ADC_SQR2_CNT));
}

/**
 * @brief  获取 ADC转换结果
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:转换结果
 */
uint32_t ADC_GetResult(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READ(ADCx->RESULT));
}

/**
 * @brief  获取 ADC转换结果累加值
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:转换结果
 */
uint32_t ADC_GetResultAcc(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READ(ADCx->RESULTACC));
}

/**
 * @brief  设定 ADC比较上阈值
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32HighThreshold: 上阈值:0~0x7FFF
 * @retval None
 */
void ADC_SetHighThreshold(ADC_TypeDef* ADCx, uint32_t u32HighThreshold)
{
    REG_WRITE(ADCx->HT, u32HighThreshold);
}

/**
 * @brief  获取 ADC比较上阈值
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:上阈值:0~0x7FFF
 */
uint32_t ADC_GetHighThreshold(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READ(ADCx->HT));
}

/**
 * @brief  设定 ADC比较下阈值
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32LowThreshold: 上阈值:0~0x7FFF
 * @retval None
 */
void ADC_SetLowThreshold(ADC_TypeDef* ADCx, uint32_t u32LowThreshold)
{
    REG_WRITE(ADCx->LT, u32LowThreshold);
}

/**
 * @brief  获取 ADC比较下阈值
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:上阈值:0~0x7FFF
 */
uint32_t ADC_GetLowThreshold(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READ(ADCx->LT));
}

/**
 * @brief  ADC中断使能
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32IT: 中断使能位 @ref ADC_IT_SELECTION
 * @retval None
 */
void ADC_EnableIT(ADC_TypeDef* ADCx, uint32_t u32IT)
{
    REG_SETBITS(ADCx->IER, u32IT);
}

/**
 * @brief  ADC中断禁止
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32IT: 中断使能位 @ref ADC_IT_SELECTION
 * @retval None
 */
void ADC_DisableIT(ADC_TypeDef* ADCx, uint32_t u32IT)
{
    REG_CLEARBITS(ADCx->IER, u32IT);
}

/**
 * @brief  检查 ADC中断 是否已使能
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32IT: 中断使能位 @ref ADC_IT_SELECTION
 * @retval uint32_t:
 *         - 0: ADC中断禁止
 *         - 1: ADC中断使能
 */
uint32_t ADC_IsEnableIT(ADC_TypeDef* ADCx, uint32_t u32IT)
{
    int temp = (REG_READBITS(ADCx->IER, u32IT) == u32IT);
    return (uint32_t)temp;
}

/**
 * @brief  使能顺序单通道转换完成触发DMA
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Enable_EOC_DMATransfer(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->IER, ADC_IER_DEOC);
}

/**
 * @brief  禁止顺序单通道转换完成触发DMA
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Disable_EOC_DMATransfer(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->IER, ADC_IER_DEOC);
}

/**
 * @brief  检查 顺序单通道转换完成触发DMA 是否已开启
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *         - 0: 未开启
 *         - 1: 开启
 */
uint32_t ADC_IsEnable_EOC_DMATransfer(ADC_TypeDef* ADCx)
{
    int temp = (REG_READBITS(ADCx->IER, ADC_IER_DEOC) == ADC_IER_DEOC);
    return (uint32_t)temp;
}

/**
 * @brief  检查 ADC中断标志
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32ITFlag: 中断标记 @ref ADC_FLAG_SELECTION
 * @retval uint32_t:
 *         - 0: ADC中断未发生
 *         - 1: ADC中断发生
 */
uint32_t ADC_IsActiveFlag(ADC_TypeDef* ADCx, uint32_t u32ITFlag)
{
    return (REG_READBITS(ADCx->IFR, u32ITFlag) == u32ITFlag);
}

/**
 * @brief  清除ADC中断标志位
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32ITFlag: 中断标记 @ref ADC_FLAG_SELECTION
 * @retval None
 */
void ADC_ClearFlag(ADC_TypeDef* ADCx, uint32_t u32ITFlag)
{
    REG_CLEARBITS(ADCx->ICR, u32ITFlag);
}

/**
 * @brief  清除所有中断标志位
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_ClearFlag_ALL(ADC_TypeDef* ADCx)
{
    ADCx->ICR = 0;
}

/**
 * @brief  设定ADC单次转换或顺序扫描转换外部中断触发源配置
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32ExtTriggerSource: 触发源 @ref ADC_TRIGGER_SRC_SELECT
 * @retval None
 */
void ADC_SetExtTrigger0Source(ADC_TypeDef* ADCx, uint32_t u32ExtTriggerSource)
{
    REG_WRITE(ADCx->EXTTRIGGER0, u32ExtTriggerSource);
}

/**
 * @brief  获取ADC单次转换或顺序扫描转换外部中断触发源
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:触发源 @ref ADC_TRIGGER_SRC_SELECT
 */
uint32_t ADC_GetExtTrigger0Source(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READ(ADCx->EXTTRIGGER0));
}

/**
 * @brief  设定ADC单次转换或顺序扫描转换外部中断触发延时配置
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @param  [in] u32Delaysel: 触发延时选择 @ref ADC_TRIGGER_DELAY_SELECT
 * @retval None
 */
void ADC_SetExtTrigger0_Delay_Sel(ADC_TypeDef* ADCx, uint32_t u32Delaysel)
{
    REG_WRITE(ADCx->EXTTRIGGER0, u32Delaysel);
}

/**
 * @brief  获取ADC单次转换或顺序扫描转换外部中断触发延时配置
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:触发延时选择 @ref ADC_TRIGGER_DELAY_SELECT
 */
uint32_t ADC_GetExtTrigger0_Delay_Cfg(ADC_TypeDef* ADCx)
{
    return (uint32_t)(REG_READ(ADCx->EXTTRIGGER0));
}

/**
 * @brief  启动 ADC单次转换
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Sgl_SoftStart(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->SGLSTART, ADC_SGLSTART_START);
}

/**
 * @brief  启动 ADC顺序扫描转换
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Sqr_SoftStart(ADC_TypeDef* ADCx)
{
    REG_SETBITS(ADCx->SQRSTART, ADC_SQRSTART_START);
}

/**
 * @brief  停止 ADC单次转换
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Sgl_SoftStop(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->SGLSTART, ADC_SGLSTART_START);
}

/**
 * @brief  停止 ADC顺序扫描转换
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval None
 */
void ADC_Sqr_SoftStop(ADC_TypeDef* ADCx)
{
    REG_CLEARBITS(ADCx->SQRSTART, ADC_SQRSTART_START);
}

/**
 * @brief  ADC单次转换是否正在进行
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *        - 0: 未进行ADC转换
 *         - 1: 正在进行ADC转换
 */
uint32_t ADC_Sgl_IsConversionOngoing(ADC_TypeDef* ADCx)
{
    uint32_t adc_conv_status = 0;

    adc_conv_status = REG_READBITS(ADCx->SGLSTART, ADC_SGLSTART_START);

    return adc_conv_status;
}

/**
 * @brief  ADC顺序扫描转换是否正在进行
 * @param  [in] ADCx: ADC句柄 @ref ADC_TypeDef
 * @retval uint32_t:
 *        - 0: 未进行ADC转换
 *         - 1: 正在进行ADC转换
 */
uint32_t ADC_Sqr_IsConversionOngoing(ADC_TypeDef* ADCx)
{
    uint32_t adc_conv_status = 0;

    adc_conv_status = REG_READBITS(ADCx->SQRSTART, ADC_SQRSTART_START);

    return adc_conv_status;
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/******************************************************************************
 * EOF (not truncated)
 *****************************************************************************/
