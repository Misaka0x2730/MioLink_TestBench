/**
 *******************************************************************************
 * @file  crc.c
 * @brief This file provides firmware functions to manage the CRC.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "crc.h"

/**
 * @addtogroup HC32F420_DDL 驱动库
 * @{
 */

/**
 * @defgroup DDL_CRC CRC子模块驱动库
 * @brief CRC Driver Library CRC子模块驱动库
 * @{
 */

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @defgroup CRC_Global_Functions CRC全局函数定义
 * @{
 */

/**
 * @brief  CRC16 编码(字节填充方式) 该函数主要用于生成CRC16编码
 * @param  [in] pu8Data:     待编码数据指针（字节方式输入）
 * @param  [in] u32Len:      待编码数据长度（字节数）
 * @param  [in] pu16Result:  计算结果指针
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             OK
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC16_Get8(uint8_t pu8Data[], uint32_t u32Len, uint16_t* pu16Result, uint32_t u32Timeout)
{
    uint32_t u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_CLEARBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint8_t*)(&(HC_CRC->DR))) = pu8Data[u32Index];
    }
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }

    *pu16Result = REG_READBITS(HC_CRC->RESULT, 0xFFFFU);
    return Ok;
}

/**
 * @brief  CRC16 编码(半字填充方式) 该函数主要用于生成CRC16编码
 * @param  [in] pu16Data:    待编码数据指针（半字方式输入）
 * @param  [in] u32Len:      待编码数据长度（半字数）
 * @param  [in] pu16Result:  计算结果指针
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             OK
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC16_Get16(uint16_t pu16Data[], uint32_t u32Len, uint16_t* pu16Result, uint32_t u32Timeout)
{
    uint32_t u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_CLEARBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint16_t*)(&(HC_CRC->DR))) = pu16Data[u32Index];
    }
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }

    *pu16Result = REG_READBITS(HC_CRC->RESULT, 0xFFFFU);
    return Ok;
}

/**
 * @brief  CRC16 编码(字填充方式) 该函数主要用于生成CRC16编码
 * @param  [in] pu32Data:    待编码数据指针（字方式输入）
 * @param  [in] u32Len:      待编码数据长度（字数）
 * @param  [in] pu16Result:  计算结果指针
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             OK
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC16_Get32(uint32_t pu32Data[], uint32_t u32Len, uint16_t* pu16Result, uint32_t u32Timeout)
{
    uint32_t u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_CLEARBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        HC_CRC->DR = pu32Data[u32Index];
    }
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }

    *pu16Result = REG_READBITS(HC_CRC->RESULT, 0xFFFFU);
    return Ok;
}

/**
 * @brief  CRC16 校验(字节填充方式) 该函数主要用于对数据及CRC16值进行校验
 * @param  [in] pu8Data:     待校验数据指针（字节方式输入）
 * @param  [in] u32Len:      待校验数据长度（字节数）
 * @param  [in] u16CRC:      待校验CRC16值
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             CRC校验正确
 *         - Error:          CRC校验错误
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC16_Check8(uint8_t pu8Data[], uint32_t u32Len, uint16_t u16CRC, uint32_t u32Timeout)
{
    en_result_t enResult = Ok;
    uint32_t    u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_CLEARBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint8_t*)(&(HC_CRC->DR))) = pu8Data[u32Index];
    }

    *((volatile uint16_t*)(&(HC_CRC->DR))) = u16CRC;
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    enResult = REG_READBITS(HC_CRC->CSR, CRC_CSR_FLAG) ? Ok : Error;

    return (enResult);
}

/**
 * @brief  CRC16 校验(半字填充方式) 该函数主要用于对数据及CRC16值进行校验
 * @param  [in] pu16Data:    待校验数据指针（半字方式输入）
 * @param  [in] u32Len:      待校验数据长度（半字数）
 * @param  [in] u16CRC:      待校验CRC16值
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             CRC校验正确
 *         - Error:          CRC校验错误
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC16_Check16(uint16_t pu16Data[], uint32_t u32Len, uint16_t u16CRC, uint32_t u32Timeout)
{
    en_result_t enResult = Ok;
    uint32_t    u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_CLEARBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint16_t*)(&(HC_CRC->DR))) = pu16Data[u32Index];
    }

    *((volatile uint16_t*)(&(HC_CRC->DR))) = u16CRC;
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    enResult = REG_READBITS(HC_CRC->CSR, CRC_CSR_FLAG) ? Ok : Error;

    return (enResult);
}

/**
 * @brief  CRC16 校验(字填充方式) 该函数主要用于对数据及CRC16值进行校验
 * @param  [in] pu32Data:    待校验数据指针（字方式输入）
 * @param  [in] u32Len:      待校验数据长度（字数）
 * @param  [in] u16CRC:      待校验CRC16值
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             CRC校验正确
 *         - Error:          CRC校验错误
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC16_Check32(uint32_t pu32Data[], uint32_t u32Len, uint16_t u16CRC, uint32_t u32Timeout)
{
    en_result_t enResult = Ok;
    uint32_t    u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_CLEARBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint32_t*)(&(HC_CRC->DR))) = pu32Data[u32Index];
    }

    *((volatile uint16_t*)(&(HC_CRC->DR))) = u16CRC;
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    enResult = REG_READBITS(HC_CRC->CSR, CRC_CSR_FLAG) ? Ok : Error;

    return (enResult);
}

/**
 * @brief  CRC32 编码(字节填充方式) 该函数主要用于生成CRC32编码
 * @param  [in] pu8Data:     待编码数据指针（字节方式输入）
 * @param  [in] u32Len:      待编码数据长度（字节数）
 * @param  [in] pu32Result:  计算结果指针
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             OK
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC32_Get8(uint8_t pu8Data[], uint32_t u32Len, uint32_t* pu32Result, uint32_t u32Timeout)
{
    uint32_t u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_SETBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint8_t*)(&(HC_CRC->DR))) = pu8Data[u32Index];
    }
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }

    *pu32Result = REG_READ(HC_CRC->RESULT);
    return Ok;
}

/**
 * @brief  CRC32 编码(半字填充方式) 该函数主要用于生成CRC32编码
 * @param  [in] pu16Data:    待编码数据指针（半字方式输入）
 * @param  [in] u32Len:      待编码数据长度（半字数）
 * @param  [in] pu32Result:  计算结果指针
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             OK
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC32_Get16(uint16_t pu16Data[], uint32_t u32Len, uint32_t* pu32Result, uint32_t u32Timeout)
{
    uint32_t u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_SETBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint16_t*)(&(HC_CRC->DR))) = pu16Data[u32Index];
    }
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }

    *pu32Result = REG_READ(HC_CRC->RESULT);
    return Ok;
}

/**
 * @brief  CRC32 编码(字填充方式) 该函数主要用于生成CRC32编码
 * @param  [in] pu32Data:    待编码数据指针（字方式输入）
 * @param  [in] u32Len:      待编码数据长度（字数）
 * @param  [in] pu32Result:  计算结果指针
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             OK
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC32_Get32(uint32_t pu32Data[], uint32_t u32Len, uint32_t* pu32Result, uint32_t u32Timeout)
{
    uint32_t u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_SETBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        HC_CRC->DR = pu32Data[u32Index];
    }
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }

    *pu32Result = REG_READ(HC_CRC->RESULT);
    return Ok;
}

/**
 * @brief  CRC32 校验(字节填充方式) 该函数主要用于对数据及CRC32值进行校验
 * @param  [in] pu8Data:     待校验数据指针（字节方式输入）
 * @param  [in] u32Len:      待校验数据长度（字节数）
 * @param  [in] u32CRC:      待校验CRC32值
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             CRC校验正确
 *         - Error:          CRC校验错误
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC32_Check8(uint8_t pu8Data[], uint32_t u32Len, uint32_t u32CRC, uint32_t u32Timeout)
{
    en_result_t enResult = Ok;
    uint32_t    u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_SETBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint8_t*)(&(HC_CRC->DR))) = pu8Data[u32Index];
    }

    REG_WRITE(HC_CRC->DR, u32CRC);
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    enResult = REG_READBITS(HC_CRC->CSR, CRC_CSR_FLAG) ? Ok : Error;

    return (enResult);
}

/**
 * @brief  CRC32 校验(半字填充方式) 该函数主要用于对数据及CRC32值进行校验
 * @param  [in] pu16Data:    待校验数据指针（半字方式输入）
 * @param  [in] u32Len:      待校验数据长度（半字数）
 * @param  [in] u32CRC:      待校验CRC32值
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             CRC校验正确
 *         - Error:          CRC校验错误
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC32_Check16(uint16_t pu16Data[], uint32_t u32Len, uint32_t u32CRC, uint32_t u32Timeout)
{
    en_result_t enResult = Ok;
    uint32_t    u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_SETBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        *((volatile uint16_t*)(&(HC_CRC->DR))) = pu16Data[u32Index];
    }

    REG_WRITE(HC_CRC->DR, u32CRC);
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    enResult = REG_READBITS(HC_CRC->CSR, CRC_CSR_FLAG) ? Ok : Error;

    return (enResult);
}

/**
 * @brief  CRC32 校验(字填充方式) 该函数主要用于对数据及CRC32值进行校验
 * @param  [in] pu32Data:    待校验数据指针（字方式输入）
 * @param  [in] u32Len:      待校验数据长度（字数）
 * @param  [in] u32CRC:      待校验CRC32值
 * @param  [in] u32Timeout:  等待超时时间
 * @retval en_result_t
 *         - Ok:             CRC校验正确
 *         - Error:          CRC校验错误
 *         - ErrorTimeout:   超时错误
 */
en_result_t CRC32_Check32(uint32_t pu32Data[], uint32_t u32Len, uint32_t u32CRC, uint32_t u32Timeout)
{
    en_result_t enResult = Ok;
    uint32_t    u32Index = 0;
    /* 等待当前CRC空闲 */
    uint32_t u32TimeoutCnt = 0;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    REG_SETBITS(HC_CRC->CSR, CRC_CSR_CODE);
    REG_WRITE(HC_CRC->RESULT, 0xFFFFFFFFU);
    for (u32Index = 0; u32Index < u32Len; u32Index++)
    {
        REG_WRITE(HC_CRC->DR, pu32Data[u32Index]);
    }

    REG_WRITE(HC_CRC->DR, u32CRC);
    /* 等待当前CRC计算完成 */
    u32TimeoutCnt = 0U;
    while (REG_READBITS(HC_CRC->CSR, CRC_CSR_BUSY))
    {
        u32TimeoutCnt++;
        if (u32Timeout <= u32TimeoutCnt)
        {
            /* 等待超时 */
            return ErrorTimeout;
        }
    }
    enResult = REG_READBITS(HC_CRC->CSR, CRC_CSR_FLAG) ? Ok : Error;

    return (enResult);
}

/**
 * @brief  获取CRC16计算结果
 * @retval uint16_t:         CRC16计算结果
 */
uint16_t CRC16_Get_Result(void)
{
    return REG_READBITS(HC_CRC->RESULT, 0xFFFFU);
}

/**
 * @brief  获取CRC32计算结果
 * @retval uint32_t:         CRC32计算结果
 */
uint32_t CRC32_Get_Result(void)
{
    return REG_READ(HC_CRC->RESULT);
}
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
