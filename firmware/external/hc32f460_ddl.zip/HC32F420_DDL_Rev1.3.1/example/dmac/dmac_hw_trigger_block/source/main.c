/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of Flash.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "ddl.h"
#include "dmac.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define BUFFER_SIZE 32U

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
volatile static uint32_t u32AdcRestult;
/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

static uint32_t aDstBuffer[BUFFER_SIZE];

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
static uint32_t aSrcConstBuffer[BUFFER_SIZE] =
{
  0x01020304, 0x05060708, 0x090A0B0C, 0x0D0E0F10,
  0x11121314, 0x15161718, 0x191A1B1C, 0x1D1E1F20,
  0x21222324, 0x25262728, 0x292A2B2C, 0x2D2E2F30,
  0x31323334, 0x35363738, 0x393A3B3C, 0x3D3E3F40,
  0x41424344, 0x45464748, 0x494A4B4C, 0x4D4E4F50,
  0x51525354, 0x55565758, 0x595A5B5C, 0x5D5E5F60,
  0x61626364, 0x65666768, 0x696A6B6C, 0x6D6E6F70,
  0x71727374, 0x75767778, 0x797A7B7C, 0x7D7E7F80
};
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_DMAConfig(en_dma_channel_t channel_id);
static void App_AdcPortInit(void);
static void App_AdcInit(void);
static void App_AdcSglCfg(void);

/**
 * @brief  Main function of project
 * @retval None
 */

int32_t main(void)
{
    en_dma_channel_t dma_channel = DMA_CHANNEL0;

    /* DMA通道配置 */
    App_DMAConfig(dma_channel);

    /* 配置ADC端口 */
    App_AdcPortInit();

    /* 初始化ADC */
    App_AdcInit();

    /* ADC采集序列通道配置，此处只开一个通道 */
    App_AdcSglCfg();

    /* 使能ADC的EOC触发DMA位 */
    ADC_Enable_EOC_DMATransfer(HC_ADC0);

    /* 使能ADC0 */
    ADC_Enable(HC_ADC0);

    /* 启动ADC顺序扫描转换，单通道转换完成后触发一次DMA传输 */
    ADC_Sqr_SoftStart(HC_ADC0);
    delay1ms(500);

    /* 启动ADC顺序扫描转换，单通道转换完成后触发一次DMA传输 */
    ADC_Sqr_SoftStart(HC_ADC0);
    delay1ms(500);

    /* 启动ADC顺序扫描转换，单通道转换完成后触发一次DMA传输 */
    ADC_Sqr_SoftStart(HC_ADC0);

    while (1)
    {
        delay1ms(1000);
    }
}

/**
 * @brief  DMA通道配置，通过软件触发的方式，把aSRC_Const_Buffer数组的值传输到aDST_Buffer数组中
 * @param  [in]  channel_id DMA通道 @ref en_dma_channel_t
 * @retval None
 */
static void App_DMAConfig(en_dma_channel_t channel_id)
{
    stc_dmac_channel_init_t stcDmacChInit = {0};

    stcDmacChInit.u32Priority      = DMA_FIX_PRIORITY;           /* 固定优先级 */
    stcDmacChInit.u32TrigSrc       = DMA_TRISRC_ADC0_SINGLE_EOC; /* 软件触发 */
    stcDmacChInit.u32BlockCnt      = 1;                          /* block大小为1 */
    stcDmacChInit.u32TransferCnt   = 3;                          /* block个数为3 */
    stcDmacChInit.u32TransferMode  = DMA_BLOCK_MODE;             /* block传输 */
    stcDmacChInit.u32DataSize      = DMA_DATA_WORD;              /* word(32-bit) */
    stcDmacChInit.u32SrcAddrFix    = DMA_SRCADDR_INC;            /* 源地址自增 */
    stcDmacChInit.u32DstAddrFix    = DMA_DSTADDR_INC;            /* 目标地址自增 */
    stcDmacChInit.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE;    /* 重载计数值 */
    stcDmacChInit.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE;  /* 源地址重载使能 */
    stcDmacChInit.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE;  /* 目标地址重载使能 */
    stcDmacChInit.u32SrcAddr       = (uint32_t)aSrcConstBuffer;  /* 源 buffer地址 */
    stcDmacChInit.u32DstAddr       = (uint32_t)aDstBuffer;       /* 目标 buffer地址 */
    stcDmacChInit.u32ChanelEnMsk   = DMA_KEEP_ENABLE;            /* 传输完成通道保持使能 */

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma);    /* 打开DMA时钟 */
    DMACCH_Init(HC_DMAC, channel_id, &stcDmacChInit); /* DMA初始化 */

    DMACCH_Enable(HC_DMAC, channel_id); /* 使能DMA通道channel_id */
    DMAC_Enable();                      /* 使能DMAC */
}

/**
 * @brief  ADC 采样端口初始化
 * @retval None
 */
static void App_AdcPortInit(void)
{
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* 开启GPIO外设时钟   */
    GPIO_PA00_ANALOG_SET();                          /* PA00配置为模拟输入 */
}

/**
 * @brief  ADC模块 初始化
 * @retval None
 */
static void App_AdcInit(void)
{
    stc_adc_cfg_t stcAdcCfg = {0};

    /* 第一步：开启BGR，模拟模块，必须开启BGR */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); /* 开启adc0外设时钟   */
    ADC_BGR_Enable(HC_ADC0);

    /* 第二步：ADC 初始化配置 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE;       /* ADC采样周期选择 */
    stcAdcCfg.AdcOpBuf        = ADC_BUFF_DISABLE;               /* ADC输入信号放大器控制使能 */
    stcAdcCfg.AdcRefVolSel    = ADC_REF_VOLTAGE_IN_2p5;         /* ADC参考电压选择 */
    stcAdcCfg.AdcClkDiv       = ADC_CLOCK_PCLK_DIV16;           /* ADC时钟选择 */
    stcAdcCfg.RaccEn          = ADC_RACCCLR_DISABLE;            /* ADC转换结果自动累加功能 */
    stcAdcCfg.OvMode          = ADC_OVMD_ENABLE;                /* ADC过转换时Adc_Result存储方式 */
    stcAdcCfg.AdcAlign        = ADC_RIGHT_ALIGN_ENABLE;         /* ADC转换结果对齐控制 */
    stcAdcCfg.AdcMode         = ADC_CONVERSION_MODE_SQR_SINGLE; /* ADC转换模式 */

    ADC_Init(HC_ADC0, &stcAdcCfg); /* 初始化配置 */

    /* 第三步：清除所有中断标志位 */
    ADC_ClearFlag_ALL(HC_ADC0);
}

/**
 * @brief  ADC 单次扫描模式 配置
 * @retval None
 */
static void App_AdcSglCfg(void)
{
    /* 第一步：配置通道和通道输入源 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH0MUX, ADC_Channel_Mux0_PA00); /* 配置通道0的输入源来自PA00 */

    /* 第二步：配置为1次 */
    ADC_Set_SQR_ChCnt(HC_ADC0, 0);

    /* 第三步：配置外部触发源，本应用使用软件触发模式，不需要配置硬件触发源 */
    ADC_SetExtTrigger0Source(HC_ADC0, 0x0000);

    /* 第四步：配置中断 */
    ADC_ClearFlag(HC_ADC0, ADC_FLAG_EOC); /* 清除EOC中断标志位 */

    ADC_EnableIT(HC_ADC0, ADC_IT_EOC);
    EnableNvic(ADC0_ADC1_IRQn, IrqLevel3, TRUE);
}

/**
 * @brief  ADC 中断服务程序
 * @retval None
 */
void Adc_IRQHandler(void)
{
    if (TRUE == ADC_IsActiveFlag(HC_ADC0, ADC_FLAG_EOC)) /* 判断是否产生EOC标志 */
    {
        ADC_ClearFlag(HC_ADC0, ADC_FLAG_EOC);   /* 清除EOC中断标志位 */
        u32AdcRestult = ADC_GetResult(HC_ADC0); /* 获取采样值 */
    }
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
