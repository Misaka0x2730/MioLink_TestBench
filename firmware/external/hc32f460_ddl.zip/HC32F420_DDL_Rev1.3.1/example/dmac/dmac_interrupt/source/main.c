/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of spi.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/

#include "ddl.h"
#include "dmac.h"
#include "flash.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define BUFFER_SIZE 32U
/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static uint32_t aSrcConstBuffer[BUFFER_SIZE] =
{
  0x01020304, 0x05060708, 0x090A0B0C, 0x0D0E0F10,
  0x11121314, 0x15161718, 0x191A1B1C, 0x1D1E1F20,
  0x21222324, 0x25262728, 0x292A2B2C, 0x2D2E2F30,
  0x31323334, 0x35363738, 0x393A3B3C, 0x3D3E3F40,
  0x41424344, 0x45464748, 0x494A4B4C, 0x4D4E4F50,
  0x51525354, 0x55565758, 0x595A5B5C, 0x5D5E5F60,
  0x61626364, 0x65666768, 0x696A6B6C, 0x6D6E6F70,
  0x71727374, 0x75767778, 0x797A7B7C, 0x7D7E7F80
};
static uint32_t aDstBuffer[BUFFER_SIZE];

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void    App_DMAConfig(en_dma_channel_t channel_id);
static int32_t myMemcmp(uint8_t* mem1, uint8_t* mem2, uint32_t bytesize);
static void    Error_Handle();

/**
 * @brief  Main function of project
 * @retval None
 */
int32_t main(void)
{
    en_dma_channel_t dma_channel = DMA_CHANNEL0;

    /* DMA通道配置 */
    App_DMAConfig(dma_channel);

    /* 软件启动DmaCh0 */
    DMACCH_Soft_Start(HC_DMAC, dma_channel);

    while (1)
    {
        delay1ms(1000);
        DMACCH_Soft_Start(HC_DMAC, dma_channel);
    }
}

/**
 * @brief  DMA通道配置，通过软件触发的方式，把aSRC_Const_Buffer数组的值传输到aDST_Buffer数组中
 * @param  [in]  channel_id DMA通道 @ref en_dma_channel_t
 * @retval None
 */
static void App_DMAConfig(en_dma_channel_t channel_id)
{
    stc_dmac_channel_init_t stcDmacChInit = {0};

    stcDmacChInit.u32Priority      = DMA_FIX_PRIORITY;          /* 固定优先级 */
    stcDmacChInit.u32TrigSrc       = DMA_TRISRC_SOFTWARE;       /* 软件触发 */
    stcDmacChInit.u32BlockCnt      = 1;                         /* block大小为1 */
    stcDmacChInit.u32TransferCnt   = BUFFER_SIZE;               /* block个数为32 */
    stcDmacChInit.u32TransferMode  = DMA_BURST_MODE;            /* burst传输 */
    stcDmacChInit.u32DataSize      = DMA_DATA_WORD;             /* word(32-bit) */
    stcDmacChInit.u32SrcAddrFix    = DMA_SRCADDR_INC;           /* 源地址自增 */
    stcDmacChInit.u32DstAddrFix    = DMA_DSTADDR_INC;           /* 目标地址自增 */
    stcDmacChInit.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE;   /* 重载计数值 */
    stcDmacChInit.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE; /* 源地址重载使能 */
    stcDmacChInit.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE; /* 目标地址重载使能 */
    stcDmacChInit.u32SrcAddr       = (uint32_t)aSrcConstBuffer; /* 源 buffer地址 */
    stcDmacChInit.u32DstAddr       = (uint32_t)aDstBuffer;      /* 目标 buffer地址 */
    stcDmacChInit.u32ChanelEnMsk   = DMA_KEEP_ENABLE;           /* 传输完成通道保持使能 */

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma);    /* 打开DMA时钟 */
    DMACCH_Init(HC_DMAC, channel_id, &stcDmacChInit); /* DMA初始化 */

    DMACCH_EnableIrq(HC_DMAC, DMA_IRQ_TC, channel_id); /* 开启DMA传输完成中断 */
    EnableNvic(DMA_CH0_IRQn, IrqLevel3, TRUE);         /* 配置DMA中断优先级 */

    DMACCH_Enable(HC_DMAC, channel_id); /* 使能DMA通道0 */
    DMAC_Enable();                      /* 使能DMAC */
}

/**
 * @brief  内存数据比较
 * @retval None
 */
static int32_t myMemcmp(uint8_t* mem1, uint8_t* mem2, uint32_t bytesize)
{
    int      i = 0;
    uint8_t* p = mem1;
    uint8_t* q = mem2;

    if (p == NULL || q == NULL)
        return -1;

    for (i = 0; i < bytesize; i++, p++, q++)
    {
        if (*p != *q)
        {
            return -1;
        }
    }
    return 0;
}

/**
 * @brief  错误处理函数
 * @retval None
 */
static void Error_Handle()
{
    while (1)
        ;
}

/**
 * @brief  DMA中断
 * @retval None
 */
void Dma_Ch0_IRQHandler(void)
{
    if (DMA_STATUS_FINISHED == DMACCH_GetStatus(HC_DMAC, DMA_CHANNEL0))
    {
        if (myMemcmp((uint8_t*)&aDstBuffer[0], (uint8_t*)&aSrcConstBuffer[0], BUFFER_SIZE) == -1)
        {
            Error_Handle();
        }
    }
    DMACCH_ClrStatus(HC_DMAC, DMA_CHANNEL0);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
