;*******************************************************************************
; Copyright (C) 2025, Xiaohua Semiconductor Co., Ltd. All rights reserved.
;
; This software component is licensed by XHSC under BSD 3-Clause license
; (the "License"); You may not use this file except in compliance with the
; License. You may obtain a copy of the License at:
;                    opensource.org/licenses/BSD-3-Clause
;
;/
;/*****************************************************************************/
;/*  Startup for IAR                                                          */
;/*  Version     V1.0                                                         */
;/*  Date        2025-11-24                                                   */
;/*  Target-mcu  HC32F420                                                 */
;/*****************************************************************************/


                MODULE  ?cstartup

                ;; Forward declaration of sections.
                SECTION CSTACK:DATA:NOROOT(3)

                EXTERN  __iar_program_start
                EXTERN  SystemInit
                PUBLIC  __vector_table
                EXTERN  STL_StartupTest
                
                SECTION .intvec:CODE:ROOT(8)
                DATA
__vector_table
                DCD     sfe(CSTACK)               ; Top of Stack
                DCD     Reset_Handler             ; Reset
                DCD     0                         ; NMI: not use
                DCD     HardFault_Handler         ; Hard Fault
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     SVC_Handler               ; SVCall
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     PendSV_Handler            ; PendSV
                DCD     SysTick_Handler           ; SysTick

; Numbered IRQ handler vectors

; Note: renaming to device dependent ISR function names are done in

                DCD     CTRIM_IRQHandler                    ; IRQ #0 
                DCD     VC_IRQHandler                       ; IRQ #1 
                DCD     LVD_IRQHandler                      ; IRQ #2 
                DCD     GPIOA_IRQHandler                    ; IRQ #3 
                DCD     GPIOB_IRQHandler                    ; IRQ #4 
                DCD     GPIOC_IRQHandler                    ; IRQ #5 
                DCD     GPIOD_IRQHandler                    ; IRQ #6 
                DCD     IWDT_IRQHandler                     ; IRQ #7 
                DCD     WWDT_IRQHandler                     ; IRQ #8 
                DCD     CLK_FAULT_IRQHandler                ; IRQ #9 
                DCD     ADC_IRQHandler                      ; IRQ #10
                DCD     FLASHCFG_IRQHandler                 ; IRQ #11
                DCD     USART0_RX_IRQHandler                ; IRQ #12
                DCD     USART0_TX_IRQHandler                ; IRQ #13
                DCD     USART0_FLAG_IRQHandler              ; IRQ #14
                DCD     USART1_RX_IRQHandler                ; IRQ #15
                DCD     USART1_TX_IRQHandler                ; IRQ #16
                DCD     USART1_FLAG_IRQHandler              ; IRQ #17
                DCD     USART2_RX_IRQHandler                ; IRQ #18
                DCD     USART2_TX_IRQHandler                ; IRQ #19
                DCD     USART2_FLAG_IRQHandler              ; IRQ #20
                DCD     USART3_RX_IRQHandler                ; IRQ #21
                DCD     USART3_TX_IRQHandler                ; IRQ #22
                DCD     USART3_FLAG_IRQHandler              ; IRQ #23
                DCD     I2C0_IRQHandler                     ; IRQ #24
                DCD     I2C1_IRQHandler                     ; IRQ #25
                DCD     SPI0_TX_IRQHandler                  ; IRQ #26
                DCD     SPI0_RX_IRQHandler                  ; IRQ #27
                DCD     SPI0_SSR_IRQHandler                 ; IRQ #28
                DCD     SPI0_ERR_IRQHandler                 ; IRQ #29
                DCD     SPI1_TX_IRQHandler                  ; IRQ #30
                DCD     SPI1_RX_IRQHandler                  ; IRQ #31
                DCD     SPI1_SSR_IRQHandler                 ; IRQ #32
                DCD     SPI1_ERR_IRQHandler                 ; IRQ #33
                DCD     GTIM0_UEV_ETR_BTIMA_IRQHandler      ; IRQ #34
                DCD     GTIM0_CH01_BTIMB_IRQHandler         ; IRQ #35
                DCD     GTIM0_CH23_BTIMC_IRQHandler         ; IRQ #36
                DCD     GTIM1_UEV_ETR_BTIMA_IRQHandler      ; IRQ #37
                DCD     GTIM1_CH01_BTIMB_IRQHandler         ; IRQ #38
                DCD     GTIM1_CH23_BTIMC_IRQHandler         ; IRQ #39
                DCD     GTIM2_UEV_ETR_BTIMA_IRQHandler      ; IRQ #40
                DCD     GTIM2_CH01_BTIMB_IRQHandler         ; IRQ #41
                DCD     GTIM2_CH23_BTIMC_IRQHandler         ; IRQ #42
                DCD     ATIM0_UEV_IRQHandler                ; IRQ #43
                DCD     ATIM0_CHA_IRQHandler                ; IRQ #44
                DCD     ATIM0_CHB_IRQHandler                ; IRQ #45
                DCD     ATIM0_BKETR_IRQHandler              ; IRQ #46
                DCD     ATIM3_UEV_IRQHandler                ; IRQ #47
                DCD     ATIM3_CHYA_IRQHandler               ; IRQ #48
                DCD     ATIM3_CHYB_IRQHandler               ; IRQ #49
                DCD     ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler  ; IRQ #50
                DCD     DMA_CH0_IRQHandler                  ; IRQ #51
                DCD     DMA_CH1_IRQHandler                  ; IRQ #52
                DCD     DMA_CH2_IRQHandler                  ; IRQ #53
                DCD     DMA_CH3_IRQHandler                  ; IRQ #54
                DCD     DMA_CH4_IRQHandler                  ; IRQ #55
                DCD     DMA_CH5_IRQHandler                  ; IRQ #56

                THUMB
; Dummy Exception Handlers (infinite loops which can be modified)

                PUBWEAK Reset_Handler
                SECTION .text:CODE:NOROOT:REORDER(4)
Reset_Handler
                LDR     R0, =0x00000000
                LDR     R1, [R0, #0]
                MOV     R13, R1
    
                ;reset NVIC if in rom debug
                LDR     R0, =0x20000000
                LDR     R2, =0x0              ; vector offset
                cmp     PC, R0
                bls     ROMCODE
              
              ; ram code base address. 
                ADD     R2, R0,R2
ROMCODE
              ; reset Vector table address.
                LDR     R0, =0xE000ED08
                STR     R2, [R0]
                
                LDR     R0, =SystemInit
                BLX     R0
                LDR     R0, =STL_StartupTest
                BX      R0

                PUBWEAK HardFault_Handler
                SECTION .text:CODE:NOROOT:REORDER(1)
HardFault_Handler
                B       HardFault_Handler

                PUBWEAK SVC_Handler
                SECTION .text:CODE:NOROOT:REORDER(1)
SVC_Handler
                B       SVC_Handler
               
                PUBWEAK PendSV_Handler
                SECTION .text:CODE:NOROOT:REORDER(1)
PendSV_Handler
                B       PendSV_Handler

                PUBWEAK SysTick_Handler
                SECTION .text:CODE:NOROOT:REORDER(1)
SysTick_Handler
                B       SysTick_Handler

                PUBWEAK CTRIM_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
CTRIM_IRQHandler
                B       CTRIM_IRQHandler

                PUBWEAK VC_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
VC_IRQHandler
                B       VC_IRQHandler
				
				PUBWEAK LVD_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
LVD_IRQHandler
                B       LVD_IRQHandler
								
				PUBWEAK GPIOA_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GPIOA_IRQHandler
                B       GPIOA_IRQHandler	
				
				PUBWEAK GPIOB_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GPIOB_IRQHandler
                B       GPIOB_IRQHandler
								
				PUBWEAK GPIOC_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GPIOC_IRQHandler
                B       GPIOC_IRQHandler
												
				PUBWEAK GPIOD_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GPIOD_IRQHandler
                B       GPIOD_IRQHandler
																
				PUBWEAK IWDT_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
IWDT_IRQHandler
                B       IWDT_IRQHandler
																				
				PUBWEAK WWDT_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
WWDT_IRQHandler
                B       WWDT_IRQHandler
																								
				PUBWEAK CLK_FAULT_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
CLK_FAULT_IRQHandler
                B       CLK_FAULT_IRQHandler
																												
				PUBWEAK ADC_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ADC_IRQHandler
                B       ADC_IRQHandler
																																
				PUBWEAK FLASHCFG_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
FLASHCFG_IRQHandler
                B       FLASHCFG_IRQHandler
																																				
				PUBWEAK USART0_RX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART0_RX_IRQHandler
                B       USART0_RX_IRQHandler
																																								
				PUBWEAK USART0_TX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART0_TX_IRQHandler
                B       USART0_TX_IRQHandler
																																												
				PUBWEAK USART0_FLAG_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART0_FLAG_IRQHandler
                B       USART0_FLAG_IRQHandler
																																																
				PUBWEAK USART1_RX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART1_RX_IRQHandler
                B       USART1_RX_IRQHandler
																																																				
				PUBWEAK USART1_TX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART1_TX_IRQHandler
                B       USART1_TX_IRQHandler
																																																								
				PUBWEAK USART1_FLAG_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART1_FLAG_IRQHandler
                B       USART1_FLAG_IRQHandler
																																																												
				PUBWEAK USART2_RX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART2_RX_IRQHandler
                B       USART2_RX_IRQHandler
																																																												
				PUBWEAK USART2_TX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART2_TX_IRQHandler
                B       USART2_TX_IRQHandler
																																																												
				PUBWEAK USART2_FLAG_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART2_FLAG_IRQHandler
                B       USART2_FLAG_IRQHandler
																																																												
				PUBWEAK USART3_RX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART3_RX_IRQHandler
                B       USART3_RX_IRQHandler
																																																												
				PUBWEAK USART3_TX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART3_TX_IRQHandler
                B       USART3_TX_IRQHandler
																																																												
				PUBWEAK USART3_FLAG_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
USART3_FLAG_IRQHandler
                B       USART3_FLAG_IRQHandler
																																																												
				PUBWEAK I2C0_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
I2C0_IRQHandler
                B       I2C0_IRQHandler
																																																												
				PUBWEAK I2C1_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
I2C1_IRQHandler
                B       I2C1_IRQHandler
																																																												
				PUBWEAK SPI0_TX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI0_TX_IRQHandler
                B       SPI0_TX_IRQHandler
																																																												
				PUBWEAK SPI0_RX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI0_RX_IRQHandler
                B       SPI0_RX_IRQHandler
																																																												
				PUBWEAK SPI0_SSR_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI0_SSR_IRQHandler
                B       SPI0_SSR_IRQHandler
																																																												
				PUBWEAK SPI0_ERR_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI0_ERR_IRQHandler
                B       SPI0_ERR_IRQHandler
																																																												
				PUBWEAK SPI1_TX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI1_TX_IRQHandler
                B       SPI1_TX_IRQHandler
																																																												
				PUBWEAK SPI1_RX_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI1_RX_IRQHandler
                B       SPI1_RX_IRQHandler

				PUBWEAK SPI1_SSR_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI1_SSR_IRQHandler
                B       SPI1_SSR_IRQHandler
				
				PUBWEAK SPI1_ERR_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
SPI1_ERR_IRQHandler
                B       SPI1_ERR_IRQHandler
				
				PUBWEAK GTIM0_UEV_ETR_BTIMA_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM0_UEV_ETR_BTIMA_IRQHandler
                B       GTIM0_UEV_ETR_BTIMA_IRQHandler
				
				PUBWEAK GTIM0_CH01_BTIMB_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM0_CH01_BTIMB_IRQHandler
                B       GTIM0_CH01_BTIMB_IRQHandler
				
				PUBWEAK GTIM0_CH23_BTIMC_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM0_CH23_BTIMC_IRQHandler
                B       GTIM0_CH23_BTIMC_IRQHandler
				
				PUBWEAK GTIM1_UEV_ETR_BTIMA_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM1_UEV_ETR_BTIMA_IRQHandler
                B       GTIM1_UEV_ETR_BTIMA_IRQHandler
				
				PUBWEAK GTIM1_CH01_BTIMB_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM1_CH01_BTIMB_IRQHandler
                B       GTIM1_CH01_BTIMB_IRQHandler
				
				PUBWEAK GTIM1_CH23_BTIMC_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM1_CH23_BTIMC_IRQHandler
                B       GTIM1_CH23_BTIMC_IRQHandler
				
				PUBWEAK GTIM2_UEV_ETR_BTIMA_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM2_UEV_ETR_BTIMA_IRQHandler
                B       GTIM2_UEV_ETR_BTIMA_IRQHandler
				
				PUBWEAK GTIM2_CH01_BTIMB_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM2_CH01_BTIMB_IRQHandler
                B       GTIM2_CH01_BTIMB_IRQHandler
				
				PUBWEAK GTIM2_CH23_BTIMC_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
GTIM2_CH23_BTIMC_IRQHandler
                B       GTIM2_CH23_BTIMC_IRQHandler
				
				PUBWEAK ATIM0_UEV_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM0_UEV_IRQHandler
                B       ATIM0_UEV_IRQHandler
				
				PUBWEAK ATIM0_CHA_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM0_CHA_IRQHandler
                B       ATIM0_CHA_IRQHandler
				
				PUBWEAK ATIM0_CHB_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM0_CHB_IRQHandler
                B       ATIM0_CHB_IRQHandler
				
				PUBWEAK ATIM0_BKETR_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM0_BKETR_IRQHandler
                B       ATIM0_BKETR_IRQHandler
				
				PUBWEAK ATIM3_UEV_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM3_UEV_IRQHandler
                B       ATIM3_UEV_IRQHandler
				
				PUBWEAK ATIM3_CHYA_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM3_CHYA_IRQHandler
                B       ATIM3_CHYA_IRQHandler
				
				PUBWEAK ATIM3_CHYB_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM3_CHYB_IRQHandler
                B       ATIM3_CHYB_IRQHandler
				
				PUBWEAK ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler
                B       ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler
				
				PUBWEAK DMA_CH0_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
DMA_CH0_IRQHandler
                B       DMA_CH0_IRQHandler
				
				PUBWEAK DMA_CH1_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
DMA_CH1_IRQHandler
                B       DMA_CH1_IRQHandler
				
				PUBWEAK DMA_CH2_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
DMA_CH2_IRQHandler
                B       DMA_CH2_IRQHandler
				
				PUBWEAK DMA_CH3_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
DMA_CH3_IRQHandler
                B       DMA_CH3_IRQHandler
				
				PUBWEAK DMA_CH4_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
DMA_CH4_IRQHandler
                B       DMA_CH4_IRQHandler
				
				PUBWEAK DMA_CH5_IRQHandler
                SECTION .text:CODE:NOROOT:REORDER(1)
DMA_CH5_IRQHandler
                B       DMA_CH5_IRQHandler
				
                END
