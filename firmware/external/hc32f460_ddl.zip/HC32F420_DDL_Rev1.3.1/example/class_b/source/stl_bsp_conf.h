/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/stl_bsp_conf.h
 * @brief This file contains STL BSP resource configure.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       CDT             First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

#ifndef __STL_BSP_CONF_H__
#define __STL_BSP_CONF_H__

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include <stdint.h>
#include <math.h>
#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @addtogroup IEC60730_STL_BSP_Configure
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
*******************************************************************************/

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/

/**
 * @defgroup STL_Function_Configure STL Function Configure
 * @brief This is the list of function to be used in the STL Library.
 * STK voltage define
 * @{
 */
#define STL_EV_BOARD_VCC              3.3
/**
 * @}
 */

/**
 * @defgroup STL_Function_Configure STL Function Configure
 * @brief This is the list of function to be used in the STL Library.
 * Select the functions you need to use to STL_ON.
 * @{
 */
#define STL_PRINT_ENABLE                STL_ON
#define STL_RESET_AT_FAILURE            STL_OFF
/**
 * @}
 */

/**
 * @defgroup STL_Print_Configure STL Print Configure
 * @{
 */
#if (STL_PRINT_ENABLE == STL_ON)

#define STL_PRINTF_DEVICE               (HC_USART0)
#define STL_PRINTF_DEVICE_FCG_ENALBE()  SYSCTRL_PeriphClkEnable(SysctrlPeripheralUsart0)

#define STL_PRINTF_BAUDRATE             (115200u)
#define STL_PRINTF_BAUDRATE_ERR_MAX     (0.025F)

#define STL_PRINTF_PORT                 (HC_GPIOA)
#define STL_PRINTF_PIN                  (GPIO_PIN_09)
#define STL_PRINTF_PORT_FUNC            (GPIO_PA09_AF_USART0_TXD_SET())

#endif
/**
 * @}
 */

/**
 * @defgroup STL_RAM_Configure STL RAM Configure
 * @{
 */
#define STL_RAM1_START                  (0x20000000ul)
#define STL_RAM1_END                    (0x20005FFFul)

/* Memory address must be coherent with MARCH_RAM in linker *.sct */
#define STL_MARCH_RAM_START             (0x20000100ul)
#define STL_MARCH_RAM_END               (0x20005FFFul)
/**
 * @}
 */

/**
 * @defgroup STL_ROM_Configure STL ROM Configure
 * @{
 */
#define STL_ROM_START                   (0x00000000UL)
#define STL_ROM_END                     (0x0001FFFFUL)
#define STL_ROM_SIZE                    (STL_ROM_END - STL_ROM_START + 1UL)
/**
 * @}
 */
 
/**
 * @defgroup Debug LED Configuration
 * @{
 */
#define LED_PORT                      (HC_GPIOB)
#define LED_PIN                       (12u)
/**
 * @}
 */

/**
 * @defgroup STL_Systick_Configure STL Systick Configure
 * @{
 */
#define STL_SYSTICK_TICK_FREQ           (100UL)                                     /* Frequency: 100Hz */
#define STL_SYSTICK_TICK_VALUE          (SystemCoreClock / STL_SYSTICK_TICK_FREQ)   /* Period value: 10ms */
/**
 * @}
 */
 

 
#define CLK_SOURCE_XTH     (0u)     ///< External High CR Clock Oscillator
#define CLK_SOURCE_RCH     (1u)     ///< Internal High CR Clock Oscillator
#define CLK_SOURCE_PLL     (2u)     ///< Main PLL Clock
#define CLK_SOURCE_RCL     (3u)     ///< Internal Low CR Clock Oscillator
#define CLK_SOURCE_XTL     (4u)     ///< external low CR Clock Oscillator

#define CLK_BASE_DIV1      (0u)                  ///< HCLK Division 1/1
#define CLK_BASE_DIV2      (1u)                  ///< HCLK Division 1/2
#define CLK_BASE_DIV4      (3u)                  ///< HCLK Division 1/4
#define CLK_BASE_DIV8      (5u)                  ///< HCLK Division 1/8

/*! RCL fix frequency, don't change this value */
#define CLK_RCL_VAL   (32768)

/*! XTL fix frequency, don't change this value */
#define CLK_XTL_VAL   (32768)

/*! RCH frequency */
#define CLK_RCH_VAL   (4*1000*1000)

/*! XTH frequency,please, set this value according acctual hsxt frequency */
#define CLK_XTH_VAL   (8*1000*1000)

#define SYSTEM_CLK_SEL    CLK_SOURCE_PLL
#define SYSTEM_CLK_FREQ   84*1000*1000

/**
 * @defgroup STL_Systick_Configure STL Systick Configure
 * @{
 */
#define STL_SYSTEM_TIMER_FREQ       (1000UL)                 /* Frequency: 1000Hz(1ms) */
#define STL_SYSTEM_TIMER_DIV        (8u)        /* System timer clk div*/
#define STL_SYSTEM_TIMER_VALUE      (uint16_t)(SystemCoreClock / STL_SYSTEM_TIMER_FREQ/STL_SYSTEM_TIMER_DIV)   /* Period value: 10ms,the value must < 0x10000 */
/**
 * @}
 */



#define STL_REF_TIMER_CLK_SEL       CLK_SOURCE_RCL
#define STL_REF_TIMER_CLK_FREQ      (32768UL)
#define STL_REF_TIMER_FREQ          (10UL)  /* Frequency: 10Hz(100ms) */
#define STL_REF_TIMER_DIV           (2u)
#define STL_REF_TIMER_VALUE         (uint16_t)(STL_REF_TIMER_CLK_FREQ/STL_REF_TIMER_FREQ/(STL_REF_TIMER_DIV))

   
#define CLK_TRIM_INT_TIME      2    //ms

/*******************************************************************************
 * Global variable definitions ('extern')
 ******************************************************************************/

/*******************************************************************************
 * Global function prototypes (definition in C source)
 ******************************************************************************/

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __STL_BSP_CONF_H__ */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
