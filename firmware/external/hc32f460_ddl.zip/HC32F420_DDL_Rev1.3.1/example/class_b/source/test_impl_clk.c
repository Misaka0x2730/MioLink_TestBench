/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/test_impl_item/test_impl_clk.c
 * @brief This file provides firmware functions to implement the clock test.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "stl_bsp_conf.h"
#include "test_impl_clk.h"
#include "sysctrl.h"
#include "flash.h"
#include "ctrim.h"
#include "btim.h"
#include "adc.h"

/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @defgroup Test_Implement_Clock Test Implement Clock
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define TMR_CONF_DELAY              (3UL)

#define LrcClktimer_IRQHandler  Ctrim_IRQHandler
#define SysClktimer_IRQHandler  GTim2_Ch23_BTimC_IRQHandler

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
stc_clock_test_para_t stcClockTestPara;

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/


/**
 * @defgroup Test_Implement_Clock_Global_Functions Test Implement Clock Global Functions
 * @{
 */
 
/**
 *******************************************************************************
 ** \brief Initialize clock for system
 **
 ** \param [in] None
 **
 ** \retval None
 **
 ******************************************************************************/
void System_Clock_Init(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t stcSysClk = {0};
    
/*******************System Clk Init****************************/
#if (SYSTEM_CLK_SEL == CLK_SOURCE_XTH)
  
    /* System Clk Source XTH Init*/    
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_XTH;
    
    stcSysClkSrc.u32XTHState         = SYSCTRL_XTH_DRV2 |\
                                       SYSCTRL_XTH_8t16MHz |\
                                       SYSCTRL_XTH_WAITCYCLE3;    
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}    

    /* System Clk Init*/
    stcSysClk.u32ClockType       = SYSCTRL_CLOCKTYPE_SYSCLK;
    stcSysClk.u32SysClkSource    = SYSCTRL_SYSCLK_SOURCE_XTH;
    stcSysClk.u32WaitCycle       = SYSCTRL_FLASH_WAIT_CYCLE2;
    SYSCTRL_SysClkInit(&stcSysClk); 
    
#elif (SYSTEM_CLK_SEL == CLK_SOURCE_RCH)

    /* System Clk Source RCH Init */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH;
    stcSysClkSrc.u32RCHState         = SYSCTRL_RCH_TRIM_24MHz|SYSCTRL_RCH_DIV1;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}

    /* System Clk Init */
    stcSysClk.u32ClockType       = SYSCTRL_CLOCKTYPE_SYSCLK;
    stcSysClk.u32SysClkSource    = SYSCTRL_SYSCLK_SOURCE_RCH;
    SYSCTRL_SysClkInit(&stcSysClk); 

    
#elif (SYSTEM_CLK_SEL == CLK_SOURCE_PLL)
    
    /* System Clk Source PLL Init */     

    /* 1: Enable BGR*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0);  /* Enable  Periperal Clk of ADC0  */ 
    ADC_BGR_Enable(HC_ADC0); 
	
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_XTH|\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;
                                       
    stcSysClkSrc.u32XTHState         = SYSCTRL_XTH_DRV2 |\
                                       SYSCTRL_XTH_8t16MHz |\
                                       SYSCTRL_XTH_WAITCYCLE3;
    
    stcSysClkSrc.u32PLLState         = SYSCTRL_PLL_MULM_CONFIG(21) |\
                                       SYSCTRL_PLL_DIVN_CONFIG(1) |\
                                       SYSCTRL_PLL_OEN_ON|\
                                       SYSCTRL_PLL_WAITCYCLE_CONFIG(7) |\
                                       SYSCTRL_PLL_OD_CONFIG(1) |\
                                       SYSCTRL_PLL_SRC_XTH;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}    
    
    delay1ms(10);

    /* System Clk Init */
    stcSysClk.u32ClockType       = SYSCTRL_CLOCKTYPE_SYSCLK;
    stcSysClk.u32SysClkSource    = SYSCTRL_SYSCLK_SOURCE_PLL;
    stcSysClk.u32WaitCycle       = SYSCTRL_FLASH_WAIT_CYCLE4;
    SYSCTRL_SysClkInit(&stcSysClk);
    
#endif
    
}

void STL_ClockSwitchtoXTH(void)
{

}

void STL_ClockSwitchtoRCH(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t stcSysClk = {0};
    
    /* System Clk Source RCH Init */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH;
    stcSysClkSrc.u32RCHState         = SYSCTRL_RCH_TRIM_24MHz|SYSCTRL_RCH_DIV1;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}

    /* System Clk Init */
    stcSysClk.u32ClockType       = SYSCTRL_CLOCKTYPE_SYSCLK;
    stcSysClk.u32SysClkSource    = SYSCTRL_SYSCLK_SOURCE_RCH;
    stcSysClk.u32WaitCycle       = SYSCTRL_FLASH_WAIT_CYCLE1;
    SYSCTRL_SysClkInit(&stcSysClk); 
}


/**
 *******************************************************************************
 ** \brief Initialize clock test at startup and runtime
 **
 ** \param [in] None
 **
 ** \retval STL_OK           Initialize successfully.
 ** \retval STL_ERR          If one of following conditions are met:
 **                          - clock parameters error
 **
 ******************************************************************************/
uint32_t STL_ClockTestInit(void)
{
    uint32_t u32Ret = STL_ERR;
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_ctrim_timer_init_t stcCfg = {0};
    stc_btim_init_t stcInitCfg = {0};

    
/*******************参数初始化****************************/
    STL_ClockParaInit();
    
/*******************参考时钟初始化****************************/
#if (STL_REF_TIMER_CLK_SEL == CLK_SOURCE_RCL)
    
    /* 系统时钟源初始化 */
    stcSysClkSrc.u32SysClkSourceType  = SYSCTRL_SYSCLK_SOURCE_TYPE_RCL;
    stcSysClkSrc.u32RCLState          = SYSCTRL_RCL_TRIM_32p8KHz |SYSCTRL_RCL_WAITCYCLE256;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}
        
#endif
    
    
/*******************参考定时器初始化****************************/
        
    /* 第一步：开启CTRIM 外设时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCtrim); /* CTRIM外设时钟使能 */

    /* 第二步：复位CTRIM模块 */
    SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_CTRIM);

    /* 第三步：TRIM 初始化配置 */
    stcCfg.u32Clock     = CTRIM_ACCURATE_CLOCK_RCL; /* 时钟源选择RCL = 32.768KHz */
    stcCfg.u32ClockDiv  = CTRIM_REF_CLOCK_DIV2;     /* 分频2 */
    stcCfg.u16ReloadVal = STL_REF_TIMER_VALUE;      /* 定时100ms，32768/2/10= 1638 */
    CTRIM_TimerInit(HC_CTRIM, &stcCfg);
    
    SYSCTRL_DebugEnable(SYSCTRL_DEBUG_CTRIM);
        
    /* 第四步：清除所有标志位 */
    CTRIM_ClearFlag_ALL(HC_CTRIM);

    /* 第五步：使能中断 */
    CTRIM_EnableIT(HC_CTRIM, CTRIM_IT_UD);   /* 计数器下溢中断 使能 */
    EnableNvic(CTRIM_IRQn, IrqLevel3, TRUE); /* 使能并配置TRIM 系统中断 */
    
/*******************系统定时器初始化****************************/   
    
    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim2_0_Btim678_1, TRUE); /* 配置BTIM6/7/8有效，GTIM2无效 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim2);        /* 使能BTIM6/7/8 外设时钟 */

    stcInitCfg.u32TaskMode      = BTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode      = BTIM_WORK_MODE_PCLK;               /* 工作模式:定时器模式，计数时钟源来自PCLK */
    stcInitCfg.u32Prescaler     = BTIM_COUNTER_CLK_DIV8;             /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = BTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32AutoReloadVal = (STL_SYSTEM_TIMER_VALUE - 1u);                     /* 自动重载寄存ARR赋值*/
    Btim_Init(HC_BTIM8, &stcInitCfg);
    
    SYSCTRL_DebugEnable(SYSCTRL_DEBUG_CTIM2);

    Btim_ClearFlag(HC_BTIM8, BTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Btim_EnableIT(HC_BTIM8, BTIM_IT_UI);      /* 允许BTIM8溢出中断 */
    EnableNvic(GTIM2_CH23_BTIMC_IRQn, IrqLevel3, TRUE);
    
    
    /* 使能CTRIM模块，开启定时器功能 */
    HC_CTRIM->CR1_f.EN = 1u;    
    /* 启动btim8运行 */
    HC_BTIM8->CR_f.CEN = 1u;

    
    u32Ret = STL_OK;
    
    return u32Ret;
}

uint32_t STL_ClockTestDeInit(void)
{
    HC_BTIM8->CR_f.CEN = 0UL;  /* 停止 BTIM8 */
    HC_CTRIM->CR1_f.EN = 0UL;  /* 停止 CTRIM */
    HC_SYSCTRL->APB1RST_f.CTRIM = 0UL;
    HC_SYSCTRL->APB1RST_f.CTRIM = 1UL;
    HC_SYSCTRL->APB0RST_f.CTIM2 = 0UL;
    HC_SYSCTRL->APB0RST_f.CTIM2 = 1UL;
    
    return STL_OK;
}

/**
 *******************************************************************************
 ** \brief Initialize para initial at runtime
 **
 ** \param [in] None
 **
 ** \retval None     
 **                                  
 **
 ******************************************************************************/
void STL_ClockParaInit(void)
{
    stcClockTestPara.u16ClkTestUpperLimit = (uint16_t)((STL_SYSTEM_TIMER_FREQ/STL_REF_TIMER_FREQ)*1.2);
    stcClockTestPara.u16ClkTestLowerLimit = (uint16_t)((STL_SYSTEM_TIMER_FREQ/STL_REF_TIMER_FREQ)*0.8);
    stcClockTestPara.m_u32TmrCount = 0UL;
    stcClockTestPara.u8TestFailJudge = 1UL;
    stcClockTestPara.u16TestFailCnt = 0UL;
    stcClockTestPara.u8FlagClockTestFail = 0UL;
    stcClockTestPara.u16ClkTestIrqCnt = 0UL;
    stcClockTestPara.u32NoneIntTestCnt = 0UL;
    stcClockTestPara.u32NonIntTestJudge = 0x100000UL;
}

/**
 * @brief  System Timer IRQ callback
 * @param  None
 * @retval None
 */
void SysClktimer_IRQHandler(void)
{
    if(1UL == HC_BTIM8->IFR_f.UI)
    {
        STL_SysTimerIrq();
        
        HC_BTIM8->ICR_f.UI = 0UL;
    }
}


/**
 * @brief  Ref Timer IRQ callback
 * @param  None
 * @retval None
 */
void LrcClktimer_IRQHandler(void)
{
    if(1u == HC_CTRIM->ISR_f.UD)
    {
        if (STL_ERR == STL_ClockTest())
        {
            stcClockTestPara.u8FlagClockTestFail = 1UL;
        }
        
        HC_CTRIM->ICR_f.UD = 0u;
    }
}



/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
