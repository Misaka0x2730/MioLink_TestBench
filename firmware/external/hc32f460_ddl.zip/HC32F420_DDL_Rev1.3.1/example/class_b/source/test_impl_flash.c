/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/test_impl_item/test_impl_flash.c
 * @brief This file provides firmware functions to implement the clock test.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "test_impl_flash.h"

/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @defgroup Test_Implement_Flas Test Implement Flash
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define TMR_CONF_DELAY              (3UL)

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
/**
 * @defgroup STL_IEC60730_Flash_Local_Variables STL IEC60730 Flash Local Variables
 * @{
 */
STL_USED const uint32_t __checksum STL_SECTION(".checksum") = 0UL;
/**
 * @}
 */ 
stc_flash_test_para_t stcFlashTestPara0;

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/


/**
 * @defgroup Test_Implement_Clock_Global_Functions Test Implement Clock Global Functions
 * @{
 */


/**
 *******************************************************************************
 ** \brief Initialize startup para of flash initial at runtime
 **
 ** \param [in] None
 **
 ** \retval None     
 **                                  
 **
 ******************************************************************************/
void STL_FlashStartupParaInit(void)
{
    stcFlashTestPara0.u32TestFlashCrc32Start = STL_ROM_CRC32_START;
    stcFlashTestPara0.u32TestFlashCrc32Size  = (STL_ROM_CRC32_END - STL_ROM_CRC32_START);
    stcFlashTestPara0.u32TestFlashBuildCrc32 = STL_ROM_CRC32_CC_CHECKSUM;
}

/**
 *******************************************************************************
 ** \brief Initialize runtime para of flash initial at runtime
 **
 ** \param [in] None
 **
 ** \retval None     
 **                                  
 **
 ******************************************************************************/
void STL_FlashRuntimeParaInit(void)
{
    stcFlashTestPara0.u32TestFlashCrc32Start = STL_ROM_CRC32_START;
    stcFlashTestPara0.u32TestFlashCrc32End   = STL_ROM_CRC32_END;
    stcFlashTestPara0.u32TestFlashCrc32Size  = (STL_ROM_CRC32_END - STL_ROM_CRC32_START);
    stcFlashTestPara0.u32TestFlashBlockSize = STL_ROM_CRC32_BLOCK_SIZE;
    stcFlashTestPara0.u32TestFlashBuildCrc32 = STL_ROM_CRC32_CC_CHECKSUM;
    stcFlashTestPara0.u32CheckAddr = stcFlashTestPara0.u32TestFlashCrc32Start;
    stcFlashTestPara0.u32CheckEndAddr = stcFlashTestPara0.u32TestFlashCrc32End + 3UL - stcFlashTestPara0.u32TestFlashBlockSize;
    stcFlashTestPara0.u32CalcLen = 0UL;
    stcFlashTestPara0.u32CalcCrc32Value = 0UL;
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
