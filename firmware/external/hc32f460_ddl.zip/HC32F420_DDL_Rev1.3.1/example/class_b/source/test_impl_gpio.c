/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/test_impl_item/test_impl_gpio.c
 * @brief This file provides firmware functions to manage the interrupt test.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "stl_bsp_conf.h"
#include "test_impl_gpio.h"
#include "gpio.h"

/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @defgroup Test_Implement_GPIO Test Implement GPIO
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/
typedef struct stc_stl_io_port
{
    GPIO_TypeDef *GPIOx;
    uint16_t u16PinMask;
} stc_stl_io_port_t;


/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
/*******************************************************************************
 ** Const table which defines pins that should be tested
 ** PintToTest[0] represents PORTA, PintToTest[1] -> PORTB ... etc.
 ** Each pin is represented by the corresponding bit in PintToTest table
 ** PIN 0 is represented by the LSB and PIN 15 by MSB
 ** If pin should be tested, a corresponding bit should be set to "1"
 ******************************************************************************/
static const stc_stl_io_port_t m_stcPinToTest[] =
{
    {HC_GPIOA, 0x0002},               /* PORTA mask */
    {HC_GPIOB, 0x0001},               /* PORTB mask */
    {HC_GPIOC, 0x0001},               /* PORTC mask */
    {HC_GPIOD, 0x0008},               /* PORTD mask */
};

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @defgroup Test_Implement_GPIO_Global_Functions Test Implement GPIO Global Functions
 * @{
 */

/**
 *******************************************************************************
 ** \brief Gpio output function test
 **
 ** \param [in] None
 **
 ** \retval STL_OK           Test successfully.
 ** \retval STL_ERR          If one of following conditions are met:
 **                          - output level error
 **
 ** \note This function performs gpio output test.
 **
 ******************************************************************************/
uint32_t stl_gpiooutput_test(void)
{
    uint32_t i, u32PinNum;
    uint32_t u32OrgSel, u32OrgDir, u32OrgOut;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod);

    for (i = 0; i < ARRAY_SZ(m_stcPinToTest); i++)
    {
        for (u32PinNum = 0; u32PinNum < (8 * sizeof(m_stcPinToTest[i].u16PinMask)); u32PinNum++)
        {
            if ((m_stcPinToTest[i].u16PinMask & (1 << u32PinNum)) != 0)
            {
                /* Store orginal IO register value */
                if(u32PinNum <= 7u)
                {
                    u32OrgSel = (*((__IO uint32_t*)((uint32_t)&m_stcPinToTest[i].GPIOx->AFRL)))>>(u32PinNum<<2);
                }
                else
                {
                    u32OrgSel = (*((__IO uint32_t*)((uint32_t)&m_stcPinToTest[i].GPIOx->AFRH)))>>((u32PinNum-8u)<<2);
                }
                u32OrgDir = GetBit(((uint32_t)&(m_stcPinToTest[i].GPIOx->DIR)), u32PinNum);
                u32OrgOut = GetBit(((uint32_t)&(m_stcPinToTest[i].GPIOx->OUT)), u32PinNum);

                SetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->ADS), u32PinNum, FALSE);
                /* Direction: Output */
                SetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->DIR), u32PinNum, FALSE);
                /* GPIO function */
                if(u32PinNum <= 7u)
                {
                    *((__IO uint32_t*)((uint32_t)&m_stcPinToTest[i].GPIOx->AFRL)) &= 0x0u << (u32PinNum<<2);
                }
                else
                {
                    *((__IO uint32_t*)((uint32_t)&m_stcPinToTest[i].GPIOx->AFRH)) &= 0x0u << ((u32PinNum-8u)<<2);
                }

                /* Output level: High */
                SetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->OUT), u32PinNum, 1);
                if (0x00 == GetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->IN), u32PinNum))
                {
                    return STL_ERR;
                }

                /* Output level: Low */
                SetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->OUT), u32PinNum, 0);
                if(0x01 == GetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->IN), u32PinNum))
                {
                    return STL_ERR;
                }

                /* Recover orginal IO register value */
                SetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->OUT), u32PinNum, u32OrgOut);
                SetBit(((uint32_t)&m_stcPinToTest[i].GPIOx->DIR), u32PinNum, u32OrgDir);
                if(u32PinNum <= 7u)
                {
                    *((__IO uint32_t*)((uint32_t)&m_stcPinToTest[i].GPIOx->AFRL)) |= u32OrgSel << (u32PinNum<<2);
                }
                else
                {
                    *((__IO uint32_t*)((uint32_t)&m_stcPinToTest[i].GPIOx->AFRH)) |= u32OrgSel << ((u32PinNum-8u)<<2);
                }
            }
        }
    }

    return STL_OK;
}

/**
 *******************************************************************************
 ** \brief Gpio input function test
 **
 ** \param [in] u32PortNum            The specified gpio port
 ** \param [in] u32PinNum             The specified gpio pin
 ** \param [in] u32Value              Expected the specified input pin level
 **
 ** \retval STL_OK            Test successfully.
 ** \retval STL_ERR           If one of following conditions are met:
 **                           - input level error
 **
 ******************************************************************************/
uint32_t stl_gpioinput_test(GPIO_TypeDef *GPIOx,
                                uint32_t u32PinNum,
                                uint32_t u32Value)
{
    uint32_t u32Ret = STL_OK;
    stc_gpio_init_t stcGpioCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod);
    
    stcGpioCfg.u32Pin         = u32PinNum;
    stcGpioCfg.u32Mode        = GPIO_MODE_INPUT;
    stcGpioCfg.u32DriverLevel = GPIO_Driver_Level_L;
    stcGpioCfg.u32PullUpDn    = GPIO_PULL_NONE;
    stcGpioCfg.u32ExtInt      = GPIO_EXTI_RISING;
    GPIO_Init(GPIOx, &stcGpioCfg);

    if (u32Value != GetBit(GPIOx->IN, u32PinNum))
    {
        u32Ret = STL_ERR;
    }

    return u32Ret;
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
