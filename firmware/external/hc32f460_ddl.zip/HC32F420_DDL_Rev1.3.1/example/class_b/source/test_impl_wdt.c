/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/test_impl_item/test_impl_wdt.c
 * @brief This file provides firmware functions to implement the watch test.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "test_impl_wdt.h"
#include "iwdt.h"

/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @defgroup Test_Implement_WDT Test Implement Watchdog
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define WDT_TIMEOUT                 (1000UL)

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
stc_wdt_test_para_t stcWdtTestPara;


/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/


/**
 *******************************************************************************
 ** \brief Initializes parameters for startup test.
 **
 ** \param [in] none
 **
 ** \retval none
 **
 ******************************************************************************/
uint32_t STL_WdtStartupParaInit(void)
{
    stcWdtTestPara.u32RstFlagRge = (uint32_t)&HC_SYSCTRL->RESETFLAG;
    stcWdtTestPara.u32RstFlagRgeWdtMsk = 0x00000008u;
    stcWdtTestPara.u32RstFlagRgeWdtClr = 0x00000008u;
    stcWdtTestPara.u32WdtTimeout = 6000UL;
    
    SYSCTRL_DebugEnable(SYSCTRL_DEBUG_STOP_IWDT);
    
    return STL_OK;

}

/**
 *******************************************************************************
 ** \brief Initializes WDT.
 **
 ** \param [in] none
 **
 ** \retval none
 **
 ******************************************************************************/
uint32_t STL_WdtRuntimeInit(void)
{
    stc_iwdt_init_t stcIwdtInit = {0};
    
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralIwt);

    /* IWDT 初始化 */
    /* IWDT 溢出时间 = (计数值(u32ArrCounter)/10K) * 分频系数(u32Prescaler) */
    /* 本例为：(10000/100000)*8 = 1.6s */
    stcIwdtInit.u32Action = IWDT_OVER_RESET__SLEEPMODE_STOP;
    stcIwdtInit.u32ArrCounter = 10000u;
    stcIwdtInit.u32Window     = 0xFFFu;
    stcIwdtInit.u32Prescaler  = IWDT_RC10K_DIV_16;
    IWDT_Init(&stcIwdtInit);
    
    return STL_OK;
}

/**
 *******************************************************************************
 ** \brief Initializes WDT for 1st poweron.
 **
 ** \param [in] none
 **
 ** \retval none
 **
 ******************************************************************************/
uint32_t STL_WdtStartupTestInit(void)
{
    stc_iwdt_init_t stcIwdtInit = {0};
    
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralIwt);

    /* IWDT 初始化 */
    /* IWDT 溢出时间 = (计数值(u32ArrCounter)/10K) * 分频系数(u32Prescaler) */
    /* 本例为：(150/100000)*4 = 76ms */
    stcIwdtInit.u32Action = IWDT_OVER_RESET__SLEEPMODE_STOP;
    stcIwdtInit.u32ArrCounter = 150u;
    stcIwdtInit.u32Window     = 0xFFFu;
    stcIwdtInit.u32Prescaler  = IWDT_RC10K_DIV_4;
    IWDT_Init(&stcIwdtInit);
    
    return STL_OK;
}

/**
 *******************************************************************************
 ** \brief Start WDT
 **
 ** \return none
 **
 ******************************************************************************/   
uint32_t STL_WdtTestStart(void)
{
    HC_IWDT->KR = 0xAAAAU;
    
    return STL_OK;
}

/**
 *******************************************************************************
 ** \brief Feed WDT
 **
 ** \param [in] none
 **
 ** \return none
 **
 ** \note This function feeds the Hardware Watchdog Timer with the unlock, feed,
 **       and lock sequence. Take care of the arbitrary values, because there
 **       are not checked for plausibility!
 **
 ******************************************************************************/
 uint32_t STL_WdtRuntimeFeed(void)
{
    HC_IWDT->KR = 0xAAAAU;
    
    return STL_OK;
}


/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
