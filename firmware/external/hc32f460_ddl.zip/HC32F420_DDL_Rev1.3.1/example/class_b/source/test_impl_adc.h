/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/test_impl_item/test_impl_adc.h
 * @brief This file contains all the functions prototypes of the ADC test.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       CDT             First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

#ifndef __TEST_IMPL_ADC_H__
#define __TEST_IMPL_ADC_H__

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "stl_common.h"
#include "stl_utility.h"
#include "adc.h"
#include "gpio.h"
#include "dmac.h"
#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @addtogroup Test_Implement_ADC
 * @{
 */

/*******************************************************************************
 * Global type definitions ('typedef')
*******************************************************************************/

/**
 *******************************************************************************
 ** \brief ADC test parameters
 ******************************************************************************/
typedef struct
{
   uint8_t u8ADUnit;            /* unit num */
   uint8_t u8Ch;                /* pointer to AD channel num*/
   uint8_t u8SampleCnt;         /* sample times */
   uint16_t u16ExpLowerValue;   /* expected lower value */
   uint16_t u16ExpUpperValue;   /* expected upper value */
} stc_stl_adc_test_info_t;

typedef struct
{
   uint32_t u32AdcFlagReg;      /* unit num */
   uint32_t u32AdcFlagMsk;
   uint32_t u32AdcFlagClrReg;   /* pointer to AD channel num*/
   uint32_t u32AdcFlagClrMsk;   /* sample times */
   uint32_t u32AdcResult0Reg;   /* expected lower value */
   uint32_t u32AdcResult1Reg;   /* expected upper value */
   uint32_t u32AdcResult2Reg;
   uint32_t u32AdcResult3Reg;
   uint32_t u32AdcTestUpperLimit;
   uint32_t u32AdcTestLowerLimit;
} stc_stl_adc_test_para_t;

/*******************************************************************************
 * Global pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions ('extern')
 ******************************************************************************/
extern stc_stl_adc_test_para_t stcAdcTestPara;

/*******************************************************************************
 * Global function prototypes (definition in C source)
 ******************************************************************************/
uint32_t stl_adc_test(stc_stl_adc_test_info_t *pstcAdcInfo);
uint32_t STL_AdcstartupInit(void);
uint32_t STL_AdcstartupDeInit(void);
/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif /* __TEST_IMPL_ADC_H__ */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
