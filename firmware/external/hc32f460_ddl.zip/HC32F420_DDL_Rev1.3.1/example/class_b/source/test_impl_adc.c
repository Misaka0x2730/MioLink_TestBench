/**
 *******************************************************************************
 * @file  functional_safety/iec60730_class_b/source/test_impl_item/test_impl_adc.c
 * @brief This file provides firmware functions to implement the ADC test.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-03-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "test_impl_adc.h"
#include "stl_bsp_conf.h"


/**
 * @addtogroup STL_IEC60730_Application
 * @{
 */

/**
 * @defgroup Test_Implement_ADC Test Implement ADC
 * @{
 */

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/ 


/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
stc_stl_adc_test_para_t stcAdcTestPara;

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/
typedef struct stc_stl_adc_port
{
    GPIO_TypeDef * PORTx;
    uint32_t u32Pin;
} stc_stl_adc_port_t;

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static const stc_stl_adc_port_t m_astcAdcPort[] = {
    {HC_GPIOA, GPIO_PIN_00},  /* AIN0 */
    {HC_GPIOA, GPIO_PIN_01},  /* AIN1 */
    {HC_GPIOA, GPIO_PIN_02},  /* AIN2 */
    {HC_GPIOA, GPIO_PIN_03},  /* AIN3 */
    {HC_GPIOA, GPIO_PIN_04},  /* AIN4 */
    {HC_GPIOA, GPIO_PIN_05},  /* AIN5 */
    {HC_GPIOA, GPIO_PIN_06},  /* AIN6 */
    {HC_GPIOA, GPIO_PIN_07},  /* AIN7 */
    {HC_GPIOB, GPIO_PIN_00},  /* AIN8 */
    {HC_GPIOB, GPIO_PIN_01},  /* AIN9 */
    {HC_GPIOC, GPIO_PIN_00},  /* AIN10 */
    {HC_GPIOC, GPIO_PIN_01}, /* AIN11 */
    {HC_GPIOC, GPIO_PIN_02}, /* AIN12 */
    {HC_GPIOC, GPIO_PIN_03}, /* AIN13 */
    {HC_GPIOC, GPIO_PIN_04}, /* AIN14 */
    {HC_GPIOC, GPIO_PIN_05}  /* AIN15 */
};
static uint32_t u32AdcResultbuf[4] = {0};
static uint32_t u32AdcRuntimebuf[18] = {0};
/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief Initialize adc test para init at startup-test
 **
 ** \param [in] pstcAdcInfo          structrue pointer of adc config information
 **
 ** \retval None
 **
 ******************************************************************************/
void STL_AdcTestParaInit(void)
{
    stcAdcTestPara.u32AdcFlagReg = (uint32_t)&HC_ADC0->IFR;
    stcAdcTestPara.u32AdcFlagMsk = 0x00000010UL;
    stcAdcTestPara.u32AdcFlagClrReg = (uint32_t)&HC_ADC0->ICR;
    stcAdcTestPara.u32AdcFlagClrMsk = 0x00000010UL;
    stcAdcTestPara.u32AdcResult0Reg = (uint32_t)&u32AdcResultbuf[0];
    stcAdcTestPara.u32AdcResult1Reg = (uint32_t)&u32AdcResultbuf[1];
    stcAdcTestPara.u32AdcResult2Reg = (uint32_t)&u32AdcResultbuf[2];
    stcAdcTestPara.u32AdcResult3Reg = (uint32_t)&u32AdcResultbuf[3];
    stcAdcTestPara.u32AdcTestUpperLimit = (uint32_t)((float)((float)((float)(STL_EV_BOARD_VCC/3)/2.5)*4096)*1.2);
    stcAdcTestPara.u32AdcTestLowerLimit = (uint32_t)((float)((float)((float)(STL_EV_BOARD_VCC/3)/2.5)*4096)*0.8);
}

/**
 * @brief  DMA通道配置，通过软件触发的方式，把HC_ADC0.RESULT数组的值传输到u32AdcResultbuf数组中
 * @param  [in]  channel_id DMA通道 @ref en_dma_channel_t
 * @retval None
 */
static void App_DMAConfig(en_dma_channel_t channel_id)
{
    stc_dmac_channel_init_t stcDmacChInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma);

    stcDmacChInit.u32Priority      = DMA_FIX_PRIORITY;
    stcDmacChInit.u32TrigSrc       = DMA_TRISRC_ADC0_SINGLE_EOC;
    stcDmacChInit.u32BlockCnt      = 1u;
    stcDmacChInit.u32TransferCnt   = 4u;
    stcDmacChInit.u32TransferMode  = DMA_BLOCK_MODE;
    stcDmacChInit.u32DataSize      = DMA_DATA_WORD;
    stcDmacChInit.u32SrcAddrFix    = DMA_SRCADDR_FIX;
    stcDmacChInit.u32DstAddrFix    = DMA_DSTADDR_INC;
    stcDmacChInit.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE;
    stcDmacChInit.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE;
    stcDmacChInit.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE;
    stcDmacChInit.u32SrcAddr       = (uint32_t)(&(HC_ADC0->RESULT));
    stcDmacChInit.u32DstAddr       = (uint32_t)u32AdcResultbuf;
    stcDmacChInit.u32ChanelEnMsk   = DMA_AUTO_DISABLE;
    DMACCH_Init(HC_DMAC, channel_id, &stcDmacChInit);

    DMACCH_Enable(HC_DMAC, channel_id);
    DMAC_Enable();
}

/**
 *******************************************************************************
 ** \brief Initialize adc test at startup-test
 **
 ** \param [in] pstcAdcInfo          structrue pointer of adc config information
 **
 ** \retval None
 **
 ******************************************************************************/
uint32_t STL_AdcstartupInit(void)
{
    stc_adc_cfg_t      stcAdcCfg;
	  
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); 
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc);
    
    STL_AdcTestParaInit();

    ADC_BGR_Enable(HC_ADC0);

    stcAdcCfg.AdcMode   = ADC_CONVERSION_MODE_SQR_SINGLE;         /* Scan mode */
    stcAdcCfg.AdcClkDiv = ADC_CLOCK_PCLK_DIV16;    /* ADC时钟选择 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE;  /* ADC采样周期选择 */
    stcAdcCfg.AdcRefVolSel    = ADC_REF_VOLTAGE_IN_2p5;    /* ADC参考电压选择 */
    stcAdcCfg.AdcOpBuf  = ADC_BUFF_ENABLE;         /* ADC输入信号放大器控制使能 */
    stcAdcCfg.OvMode    = ADC_OVMD_ENABLE;         /* ADC过转换时Adc_Result存储方式 */
    stcAdcCfg.AdcAlign  = ADC_RIGHT_ALIGN_ENABLE;  /* ADC转换结果对齐控制 */
    stcAdcCfg.RaccEn    = ADC_RACCCLR_DISABLE;     /* ADC转换结果自动累加功能 */
    ADC_Init(HC_ADC0, &stcAdcCfg);

    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH0MUX, ADC_Channel_Mux16_AVCC_DIV3);
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH1MUX, ADC_Channel_Mux16_AVCC_DIV3);
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH2MUX, ADC_Channel_Mux16_AVCC_DIV3);
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH3MUX, ADC_Channel_Mux16_AVCC_DIV3);
    
    ADC_Set_SQR_ChCnt(HC_ADC0, 4u);
    
    HC_ADC0->IER_f.DEOC = 1u;
    
    ADC_SetExtTrigger0Source(HC_ADC0, ADCMSKTRIGSOFT);
    
    App_DMAConfig(DMA_CHANNEL0);
    
    ADC_Sqr_SoftStart(HC_ADC0);
    
    return STL_OK;
}

uint32_t STL_AdcstartupDeInit(void)
{
    HC_SYSCTRL->APB1RST_f.ADC0 = 0UL;
    HC_SYSCTRL->APB1RST_f.ADC0 = 1UL;
    HC_SYSCTRL->AHB0RST_f.DMAC = 0UL;
    HC_SYSCTRL->AHB0RST_f.DMAC = 1UL;
    SYSCTRL_PeriphClkDisable(SysctrlPeripheralAdc0); 
    
    return STL_OK;
}

/**
 * @brief  DMA通道配置，通过软件触发的方式，把HC_ADC0.RESULT数组的值传输到u32AdcResultbuf数组中
 * @param  [in]  channel_id DMA通道 @ref en_dma_channel_t
 * @retval None
 */
static void App_DmaRuntimeConfig(en_dma_channel_t channel_id, uint32_t u32Tc)
{
    stc_dmac_channel_init_t stcDmacChInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma);

    stcDmacChInit.u32Priority      = DMA_FIX_PRIORITY;
    stcDmacChInit.u32TrigSrc       = DMA_TRISRC_ADC0_SINGLE_EOC;
    stcDmacChInit.u32BlockCnt      = 1u;
    stcDmacChInit.u32TransferCnt   = u32Tc;
    stcDmacChInit.u32TransferMode  = DMA_BLOCK_MODE;
    stcDmacChInit.u32DataSize      = DMA_DATA_WORD;
    stcDmacChInit.u32SrcAddrFix    = DMA_SRCADDR_FIX;
    stcDmacChInit.u32DstAddrFix    = DMA_DSTADDR_INC;
    stcDmacChInit.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE;
    stcDmacChInit.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE;
    stcDmacChInit.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE;
    stcDmacChInit.u32SrcAddr       = (uint32_t)(&(HC_ADC0->RESULT));
    stcDmacChInit.u32DstAddr       = (uint32_t)u32AdcRuntimebuf;
    stcDmacChInit.u32ChanelEnMsk   = DMA_AUTO_DISABLE;
    DMACCH_Init(HC_DMAC, channel_id, &stcDmacChInit);

    DMACCH_Enable(HC_DMAC, channel_id);
    DMAC_Enable();
}

/**
 *******************************************************************************
 ** \brief Initialize adc test at run-time-test
 **
 ** \param [in] pstcAdcInfo          structrue pointer of adc config information
 **
 ** \retval None
 **
 ******************************************************************************/
static void stl_adc_test_init(stc_stl_adc_test_info_t *pstcAdcInfo)
{
    uint8_t i;
    stc_adc_cfg_t stcAdcCfg;
	  
    STL_ASSERT(NULL != pstcAdcInfo);

    DDL_ZERO_STRUCT(stcAdcCfg);
    
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); 
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc);
    
    if(pstcAdcInfo->u8Ch <= 25UL)
    {
        REG_SETBITS(m_astcAdcPort[pstcAdcInfo->u8Ch].PORTx->ADS, m_astcAdcPort[pstcAdcInfo->u8Ch].u32Pin);
    }
    
    ADC_BGR_Enable(HC_ADC0);

    stcAdcCfg.AdcMode   = ADC_CONVERSION_MODE_SQR_SINGLE;         /* Scan mode */
    stcAdcCfg.AdcClkDiv = ADC_CLOCK_PCLK_DIV16;    /* ADC时钟选择 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE;  /* ADC采样周期选择 */
    stcAdcCfg.AdcRefVolSel    = ADC_REF_VOLTAGE_IN_2p5;    /* ADC参考电压选择 */
    stcAdcCfg.AdcOpBuf  = ADC_BUFF_ENABLE;         /* ADC输入信号放大器控制使能 */
    stcAdcCfg.OvMode    = ADC_OVMD_ENABLE;         /* ADC过转换时Adc_Result存储方式 */
    stcAdcCfg.AdcAlign  = ADC_RIGHT_ALIGN_ENABLE;  /* ADC转换结果对齐控制 */
    stcAdcCfg.RaccEn    = ADC_RACCCLR_DISABLE;     /* ADC转换结果自动累加功能 */
    ADC_Init(HC_ADC0, &stcAdcCfg);

    for (i = 0; i < pstcAdcInfo->u8SampleCnt; i++)
    {
        ADC_SetChannelInputSource(HC_ADC0, (ADC_SQRCH0MUX + i), pstcAdcInfo->u8Ch);
    }
     
    ADC_Set_SQR_ChCnt(HC_ADC0, pstcAdcInfo->u8SampleCnt);
    
    HC_ADC0->IER_f.DEOC = 1u;
    
    ADC_SetExtTrigger0Source(HC_ADC0, ADCMSKTRIGSOFT);
    
    App_DmaRuntimeConfig(DMA_CHANNEL0,pstcAdcInfo->u8SampleCnt);
}

/**
 *******************************************************************************
 ** \brief adc test at run-time-test
 **
 ** \param [in] pstcAdcInfo          structrue pointer of adc config information
 **
 ** \retval STL_OK           test successfully.
 ** \retval STL_ERR          If one of following conditions are met:
 **                          - adc sample value error
 **
 ******************************************************************************/
uint32_t stl_adc_test(stc_stl_adc_test_info_t *pstcAdcInfo)
{
    uint8_t i;
    uint16_t u16AdcVal = 0;
    uint16_t u16AdcValSum = 0;

    uint32_t u32Ret = STL_OK;

    STL_ASSERT(NULL != pstcAdcInfo);

    stl_adc_test_init(pstcAdcInfo);
   
    ADC_Sqr_SoftStart(HC_ADC0);
		
    while (FALSE == ADC_IsActiveFlag(HC_ADC0, ADC_FLAG_EOS));
   
    ADC_ClearFlag(HC_ADC0, ADC_FLAG_EOS);
    

    for (i = 0; i < pstcAdcInfo->u8SampleCnt; i++)
    {
        u16AdcVal = u32AdcRuntimebuf[i];
        u16AdcValSum += u16AdcVal;
    }

    u16AdcVal = u16AdcValSum / pstcAdcInfo->u8SampleCnt;

    if ((u16AdcVal < pstcAdcInfo->u16ExpLowerValue) ||
        (u16AdcVal > pstcAdcInfo->u16ExpUpperValue) )
    {
        STL_Printf("********    error sample value = 0x%04x   ********", u16AdcVal);
        u32Ret = STL_ERR;
    }

    return u32Ret;
}



/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
