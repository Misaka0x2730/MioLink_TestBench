/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of ClassB STL.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-12-24       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */


/******************************************************************************
 * Include files
 ******************************************************************************/
#include "stl_test_runtime.h"
#include "stl_bsp_conf.h"
#include "test_impl_clk.h"
#include "stl_utility.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
uint8_t u8RunTimeTestID;

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/


/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/




/**
 ** \brief  Main function of project
 **
 ** \return int32_t return value, if needed
 **
 ** \note This example show iec60730 self-test.
 **
 */

int32_t main(void)
{
    System_Clock_Init();
    
    /* Initialize Periodic&Runtime-Self-Test (PRST) module */
    STL_RuntimeTestInit();

    /* user application initiliaze */
    {
        /* user initilize code */
    }

#if (STL_PRINT_ENABLE == STL_ON)
    /*  debug in runtime initialization */
    STL_PrintfInit();
#endif

    STL_Printf("********      self test runtime start     ********");
    STL_Printf("********     self test runtime running    ********");

    while (1)
    {
        /* Non-interrupt Test Cnt */
        stcClockTestPara.u32NoneIntTestCnt++;
        
        /* Excute test: Periodic&Runtime-Self-Test (PRST) */
        STL_RuntimeTest();

        /* user application loop function */
        {
            /* user application */
        }
    }
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
