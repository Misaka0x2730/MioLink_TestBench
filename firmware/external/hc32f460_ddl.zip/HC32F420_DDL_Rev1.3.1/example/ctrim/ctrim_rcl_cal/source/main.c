/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides sample code of ctrim.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-23       MADS Team       First version
   2023-12-18       MADS            Modify parametes for XTH
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ctrim.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_ClkInit(void);
static void App_TrimCalInit(void);
static void App_GpioCfg(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  主函数
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    /* 时钟初始化 */
    App_ClkInit();

    /* 端口初始化 */
    App_GpioCfg();

    /* 等待 USER按键 按下 */
    while (0u != STK_USERKEY_READ())
        ;

    /* 关闭RCL(PB15)输出，切换到XTH的4M分频时钟(PA01)输出 */
    GPIO_PB15_AF_GPIO_SET();      /* 关闭RCL输出 */
    GPIO_PA01_MCO_OUT_XTH_DIV8(); /* MCO(PA01)输出->XTH 8分频输出 = 8M/8 = 1MHz输出 */

    /* Trim 校准功能初始化 */
    App_TrimCalInit();

    /* 使能CTRIM模块，开启校验 */
    CTRIM_Enable(HC_CTRIM);

    while (1u)
    {
        ;
    }
}

/**
 * @brief  TRIM 中断服务程序
 * @retval None.
 */
void Ctrim_IRQHandler(void)
{
    uint32_t u32TrimTVAL = 0u;

    /* 判断是否收到自动Trim结束标志位 */
    if (TRUE == CTRIM_IsActiveFlag(HC_CTRIM, CTRIM_FLAG_END))
    {
        CTRIM_ClearFlag(HC_CTRIM, CTRIM_CLEAR_FLAG_END); /* 清除标志位 */

        /* 点亮LED，校验成功 */
        STK_LED_ON();

        /* 用户根据需要将自动Trim结果HC_CTRIM->TVAL寄存器的值写入HC_SYSCTRL->RCLTRIM */
        u32TrimTVAL = HC_CTRIM->TVAL;
        REG_MODIFY(HC_SYSCTRL->RCLTRIM, (SYSCTRL_RCLTRIM_TRIM & 0x1FFU), u32TrimTVAL);
        /* 用户根据需要关闭Trim使能并复位 */
        CTRIM_Disable(HC_CTRIM);
        SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_CTRIM);
        SYSCTRL_PeriphClkEnable(SysctrlPeripheralCtrim); /* CTRIM外设时钟使能 */

        /* 关闭4M输出(PA01)，切换到校准后的RCL时钟输出(PB15) */
        GPIO_PA01_AF_GPIO_SET();      /* 关闭4M输出 */
        GPIO_PB15_MCO_OUT_RCL_DIV1(); /* 切换到校准后的RCL时钟输出 */
    }
}

/**
 * @brief  端口相关配置
 * @retval None.
 */
static void App_GpioCfg(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;     /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                  /* 端口初始化               */

    /* CTRIM_ETR(PA08)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_08;     /* 端口引脚->P08            */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                  /* 端口初始化               */
    GPIO_PA08_AF_CTRIM_ETRTOG_SET();           /* ETR输入->外部输入口      */

    /* RCL输出(PB15)端口配置 */
    DDL_ZERO_STRUCT(stcGpioInit);                  /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_15;         /* 端口引脚->P15            */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                      /* 端口初始化               */
    GPIO_PB15_MCO_OUT_RCL_DIV1();                  /* MCO输出->RCL直接输出     */

    /* XTH输出(PA01)端口配置 */
    DDL_ZERO_STRUCT(stcGpioInit);                  /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_01;         /* 端口引脚->P01            */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                      /* 端口初始化               */
}

/**
 * @brief  时钟配置
 * @retval None.
 */
static void App_ClkInit(void)
{
    /* 设置XTH晶振参数，使能XTH时钟，32MHz */
    stc_sysctrl_sysclk_source_init_t stcSysCtrlInit;

    DDL_ZERO_STRUCT(stcSysCtrlInit); /* 结构体初始化清零         */
    stcSysCtrlInit.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_XTH;
    stcSysCtrlInit.u32XTHState         = SYSCTRL_XTH_DRV2 | SYSCTRL_XTH_8t16MHz | SYSCTRL_XTH_WAITCYCLE3;
    SYSCTRL_SysClkSrcInit(&stcSysCtrlInit);

    /* 使能RCL时钟，32768Hz */
    DDL_ZERO_STRUCT(stcSysCtrlInit); /* 结构体初始化清零         */
    stcSysCtrlInit.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCL;
    stcSysCtrlInit.u32RCLState         = SYSCTRL_RCL_TRIM_32p8KHz | SYSCTRL_RCL_WAITCYCLE256;
    SYSCTRL_SysClkSrcInit(&stcSysCtrlInit);
}

/**
 * @brief  CTRIM校准初始化
 * @retval None.
 */
static void App_TrimCalInit(void)
{
    stc_ctrim_cali_init_t stcCfg = {0};

    /* 第一步：开启CTRIM 外设时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCtrim); /* CTRIM外设时钟使能 */

    /* 第二步：复位CTRIM模块 */
    SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_CTRIM);

    /* 第三步：TRIM 初始化配置 */
    stcCfg.u32Mode           = CTRIM_MODE_RCL_AUTO_TRIM;
    stcCfg.u32AccurateClock  = CTRIM_ACCURATE_CLOCK_ETR;
    stcCfg.u32RefClockDiv    = CTRIM_REF_CLOCK_DIV512; /* GCLK频率为 32768/512 = 64Hz */
    stcCfg.u32OneShot        = CTRIM_ONE_SHOT_SINGLE;
    stcCfg.u32InitialStep    = CTRIM_INITIAL_STEP_16;
    stcCfg.u16ReloadVal      = 15625u - 1u; /* 一个GCLK的计数周期目标计数值 = 1000000/64 = 15625 */
    stcCfg.u8CountErrorLimit = 16u;         /* 校准精度设置为0.1%，FLIM = 15625*0.1% = 15.625 */
    CTRIM_CaliInit(HC_CTRIM, &stcCfg);

    /* 第四步：清除所有标志位 */
    CTRIM_ClearFlag_ALL(HC_CTRIM);

    /* 第五步：使能中断 */
    CTRIM_EnableIT(HC_CTRIM, CTRIM_IT_END);  /* 打开TRIM中断使能  */
    EnableNvic(CTRIM_IRQn, IrqLevel3, TRUE); /* 使能并配置TRIM 系统中断 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
