/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides sample code of ctrim.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-23       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ctrim.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_TrimCalInit(void);
static void App_GpioCfg(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  主函数
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    uint32_t u32TrimTVAL = 0u;

    /* 端口初始化 */
    App_GpioCfg();

    /* 等待 USER按键 按下 */
    while (0u != STK_USERKEY_READ())
        ;

    /* Trim 校准功能初始化 */
    App_TrimCalInit();

    /* 使能CTRIM模块，开启校验 */
    CTRIM_Enable(HC_CTRIM);

    while (1u)
    {
        /* 判断是否收到自动Trim结束标志位 */
        if (TRUE == CTRIM_IsActiveFlag(HC_CTRIM, CTRIM_FLAG_END))
        {
            CTRIM_ClearFlag(HC_CTRIM, CTRIM_CLEAR_FLAG_END); /* 清除标志位 */

            /* 点亮LED，校验成功 */
            STK_LED_ON();

            /* 用户根据需要将自动Trim结果HC_CTRIM->TVAL寄存器的值写入HC_SYSCTRL->RCHTRIM */
            u32TrimTVAL = HC_CTRIM->TVAL;
            REG_MODIFY(HC_SYSCTRL->RCHTRIM, SYSCTRL_RCHTRIM_TRIM, u32TrimTVAL);
            /* 用户根据需要关闭Trim使能并复位 */
            CTRIM_Disable(HC_CTRIM);
            SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_CTRIM);
            SYSCTRL_PeriphClkEnable(SysctrlPeripheralCtrim); /* CTRIM外设时钟使能 */
        }
    }
}

/**
 * @brief  端口相关配置
 * @retval None.
 */
static void App_GpioCfg(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;     /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                  /* 端口初始化               */

    /* RCH(PB15)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                  /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_15;         /* 端口引脚->P15            */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                      /* 端口初始化               */
    GPIO_PB15_MCO_OUT_RCH_DIV1();                  /* MCO输出->RCH直接输出     */
    GPIO_PB15_AF_MCO_SET();                        /* 设置RCH从PB15输出        */

    /* CTRIM_ETR(PA08)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_08;     /* 端口引脚->P08            */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                  /* 端口初始化               */
    GPIO_PA08_AF_CTRIM_ETRTOG_SET();           /* ETR输入->外部输入口      */
}

/**
 * @brief  CTRIM校准初始化
 * @retval None.
 */
static void App_TrimCalInit(void)
{
    stc_ctrim_cali_init_t stcCfg = {0u};

    /* 第一步：开启CTRIM 外设时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCtrim); /* CTRIM外设时钟使能 */

    /* 第二步：复位CTRIM模块 */
    SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_CTRIM);

    /* 第三步：TRIM 初始化配置 */
    stcCfg.u32Mode           = CTRIM_MODE_RCH_AUTO_TRIM;
    stcCfg.u32AccurateClock  = CTRIM_ACCURATE_CLOCK_ETR; /* 外部输入频率为1KHz */
    stcCfg.u32RefClockDiv    = CTRIM_REF_CLOCK_DIV2;     /* GCLK频率为1K/2 = 500Hz */
    stcCfg.u32OneShot        = CTRIM_ONE_SHOT_SINGLE;
    stcCfg.u32InitialStep    = CTRIM_INITIAL_STEP_32;
    stcCfg.u32EtrFilter      = CTRIM_ETR_CLK_FLT_PCLK_DIV1CYC2;
    stcCfg.u16ReloadVal      = 48000u - 1u; /* 一个GCLK的计数周期目标计数值 = 24000000/500 = 48000 */
    stcCfg.u8CountErrorLimit = 240u;        /* 校准精度设置为0.5%，FLIM = 47999*0.5% = 240 */
    CTRIM_CaliInit(HC_CTRIM, &stcCfg);

    /* 第四步：清除所有标志位 */
    CTRIM_ClearFlag_ALL(HC_CTRIM);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
