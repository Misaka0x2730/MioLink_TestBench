/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides sample code of ctrim.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-23       MADS Team       First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ctrim.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_TrimTimerInit(void);
static void App_GpioCfg(void);
static void App_ClkInit(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  主函数
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    /* 时钟初始化 */
    App_ClkInit();

    /* 端口初始化 */
    App_GpioCfg();

    /* Trim 定时初始化 */
    App_TrimTimerInit();

    /* 使能CTRIM模块，开启定时器功能 */
    CTRIM_Enable(HC_CTRIM);

    while (1)
    {
        ;
    }
}

/**
 * @brief  TRIM 中断服务程序
 * @retval None.
 */
void Ctrim_IRQHandler(void)
{
    if (TRUE == CTRIM_IsActiveFlag(HC_CTRIM, CTRIM_FLAG_UD))
    {
        CTRIM_ClearFlag(HC_CTRIM, CTRIM_CLEAR_FLAG_UD); /* 清除标志位 */
    }
}

/**
 * @brief  端口相关配置
 * @retval None.
 */
static void App_GpioCfg(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */
    GPIO_PB12_AF_CTRIM_ETRTOG_SET();                  /* PB12复用为 ETRTOG            */
}

/**
 * @brief  时钟配置
 * @retval None.
 */
static void App_ClkInit(void)
{
    /* 设置RCL参数，使能RCL时钟，32.768KHz */
    stc_sysctrl_sysclk_source_init_t stcSysCtrlInit;

    DDL_ZERO_STRUCT(stcSysCtrlInit); /* 结构体初始化清零         */
    stcSysCtrlInit.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCL;
    stcSysCtrlInit.u32RCLState         = SYSCTRL_RCL_TRIM_32p8KHz | SYSCTRL_RCL_WAITCYCLE256;
    SYSCTRL_SysClkSrcInit(&stcSysCtrlInit);
}

/**
 * @brief  CTRIM定时初始化
 * @retval None.
 */
static void App_TrimTimerInit(void)
{
    stc_ctrim_timer_init_t stcCfg = {0};

    /* 第一步：开启CTRIM 外设时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCtrim); /* CTRIM外设时钟使能 */

    /* 第二步：复位CTRIM模块 */
    SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_CTRIM);

    /* 第三步：TRIM 初始化配置 */
    stcCfg.u32Clock     = CTRIM_ACCURATE_CLOCK_RCL; /* 时钟源选择RCL = 32.768KHz */
    stcCfg.u32ClockDiv  = CTRIM_REF_CLOCK_DIV512;   /* 分频512 */
    stcCfg.u16ReloadVal = 64U - 1U;                 /* 定时1s，32.768K/512 = 64 */
    CTRIM_TimerInit(HC_CTRIM, &stcCfg);

    /* 第四步：清除所有标志位 */
    CTRIM_ClearFlag_ALL(HC_CTRIM);

    /* 第五步：使能中断 */
    CTRIM_EnableIT(HC_CTRIM, CTRIM_IT_UD);   /* 计数器下溢中断 使能 */
    EnableNvic(CTRIM_IRQn, IrqLevel3, TRUE); /* 使能并配置TRIM 系统中断 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
