/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of ADC.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2024-05-24       MADS            Modify read/write of EOC to ESG; 
                                    Change register access to API for u32AdcRestult
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "ddl.h"
#include "dmac.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define BUFFER_SIZE 32U

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
volatile static uint32_t u32AdcRestult;
/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_AdcPortInit(void);
static void App_AdcInit(void);
static void App_AdcSglCfg(void);

/**
 * @brief  Main function of project
 * @retval None
 */

int32_t main(void)
{
    /* 配置ADC端口 */
    App_AdcPortInit();

    /* ADC 初始化*/
    App_AdcInit();

    /* ADC 采样模式配置*/
    App_AdcSglCfg();

    ADC_Enable(HC_ADC0);

    ADC_Sgl_SoftStart(HC_ADC0); /* 启动ADC顺序扫描转换 */

    while (1)
    {
        delay1ms(2000);
        ADC_Sgl_SoftStart(HC_ADC0); /* 启动ADC顺序扫描转换 */
    }
}

/**
 * @brief  ADC 采样端口初始化
 * @retval None
 */
static void App_AdcPortInit(void)
{
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* 开启GPIO外设时钟   */
    GPIO_PA00_ANALOG_SET();                          /* PA00配置为模拟输入 */
}

/**
 * @brief  ADC模块 初始化
 * @retval None
 */
static void App_AdcInit(void)
{
    stc_adc_cfg_t stcAdcCfg = {0};

    /* 第一步：开启BGR，模拟模块，必须开启BGR */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); /* 开启adc0外设时钟   */
    ADC_BGR_Enable(HC_ADC0);

    /* 第二步：ADC 初始化配置 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE;   /* ADC采样周期选择 */
    stcAdcCfg.AdcOpBuf        = ADC_BUFF_DISABLE;           /* ADC输入信号放大器控制使能 */
    stcAdcCfg.AdcRefVolSel    = ADC_REF_VOLTAGE_IN_2p5;     /* ADC参考电压选择 */
    stcAdcCfg.AdcClkDiv       = ADC_CLOCK_PCLK_DIV16;       /* ADC时钟选择 */
    stcAdcCfg.RaccEn          = ADC_RACCCLR_ENABLE;         /* ADC转换结果自动累加功能 */
    stcAdcCfg.OvMode          = ADC_OVMD_ENABLE;            /* ADC过转换时Adc_Result存储方式 */
    stcAdcCfg.AdcAlign        = ADC_RIGHT_ALIGN_ENABLE;     /* ADC转换结果对齐控制 */
    stcAdcCfg.AdcMode         = ADC_CONVERSION_MODE_SINGLE; /* ADC转换模式 */

    ADC_Init(HC_ADC0, &stcAdcCfg); /* 初始化配置 */

    /* 第三步：清除所有中断标志位 */
    ADC_ClearFlag_ALL(HC_ADC0);
}

/**
 * @brief  ADC 单次扫描模式 配置
 * @retval None
 */
static void App_AdcSglCfg(void)
{
    /* 第一步：配置通道和通道输入源：PA00 */
    ADC_SetSglMux(HC_ADC0, ADC_Channel_Mux0_PA00);

    /* 第二步：配置外部触发源，本应用使用软件触发模式，不需要配置硬件触发源 */
    ADC_SetExtTrigger0Source(HC_ADC0, 0x0000);

    /* 第三步：配置中断 */
    ADC_ClearFlag(HC_ADC0, ADC_FLAG_ESG);
    ADC_EnableIT(HC_ADC0, ADC_IT_ESG);
    EnableNvic(ADC0_ADC1_IRQn, IrqLevel3, TRUE);
}

/**
 * @brief  ADC 中断服务程序
 * @retval None
 */
void Adc_IRQHandler(void)
{
    if (TRUE == ADC_IsActiveFlag(HC_ADC0, ADC_FLAG_ESG)) /* 判断是否产生ESG标志 */
    {
        ADC_ClearFlag(HC_ADC0, ADC_FLAG_ESG);   /* 清除ESG中断标志位 */
        u32AdcRestult = ADC_GetResult(HC_ADC0); /* 获取采样值 */
    }
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
