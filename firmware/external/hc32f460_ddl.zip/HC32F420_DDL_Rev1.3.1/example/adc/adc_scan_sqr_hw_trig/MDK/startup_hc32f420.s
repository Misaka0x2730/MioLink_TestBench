;/**
; *******************************************************************************
; * @file  startup_template.s
; * @brief Startup file for Keil. 
; @verbatim
;   Change Logs:
;   Date             Author          Notes
;   2022-08-23       MADS Team       First version
; @endverbatim
; *******************************************************************************
; * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
; *
; * This software component is licensed by XHSC under BSD 3-Clause license
; * (the "License"); You may not use this file except in compliance with the
; * License. You may obtain a copy of the License at:
; *                    opensource.org/licenses/BSD-3-Clause
; *
; *******************************************************************************
; */

; Stack Configuration
; Stack Size (in Bytes) <0x0-0xFFFFFFFF:8>

Stack_Size      EQU     0x00000200			; 

                AREA    STACK, NOINIT, READWRITE, ALIGN=3
Stack_Mem       SPACE   Stack_Size
__initial_sp


; Heap Configuration
;  Heap Size (in Bytes) <0x0-0xFFFFFFFF:8>

Heap_Size       EQU     0x00000200			; 

                AREA    HEAP, NOINIT, READWRITE, ALIGN=3
__heap_base
Heap_Mem        SPACE   Heap_Size
__heap_limit


                PRESERVE8
                THUMB


; Vector Table Mapped to Address 0 at Reset

                AREA    RESET, DATA, READONLY
                EXPORT  __Vectors
                EXPORT  __Vectors_End
                EXPORT  __Vectors_Size

__Vectors                       
                DCD     __initial_sp                ; Top of Stack
                DCD     Reset_Handler               ; Reset        
                DCD     0                           ; NMI not use
                DCD     HardFault_Handler           ; Hard Fault
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     SVC_Handler                 ; SVCall
                DCD     0                           ; Reserved
                DCD     0                           ; Reserved
                DCD     PendSV_Handler              ; PendSV
                DCD     SysTick_Handler             ; SysTick



; External Interrupts
		        DCD	    CTRIM_IRQHandler
		        DCD	    VC_IRQHandler
		        DCD	    LVD_IRQHandler
		        DCD	    GPIOA_IRQHandler
		        DCD	    GPIOB_IRQHandler
		        DCD	    GPIOC_IRQHandler
		        DCD	    GPIOD_IRQHandler
		        DCD	    IWDT_IRQHandler
		        DCD	    WWDT_IRQHandler
		        DCD	    CLK_FAULT_IRQHandler
		        DCD	    ADC_IRQHandler
		        DCD	    FLASHCFG_IRQHandler
		        DCD	    USART0_RX_IRQHandler
		        DCD	    USART0_TX_IRQHandler
		        DCD	    USART0_FLAG_IRQHandler
		        DCD	    USART1_RX_IRQHandler
		        DCD	    USART1_TX_IRQHandler
		        DCD	    USART1_FLAG_IRQHandler
		        DCD	    USART2_RX_IRQHandler
		        DCD	    USART2_TX_IRQHandler
		        DCD	    USART2_FLAG_IRQHandler
		        DCD	    USART3_RX_IRQHandler
		        DCD	    USART3_TX_IRQHandler
		        DCD	    USART3_FLAG_IRQHandler
		        DCD	    I2C0_IRQHandler
		        DCD	    I2C1_IRQHandler
		        DCD	    SPI0_TX_IRQHandler
		        DCD	    SPI0_RX_IRQHandler
		        DCD	    SPI0_SSR_IRQHandler
		        DCD	    SPI0_ERR_IRQHandler
		        DCD	    SPI1_TX_IRQHandler
		        DCD	    SPI1_RX_IRQHandler
		        DCD	    SPI1_SSR_IRQHandler
		        DCD	    SPI1_ERR_IRQHandler
		        DCD	    GTIM0_UEV_ETR_BTIMA_IRQHandler
		        DCD	    GTIM0_CH01_BTIMB_IRQHandler
		        DCD	    GTIM0_CH23_BTIMC_IRQHandler
		        DCD	    GTIM1_UEV_ETR_BTIMA_IRQHandler
		        DCD	    GTIM1_CH01_BTIMB_IRQHandler
		        DCD	    GTIM1_CH23_BTIMC_IRQHandler
		        DCD	    GTIM2_UEV_ETR_BTIMA_IRQHandler
		        DCD	    GTIM2_CH01_BTIMB_IRQHandler
		        DCD	    GTIM2_CH23_BTIMC_IRQHandler
		        DCD	    ATIM0_UEV_IRQHandler
		        DCD	    ATIM0_CHA_IRQHandler
		        DCD	    ATIM0_CHB_IRQHandler
		        DCD	    ATIM0_BKETR_IRQHandler
		        DCD	    ATIM3_UEV_IRQHandler
		        DCD	    ATIM3_CHYA_IRQHandler
		        DCD	    ATIM3_CHYB_IRQHandler
		        DCD	    ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler
		        DCD	    DMA_CH0_IRQHandler
		        DCD	    DMA_CH1_IRQHandler
		        DCD	    DMA_CH2_IRQHandler
		        DCD	    DMA_CH3_IRQHandler
		        DCD	    DMA_CH4_IRQHandler
		        DCD	    DMA_CH5_IRQHandler				
				
__Vectors_End

__Vectors_Size 	EQU     __Vectors_End - __Vectors

                AREA    |.text|, CODE, READONLY


; Reset Handler
Reset_Handler   PROC
                EXPORT  Reset_Handler               [WEAK]
                IMPORT  SystemInit
                IMPORT  __main
                    
                LDR     R0, =0x00000000
				LDR     R1, [R0, #0]
				MOV     R13, R1
                
               ;reset NVIC if in rom debug
                LDR     R0, =0x20000000
                LDR     R2, =0x0
                MOVS    R1, #0 
                ADD     R1, PC,#0 
                CMP     R1, R0
                BLS     RAMCODE

              ; ram code base address. 
                ADD     R2, R0,R2
RAMCODE
              ; reset Vector table address.
                LDR     R0, =0xE000ED08 
                STR     R2, [R0]

                LDR     R0, =SystemInit
                BLX     R0
                LDR     R0, =__main
                BX      R0
                ENDP


; Dummy Exception Handlers (infinite loops which can be modified)
                  
HardFault_Handler\
                PROC
                EXPORT  HardFault_Handler                  [WEAK]
                B       .
                ENDP
SVC_Handler     \
                PROC
                EXPORT  SVC_Handler                        [WEAK]
                B       .
                ENDP
PendSV_Handler  \
                PROC
                EXPORT  PendSV_Handler                     [WEAK]
                B       .
                ENDP
SysTick_Handler \
                PROC
                EXPORT  SysTick_Handler                    [WEAK]
                B       .
                ENDP

Default_Handler PROC

		        EXPORT	CTRIM_IRQHandler		           [WEAK]
		        EXPORT	VC_IRQHandler		               [WEAK]
		        EXPORT	LVD_IRQHandler		               [WEAK]
		        EXPORT	GPIOA_IRQHandler		           [WEAK]
		        EXPORT	GPIOB_IRQHandler		           [WEAK]
		        EXPORT	GPIOC_IRQHandler		           [WEAK]
		        EXPORT	GPIOD_IRQHandler		           [WEAK]
		        EXPORT	IWDT_IRQHandler		               [WEAK]
		        EXPORT	WWDT_IRQHandler		               [WEAK]
		        EXPORT	CLK_FAULT_IRQHandler		       [WEAK]
		        EXPORT	ADC_IRQHandler		               [WEAK]
		        EXPORT	FLASHCFG_IRQHandler		           [WEAK]
		        EXPORT	USART0_RX_IRQHandler		       [WEAK]
		        EXPORT	USART0_TX_IRQHandler		       [WEAK]
		        EXPORT	USART0_FLAG_IRQHandler		       [WEAK]
		        EXPORT	USART1_RX_IRQHandler		       [WEAK]
		        EXPORT	USART1_TX_IRQHandler		       [WEAK]
		        EXPORT	USART1_FLAG_IRQHandler		       [WEAK]
		        EXPORT	USART2_RX_IRQHandler		       [WEAK]
		        EXPORT	USART2_TX_IRQHandler		       [WEAK]
		        EXPORT	USART2_FLAG_IRQHandler		       [WEAK]
		        EXPORT	USART3_RX_IRQHandler		       [WEAK]
		        EXPORT	USART3_TX_IRQHandler		       [WEAK]
		        EXPORT	USART3_FLAG_IRQHandler		       [WEAK]
		        EXPORT	I2C0_IRQHandler		               [WEAK]
		        EXPORT	I2C1_IRQHandler		               [WEAK]
		        EXPORT	SPI0_TX_IRQHandler		           [WEAK]
		        EXPORT	SPI0_RX_IRQHandler		           [WEAK]
		        EXPORT	SPI0_SSR_IRQHandler		           [WEAK]
		        EXPORT	SPI0_ERR_IRQHandler		           [WEAK]
		        EXPORT	SPI1_TX_IRQHandler		           [WEAK]
		        EXPORT	SPI1_RX_IRQHandler		           [WEAK]
		        EXPORT	SPI1_SSR_IRQHandler		           [WEAK]
		        EXPORT	SPI1_ERR_IRQHandler		           [WEAK]
		        EXPORT	GTIM0_UEV_ETR_BTIMA_IRQHandler	   [WEAK]
		        EXPORT	GTIM0_CH01_BTIMB_IRQHandler		   [WEAK]
		        EXPORT	GTIM0_CH23_BTIMC_IRQHandler		   [WEAK]
		        EXPORT	GTIM1_UEV_ETR_BTIMA_IRQHandler	   [WEAK]
		        EXPORT	GTIM1_CH01_BTIMB_IRQHandler		   [WEAK]
		        EXPORT	GTIM1_CH23_BTIMC_IRQHandler		   [WEAK]
		        EXPORT	GTIM2_UEV_ETR_BTIMA_IRQHandler	   [WEAK]
		        EXPORT	GTIM2_CH01_BTIMB_IRQHandler		   [WEAK]
		        EXPORT	GTIM2_CH23_BTIMC_IRQHandler		   [WEAK]
		        EXPORT	ATIM0_UEV_IRQHandler		       [WEAK]
		        EXPORT	ATIM0_CHA_IRQHandler		       [WEAK]
		        EXPORT	ATIM0_CHB_IRQHandler		       [WEAK]
		        EXPORT	ATIM0_BKETR_IRQHandler		       [WEAK]
		        EXPORT	ATIM3_UEV_IRQHandler		       [WEAK]
		        EXPORT	ATIM3_CHYA_IRQHandler		       [WEAK]
		        EXPORT	ATIM3_CHYB_IRQHandler		       [WEAK]
		        EXPORT	ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler [WEAK]
		        EXPORT	DMA_CH0_IRQHandler		           [WEAK]
		        EXPORT	DMA_CH1_IRQHandler		           [WEAK]
		        EXPORT	DMA_CH2_IRQHandler		           [WEAK]
		        EXPORT	DMA_CH3_IRQHandler		           [WEAK]
		        EXPORT	DMA_CH4_IRQHandler		           [WEAK]
		        EXPORT	DMA_CH5_IRQHandler		           [WEAK]
		        	
CTRIM_IRQHandler
VC_IRQHandler
LVD_IRQHandler
GPIOA_IRQHandler
GPIOB_IRQHandler
GPIOC_IRQHandler
GPIOD_IRQHandler
IWDT_IRQHandler
WWDT_IRQHandler
CLK_FAULT_IRQHandler
ADC_IRQHandler
FLASHCFG_IRQHandler
USART0_RX_IRQHandler
USART0_TX_IRQHandler
USART0_FLAG_IRQHandler
USART1_RX_IRQHandler
USART1_TX_IRQHandler
USART1_FLAG_IRQHandler
USART2_RX_IRQHandler
USART2_TX_IRQHandler
USART2_FLAG_IRQHandler
USART3_RX_IRQHandler
USART3_TX_IRQHandler
USART3_FLAG_IRQHandler
I2C0_IRQHandler
I2C1_IRQHandler
SPI0_TX_IRQHandler
SPI0_RX_IRQHandler
SPI0_SSR_IRQHandler
SPI0_ERR_IRQHandler
SPI1_TX_IRQHandler
SPI1_RX_IRQHandler
SPI1_SSR_IRQHandler
SPI1_ERR_IRQHandler
GTIM0_UEV_ETR_BTIMA_IRQHandler
GTIM0_CH01_BTIMB_IRQHandler
GTIM0_CH23_BTIMC_IRQHandler
GTIM1_UEV_ETR_BTIMA_IRQHandler
GTIM1_CH01_BTIMB_IRQHandler
GTIM1_CH23_BTIMC_IRQHandler
GTIM2_UEV_ETR_BTIMA_IRQHandler
GTIM2_CH01_BTIMB_IRQHandler
GTIM2_CH23_BTIMC_IRQHandler
ATIM0_UEV_IRQHandler
ATIM0_CHA_IRQHandler
ATIM0_CHB_IRQHandler
ATIM0_BKETR_IRQHandler
ATIM3_UEV_IRQHandler
ATIM3_CHYA_IRQHandler
ATIM3_CHYB_IRQHandler
ATIM3_BK_ETR_OV_UD_CMP3_IRQHandler
DMA_CH0_IRQHandler
DMA_CH1_IRQHandler
DMA_CH2_IRQHandler
DMA_CH3_IRQHandler
DMA_CH4_IRQHandler
DMA_CH5_IRQHandler

                
               B .

                ENDP


                ALIGN


; User Initial Stack & Heap

                IF      :DEF:__MICROLIB

                EXPORT  __initial_sp
                EXPORT  __heap_base
                EXPORT  __heap_limit

                ELSE

                IMPORT  __use_two_region_memory
                EXPORT  __user_initial_stackheap
__user_initial_stackheap

                LDR     R0, =  Heap_Mem
                LDR     R1, =(Stack_Mem + Stack_Size)
                LDR     R2, = (Heap_Mem +  Heap_Size)
                LDR     R3, = Stack_Mem
                BX      LR

                ALIGN

                ENDIF


                END
