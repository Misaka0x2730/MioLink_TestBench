/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of ADC.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2024-10-24       MADS            Modify parameter in App_AdcSqrCfg() 
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "ddl.h"
#include "dmac.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define BUFFER_SIZE 32U

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
volatile static uint32_t u32AdcRestult;
/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

static uint16_t aDstBuffer[BUFFER_SIZE];

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_DMAConfig(en_dma_channel_t channel_id);
static void App_AdcPortInit(void);
static void App_AdcInit(void);
static void App_AdcSqrCfg(void);

/**
 * @brief  Main function of project
 * @retval None
 */

int32_t main(void)
{
    en_dma_channel_t dma_channel = DMA_CHANNEL0;

    /* DMA0通道配置 */
    App_DMAConfig(dma_channel);

    /* ADC端口配置 */
    App_AdcPortInit();

    /* ADC端口配置 */
    App_AdcInit();

    /* ADC序列通道配置 */
    App_AdcSqrCfg();

    /* 开启ADC_EOC_DMA功能 */
    ADC_Enable_EOC_DMATransfer(HC_ADC0);

    /* 使能ADC*/
    ADC_Enable(HC_ADC0);

    while (1)
    {
        delay1ms(1000);
    }
}

/**
 * @brief  DMA通道配置，通过软件触发的方式，把aSRC_Const_Buffer数组的值传输到aDST_Buffer数组中
 * @param  [in]  channel_id DMA通道 @ref en_dma_channel_t
 * @retval None
 */
static void App_DMAConfig(en_dma_channel_t channel_id)
{
    stc_dmac_channel_init_t stcDmacChInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma);

    stcDmacChInit.u32Priority      = DMA_FIX_PRIORITY;
    stcDmacChInit.u32TrigSrc       = DMA_TRISRC_ADC0_SINGLE_EOC;
    stcDmacChInit.u32BlockCnt      = 1;
    stcDmacChInit.u32TransferCnt   = 3;
    stcDmacChInit.u32TransferMode  = DMA_BLOCK_MODE;
    stcDmacChInit.u32DataSize      = DMA_DATA_HALFWORD;
    stcDmacChInit.u32SrcAddrFix    = DMA_SRCADDR_FIX;
    stcDmacChInit.u32DstAddrFix    = DMA_DSTADDR_INC;
    stcDmacChInit.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE;
    stcDmacChInit.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE;
    stcDmacChInit.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE;
    stcDmacChInit.u32SrcAddr       = (uint32_t)(&(HC_ADC0->RESULT));
    stcDmacChInit.u32DstAddr       = (uint32_t)aDstBuffer;
    stcDmacChInit.u32ChanelEnMsk   = DMA_KEEP_ENABLE;

    DMACCH_Init(HC_DMAC, channel_id, &stcDmacChInit);
    DMACCH_Enable(HC_DMAC, DMA_CHANNEL0);
    DMAC_Enable();
}

/**
 * @brief  ADC 采样端口初始化
 * @retval None
 */
static void App_AdcPortInit(void)
{
    stc_gpio_init_t stcGpioCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* 开启GPIO外设时钟 */

    GPIO_PA00_ANALOG_SET(); /* PA00配置为模拟输入 */
    GPIO_PA01_ANALOG_SET(); /* PA01配置为模拟输入 */
    GPIO_PA02_ANALOG_SET(); /* PA02配置为模拟输入 */

    /* GPIO IO 初始化 */
    stcGpioCfg.u32Pin         = GPIO_PIN_15;         /* GPIO PIN脚选择 */
    stcGpioCfg.u32Mode        = GPIO_MODE_EXT_INT;   /* GPIO 模式选择 */
    stcGpioCfg.u32DriverLevel = GPIO_Driver_Level_L; /* GPIO 驱动能力 */
    stcGpioCfg.u32PullUpDn    = GPIO_PULL_UP;        /* GPIO 上下拉配置 */
    stcGpioCfg.u32ExtInt      = GPIO_EXTI_FALLING;   /* GPIO 外部中断 */

    GPIOA_Init(&stcGpioCfg);

    GPIO_ExtIrqStateClear(HC_GPIOA, GPIO_PIN_15); /* 中断标志清除 */
    EnableNvic(PORTA_IRQn, IrqLevel3, TRUE);
}

/**
 * @brief  ADC模块 初始化
 * @retval None
 */
static void App_AdcInit(void)
{
    stc_adc_cfg_t stcAdcCfg = {0};

    /* 第一步：开启BGR，模拟模块，必须开启BGR */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); /* 开启adc0外设时钟   */
    ADC_BGR_Enable(HC_ADC0);

    /* 第二步：ADC 初始化配置 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE;       /* ADC采样周期选择 */
    stcAdcCfg.AdcOpBuf        = ADC_BUFF_DISABLE;               /* ADC输入信号放大器控制使能 */
    stcAdcCfg.AdcRefVolSel    = ADC_REF_VOLTAGE_IN_2p5;         /* ADC参考电压选择 */
    stcAdcCfg.AdcClkDiv       = ADC_CLOCK_PCLK_DIV16;           /* ADC时钟选择 */
    stcAdcCfg.RaccEn          = ADC_RACCCLR_ENABLE;             /* ADC转换结果自动累加功能 */
    stcAdcCfg.OvMode          = ADC_OVMD_ENABLE;                /* ADC过转换时Adc_Result存储方式 */
    stcAdcCfg.AdcAlign        = ADC_RIGHT_ALIGN_ENABLE;         /* ADC转换结果对齐控制 */
    stcAdcCfg.AdcMode         = ADC_CONVERSION_MODE_SQR_SINGLE; /* ADC转换模式 */

    ADC_Init(HC_ADC0, &stcAdcCfg); /* 初始化配置 */

    /* 第三步：清除所有中断标志位 */
    ADC_ClearFlag_ALL(HC_ADC0);
}

/**
 * @brief  ADC 单次扫描模式 配置
 * @retval None
 */
static void App_AdcSqrCfg(void)
{
    /* 第一步：配置通道和通道输入源 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH0MUX, ADC_Channel_Mux0_PA00); /* 配置通道0的输入源来自PA00 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH1MUX, ADC_Channel_Mux1_PA01); /* 配置通道0的输入源来自PA01 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH2MUX, ADC_Channel_Mux2_PA02); /* 配置通道0的输入源来自PA02 */

    /* 第二步：配置为3次 */
    ADC_Set_SQR_ChCnt(HC_ADC0, 3);

    /* 第三步：配置外部触发源 */
    ADC_SetExtTrigger0Source(HC_ADC0, ADCMSKTRIGPA15);

    /* 第四步：配置中断 */
    ADC_ClearFlag(HC_ADC0, ADC_FLAG_EOS); /* 清除EOC中断标志位 */

    ADC_EnableIT(HC_ADC0, ADC_IT_EOS | ADC_IT_EOC);
    EnableNvic(ADC0_ADC1_IRQn, IrqLevel3, TRUE);
}

/**
 * @brief  ADC 中断服务程序
 * @retval None
 */
void Adc_IRQHandler(void)
{
    if (TRUE == ADC_IsActiveFlag(HC_ADC0, ADC_FLAG_EOS)) /* 判断是否产生EOC标志 */
    {
        ADC_ClearFlag(HC_ADC0, ADC_FLAG_EOS); /* 清除EOS中断标志位 */
    }
}

/**
 * @brief  Port A 中断处理函数
 * @retval None
 */
void GpioA_IRQHandler(void)
{
    if (GPIO_ExtIrqStateGet(HC_GPIOA, GPIO_PIN_15))
    {
        GPIO_ExtIrqStateClear(HC_GPIOA, GPIO_PIN_15);
        delay1ms(200U);
    }
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
