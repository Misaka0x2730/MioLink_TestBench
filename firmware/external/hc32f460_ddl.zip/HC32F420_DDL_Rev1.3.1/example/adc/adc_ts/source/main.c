/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of ADC of on chip temperature sensor.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2024-05-06       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "btim.h"
#include "ddl.h"
#include "flash.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define REF_VOL_SELECT REF_VOL_15V
#define REF_VOL_15V    0 /* 1.5V参考电压 */
#define REF_VOL_25V    1 /* 2.5V参考电压 */

#if (REF_VOL_SELECT == REF_VOL_15V)
#define VOL_REF   1.5        /* 1.5V参考电压 */
#define CALI_ADDR 0x0100122C /* 1.5V校准值存放地址 */
#else
#define VOL_REF   2.5        /* 2.5V参考电压 */
#define CALI_ADDR 0x01001230 /* 2.5V校准值存放地址 */
#endif
#define TS_ENV_ADDR 0x01001234
#define TEMPER_PARA 0.09354

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
static volatile float32_t f32TemperValue; /* 温度值 */
static volatile boolean_t bAdcConvFinish; /* ADC转换完成标志位 */
static volatile uint32_t  u32AdcRestult;  /* ADC转换结果 */

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_AdcInit(void);
static void App_AdcSglCfg(void);
static void App_Btimer0_Init(uint16_t u16Period);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval None
 */
int32_t main(void)
{
    /* ADC 初始化 */
    App_AdcInit();

    /* ADC 采样模式配置 */
    App_AdcSglCfg();

    /* ADC 启动 */
    ADC_Enable(HC_ADC0);

    /* BTIM0 初始化 */
    App_Btimer0_Init(15625); /* 1/4M * 256分频 * 15625 = 1s */

    /* BTIM0 启动 */
    Btim_Enable(HC_BTIM0);

    while (1)
    {
        /* 转换完成 */
        if (TRUE == bAdcConvFinish)
        {
            bAdcConvFinish = FALSE;
            f32TemperValue = (*(uint32_t*)(TS_ENV_ADDR)) / 2.0 + TEMPER_PARA * VOL_REF * ((int32_t)(u32AdcRestult - (*(uint32_t*)(CALI_ADDR)))); /* 输出温度值 */
        }
    }
}

/**
 * @brief  ADC模块 初始化
 * @retval None
 */
static void App_AdcInit(void)
{
    stc_adc_cfg_t stcAdcCfg = {0};

    /* 第一步：开启BGR，模拟模块，必须开启BGR */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); /* 开启ADC0外设时钟 */
    ADC_TS_Enable(HC_ADC0);
    ADC_BGR_Enable(HC_ADC0);

    /* 第二步：ADC 初始化配置 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE; /* ADC采样周期选择 */
    stcAdcCfg.AdcOpBuf        = ADC_BUFF_ENABLE;          /* 打开跟随器 */
#if (REF_VOL_SELECT == REF_VOL_15V)
    stcAdcCfg.AdcRefVolSel = ADC_REF_VOLTAGE_IN_1p5; /* ADC参考电压选择 */
#else
    stcAdcCfg.AdcRefVolSel = ADC_REF_VOLTAGE_IN_2p5; /* ADC参考电压选择 */
#endif
    stcAdcCfg.AdcClkDiv = ADC_CLOCK_PCLK_DIV16;       /* ADC时钟选择 */
    stcAdcCfg.RaccEn    = ADC_RACCCLR_DISABLE;        /* ADC转换结果自动累加功能 */
    stcAdcCfg.OvMode    = ADC_OVMD_ENABLE;            /* ADC过转换时ADC转换结果存储方式 */
    stcAdcCfg.AdcAlign  = ADC_RIGHT_ALIGN_ENABLE;     /* ADC转换结果对齐控制 */
    stcAdcCfg.AdcMode   = ADC_CONVERSION_MODE_SINGLE; /* ADC转换模式 */

    ADC_Init(HC_ADC0, &stcAdcCfg); /* 初始化配置 */

    /* 第三步：清除所有中断标志位 */
    ADC_ClearFlag_ALL(HC_ADC0);
}

/**
 * @brief  ADC 单次转化模式配置
 * @retval None
 */
static void App_AdcSglCfg(void)
{
    /* 第一步：配置通道和通道输入源：内置温度传感器 */
    ADC_SetSglMux(HC_ADC0, ADC_Channel_Mux17_AI_TS);

    /* 第二步：配置外部触发源，本样例使用软件配置启动，不需要配置硬件触发源 */
    ADC_SetExtTrigger0Source(HC_ADC0, ADCMSKTRIGSOFT);

    /* 第三步：配置中断 */
    ADC_ClearFlag(HC_ADC0, ADC_FLAG_ESG);
    ADC_EnableIT(HC_ADC0, ADC_FLAG_ESG);
    EnableNvic(ADC0_ADC1_IRQn, IrqLevel3, TRUE);
}

/**
 * @brief  ADC 中断服务程序
 * @retval None
 */
void Adc_IRQHandler(void)
{
    if (TRUE == ADC_IsActiveFlag(HC_ADC0, ADC_FLAG_ESG)) /* 判断是否产生单次转换完成标志 */
    {
        ADC_ClearFlag(HC_ADC0, ADC_FLAG_ESG);    /* 清除中断标志位 */
        u32AdcRestult  = ADC_GetResult(HC_ADC0); /* 获取采样值 */
        bAdcConvFinish = TRUE;                   /* 转换完成标志 */
    }
}

/**
 * @brief BTIM0中断服务函数
 * @retval None
 */
void GTim0_Uev_Etr_BTimA_IRQHandler(void)
{
    if (TRUE == Btim_IsActiveFlag(HC_BTIM0, BTIM_IT_FLAG_UI))
    {
        Btim_ClearFlag(HC_BTIM0, BTIM_IT_CLR_UI); /* 清除BTIM0的溢出中断标志位 */
        ADC_Sgl_SoftStart(HC_ADC0);               /* 启动ADC单次转换 */
    }
}

/**
 * @brief  BTIM0初始化
 * @param  [in] u16Period 周期设置值
 * @retval None
 */
static void App_Btimer0_Init(uint16_t u16Period)
{
    stc_btim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1, TRUE); /* 配置BTIM0/1/2有效，GTIM0无效 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);        /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode      = BTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode      = BTIM_WORK_MODE_PCLK;               /* 工作模式:定时器模式，计数时钟源来自PCLK */
    stcInitCfg.u32Prescaler     = BTIM_COUNTER_CLK_DIV256;           /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = BTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32AutoReloadVal = (u16Period - 1);                   /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Btim_Init(HC_BTIM0, &stcInitCfg);

    Btim_ClearFlag(HC_BTIM0, BTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Btim_EnableIT(HC_BTIM0, BTIM_IT_UI);      /* 允许BTIM0溢出中断 */
    EnableNvic(GTIM0_UEV_ETR_BTIMA_IRQn, IrqLevel3, TRUE);
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
