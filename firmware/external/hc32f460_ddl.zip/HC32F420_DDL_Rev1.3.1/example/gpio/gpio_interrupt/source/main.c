/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "flash.h"
#include "gpio.h"

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;       /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_EXT_INT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;    /* 端口上下拉配置->无上下拉 */
    stcGpioInit.u32ExtInt   = GPIO_EXTI_FALLING; /* 端口中断使能配置->下降沿 */
    GPIOB_Init(&stcGpioInit);                    /* 端口初始化               */

    /* NVIC 中断使能 */
    GPIO_ExtIrqStateClear(STK_USERKEY_PORT, STK_USERKEY_PIN); /* 中断标志清除 */
    EnableNvic(PORTB_IRQn, IrqLevel3, TRUE);

    while (1)
    {
        STK_LED_OFF();
    }
}

/**
 * @brief  Port B 中断处理函数
 */
void GpioB_IRQHandler(void)
{
    if (STK_USERKEY_PIN | GPIO_ExtIrqStateGet(STK_USERKEY_PORT, STK_USERKEY_PIN))
    {
        GPIO_ExtIrqStateClear(STK_USERKEY_PORT, STK_USERKEY_PIN);
        STK_LED_ON();
        delay1ms(200U);
    }
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
