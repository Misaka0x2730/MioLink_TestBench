/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "gpio.h"
#include "lpm.h"
#include "flash.h"

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_ClkCfg(void);
static void App_GpioInit(void);
static void App_LowPowerModeGpioSet(void);
static void App_HclkRch4M(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    /* 系统时钟初始化 */
    App_ClkCfg();
    
    /* LED/按键 端口初始化 */
    App_GpioInit();

    /* ========================================================================= */
    /* ========================= 警告，警告，警告！！！========================= */
    /* ========================================================================= */
    /* 本样例程序会进入深度休眠模式，因此以下延时2s和while等待按键代码起防护作用 */
    /* （为了防止进入深度休眠后在不同调试环境下芯片调试功能不能再次使用），      */
    /* 在使用本样例时，禁止在没有唤醒机制的情况下删除延时2s和while等待按键代码。 */
    delay1ms(2000U);
    while (STK_USERKEY_READ())
    {
        ;
    }

    /* NVIC 中断使能，用以唤醒低功耗模式 */
    GPIO_ExtIrqStateClear(STK_USERKEY_PORT, STK_USERKEY_PIN); /* 中断标志清除 */
    EnableNvic(PORTB_IRQn, IrqLevel3, TRUE);

    STK_LED_OFF();

    /* 配置Demo板上打开但没使用的IO为输入，避免端口漏电 */
    App_LowPowerModeGpioSet();

    /* 为快速响应中断，在进入深度休眠模式前将系统时钟切换为RCHCLKD */
    App_HclkRch4M();

    /* 关闭PLL */
    SYSCTRL_Func_Ctrl(Sysctrl_Fun_PLL_DIS_0_EN_1, FALSE);

    /* 进入低功耗模式——深度休眠(使能sleep-on-exit) */
    LPM_GotoDeepSleep(TRUE);

    while (1U)
    {
        /* 当使能sleep-on-exit时，以下LED闪烁代码不会被执行 */
        STK_LED_OFF();
        delay1ms(200U);
        STK_LED_ON();
        delay1ms(200U);
    }
}

/**
 * @brief  Port B 中断处理函数
 */
void GpioB_IRQHandler(void)
{
    if (GPIO_ExtIrqStateGet(STK_USERKEY_PORT, STK_USERKEY_PIN))
    {
        GPIO_ExtIrqStateClear(STK_USERKEY_PORT, STK_USERKEY_PIN);

        STK_LED_ON();
        delay1ms(2000U);
        STK_LED_OFF();
    }
}

/**
 * @brief  低功耗下端口配置
 */
static void App_LowPowerModeGpioSet(void)
{
    /* 本样例使用了GPIOB(Key和LED) */

    /* 配置为数字端口 */
    REG_WRITE(HC_GPIOB->ADS, 0x0000U);

    /* GPIOB未使用引脚设置为输入下拉（LED、Key外部电路有上拉，不设置为下拉） */
    REG_WRITE(HC_GPIOB->DIR, 0xEFFFU);     /* PB12(LED)设置为输出，其余设置为输入 */
    REG_WRITE(HC_GPIOB->PUPD, 0xEBFF0000); /* 未使用引脚设置为输入下拉（LED、Key由外部上拉，无需设置）*/
}

/**
 * @brief  系统时钟模块配置
 * @retval None
 */
static void App_ClkCfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t stcSysClk = {0};

    /* 系统时钟源初始化 */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH |
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32RCHState = SYSCTRL_RCH_TRIM_24MHz |
                               SYSCTRL_RCH_DIV6;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(42) |
                               SYSCTRL_PLL_DIVN_CONFIG(1) |
                               SYSCTRL_PLL_OEN_ON |
                               SYSCTRL_PLL_WAITCYCLE_CONFIG(7) |
                               SYSCTRL_PLL_OD_CONFIG(2) |
                               SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc))
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK |
                             SYSCTRL_CLOCKTYPE_HCLK |
                             SYSCTRL_CLOCKTYPE_PCLK0 |
                             SYSCTRL_CLOCKTYPE_PCLK1;

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* 选择PLL为系统时钟 Pclk = ((RCH_D = 24/2)*14/1)>>2 = 84MHZ */
    stcSysClk.u32HClkDiv = SYSCTRL_SYSCLK_HCLK_PRS1;       /* HCLK = Pclk = 84MHZ */
    stcSysClk.u32PClk0Div = SYSCTRL_SYSCLK_PCLK0_PRS1;     /* PCLK0 = Hclk = 84MHZ */
    stcSysClk.u32PClk1Div = SYSCTRL_SYSCLK_PCLK0_PRS1;     /* PCLK1 = Hclk = 84MHZ */
    stcSysClk.u32WaitCycle = SYSCTRL_FLASH_WAIT_CYCLE4;    /* FLash_Wait = 4 */

    SYSCTRL_SysClkInit(&stcSysClk);
}

/**
 * @brief  系统时钟模块配置为RCH 4M
 * @retval None
 */
static void App_HclkRch4M(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t stcSysClk = {0};

    /* 系统时钟源初始化 */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH;

    stcSysClkSrc.u32RCHState = SYSCTRL_RCH_TRIM_24MHz |
                               SYSCTRL_RCH_DIV6;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc))
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK |
                             SYSCTRL_CLOCKTYPE_HCLK |
                             SYSCTRL_CLOCKTYPE_PCLK0 |
                             SYSCTRL_CLOCKTYPE_PCLK1;

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_RCH; /* 选择系统时钟 RCH 4M */
    stcSysClk.u32HClkDiv = SYSCTRL_SYSCLK_HCLK_PRS1;       /* HCLK = 4MHZ */
    stcSysClk.u32PClk0Div = SYSCTRL_SYSCLK_PCLK0_PRS1;     /* PCLK0 = Hclk = 4MHZ */
    stcSysClk.u32PClk1Div = SYSCTRL_SYSCLK_PCLK0_PRS1;     /* PCLK1 = Hclk = 4MHZ */
    stcSysClk.u32WaitCycle = SYSCTRL_FLASH_WAIT_CYCLE1;    /* FLash_Wait = 1 */

    SYSCTRL_SysClkInit(&stcSysClk);
}

/**
 * @brief  GPIO 初始化
 */
static void App_GpioInit(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
  
    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_SET();                                  /* 端口初始电平->高, 打开LED    */
    stcGpioInit.u32Pin = GPIO_PIN_12;                 /* 端口引脚->P12                */
    stcGpioInit.u32Mode = GPIO_MODE_OUTPUT_PP;        /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;         /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin = GPIO_PIN_10;          /* 端口引脚->P10            */
    stcGpioInit.u32Mode = GPIO_MODE_EXT_INT;   /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    stcGpioInit.u32ExtInt = GPIO_EXTI_FALLING; /* 端口中断使能配置->下降沿 */
    GPIOB_Init(&stcGpioInit);                  /* 端口初始化               */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
