/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static volatile uint32_t u32PwcCapValue;
static volatile uint16_t u16ATIM0_CntValue;
static uint16_t          u16ATIM0_OverFlowCnt;
static uint16_t          u16ATIM0_CapValue;

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Atimer0_Port_Cfg(void);
static void App_Atimer0_Cfg(void);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Clock_Cfg(); /* 时钟初始化 */

    App_Atimer0_Port_Cfg(); /* ATIM0 Port端口配置 */

    App_Atimer0_Cfg(); /* ATIM0 配置 */

    ATIM0_Mode1_Run(); /* ATIM0 运行 */

    while (1)
        ;
}

/**
 * @brief  ATIM0_UEV 中断函数
 * @retval None
 */
void ATim0_Uev_IRQHandler(void)
{
    /* Atimer0 模式1 计数溢出中断 */
    u16ATIM0_OverFlowCnt++; /* 计数脉宽测量开始边沿到结束边沿过程中timer的溢出次数 */

    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI); /* 清除中断标志 */
}

/**
 * @brief  ATIM0_CHA 中断函数
 * @retval None
 */
void ATim0_ChA_IRQHandler(void)
{
    /* Atimer0 模式1 PWC脉宽测量中断 */
    u16ATIM0_CntValue = ATIM0_Mode1_Cnt16Get();        /* 读取当前计数值 */
    u16ATIM0_CapValue = ATIM0_Mode1_PWC_CapValueGet(); /* 读取脉宽测量值 */

    u32PwcCapValue = u16ATIM0_OverFlowCnt * 0x10000 + u16ATIM0_CapValue;

    u16ATIM0_OverFlowCnt = 0;

    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_PWC_CA0); /* 清除中断标志 */
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON 
                               | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0 
                             | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  ATIM0 CHx 端口配置
 * @retval None
 */
void App_Atimer0_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    /* 外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */

    /* PA10(ATIM0_CH0A) 端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                  /* 结构体初始化清零         */
    GPIO_PA10_RESET();                             /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;         /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                      /* 端口初始化               */
    GPIO_PA10_AF_ATIM0_CH0A_SET();                 /* PA10复用为ATIM0_CH0A     */
}

/**
 * @brief  ATIM0 配置
 * @retval None
 */
void App_Atimer0_Cfg(void)
{
    uint16_t                  u16CntValue;
    stc_atim0_mode1_cfg_t     stcAtim0BaseCfg  = {0};
    stc_atim0_pwc_input_cfg_t stcAtim0PwcInCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* ATIM0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                             /* 结构体初始化清零 */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M1_M1CR_WORK_MODE_PWC; /* 定时器模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M1_M1CR_CT_PCLK;       /* 定时器功能，计数时钟为内部PCLK */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M1_M1CR_ATIM0CLK_PRS4; /* PCLK/4 */
    stcAtim0BaseCfg.u32ShotMode    = ATIM0_M1_M1CR_SHOT_CYCLE;    /* PWC循环检测 */
    ATIM0_Mode1_Init(&stcAtim0BaseCfg);                           /* TIM0 的模式1功能初始化 */

    DDL_ZERO_STRUCT(stcAtim0PwcInCfg);                                 /* 结构体初始化清零 */
    stcAtim0PwcInCfg.u32TsSel  = ATIM0_M1_MSCR_TS_CH0A_FILTER;         /* PWC输入选择 CHA */
    stcAtim0PwcInCfg.u32IA0Sel = ATIM0_M1_MSCR_IA0S_CH0A;              /* CHA选择IA0 */
    stcAtim0PwcInCfg.u32FltIA0 = ATIM0_M1_FLTR_FLTA0_B0_ET_3_PCLKDIV4; /* PCLK/4 3个连续有效 */
    ATIM0_Mode1_Input_Cfg(&stcAtim0PwcInCfg);                          /* PWC输入设置 */

    ATIM0_Mode1_PWC_Edge_Sel(ATIM0_M1_M1CR_DETECT_EDGE_FALL_TO_FALL); /* 下降沿到下降沿脉宽测量 */

    u16CntValue = 0;
    ATIM0_Mode1_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI | ATIM0_INT_CLR_PWC_CA0); /* 清Uev中断、捕捉中断标志 */
    ATIM0_Mode1_EnableIrq(ATIM0_M1_INT_UI | ATIM0_M1_INT_CA0);    /* 使能TIM0溢出中断 */
    EnableNvic(ATIM0_UEV_IRQn, IrqLevel3, TRUE);                  /* TIM0_UEV中断使能 */
    EnableNvic(ATIM0_CHA_IRQn, IrqLevel3, TRUE);                  /* TIM0_CHA中断使能 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
