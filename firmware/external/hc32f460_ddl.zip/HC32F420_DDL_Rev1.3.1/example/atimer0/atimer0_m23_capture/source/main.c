/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static uint32_t          Atim0_Capture_Value1, Atim0_Capure_Value2;
static volatile int32_t  Atim0_Capture_Value;
static volatile uint16_t Atim0_Uev_Cnt;

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Atimer0_Port_Cfg(void);
static void App_Timer0_Cfg(void);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Clock_Cfg(); /* 时钟初始化 */

    App_Atimer0_Port_Cfg(); /* Atimer0 Port端口配置 */

    App_Timer0_Cfg(); /* Atimer0 配置 */

    ATIM0_Mode23_Run(); /* 运行 */

    while (1) {}
}

/**
 * @brief  ATIM0_CHA 中断函数
 * @retval None
 */
void ATim0_ChA_IRQHandler(void)
{
    static uint8_t i;

    /* Timer0 捕获中断A */
    if (TRUE == ATIM0_GetIntFlag(ATIM0_INT_FLAG_PWC_CA0))
    {
        if (0 == i)
        {
            Atim0_Capture_Value1 = ATIM0_Mode23_Channel_Capture_Value_Get(ATIM0_COMPARE_CAPTURE_CH0A); /* 第一次读取捕获值 */
            Atim0_Uev_Cnt        = 0;
            i++;
        }
        else
        {
            Atim0_Capure_Value2 = ATIM0_Mode23_Channel_Capture_Value_Get(ATIM0_COMPARE_CAPTURE_CH0A);  /* 第二次读取捕获值 */
            Atim0_Capture_Value = Atim0_Uev_Cnt * 0xFFFF + Atim0_Capure_Value2 - Atim0_Capture_Value1; /* 两次捕获之间的差值 */

            Atim0_Uev_Cnt = 0;

            i = 0;
        }

        ATIM0_ClearIrqFlag(ATIM0_INT_CLR_PWC_CA0); /* 清中断标志 */
    }
}

/**
 * @brief  ATIM0_UEV 中断函数
 * @retval None
 */
void ATim0_Uev_IRQHandler(void)
{
    /* timer0计数溢出中断 */
    Atim0_Uev_Cnt++;
    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI);
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON 
                               | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0 
                             | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  ATIM0 CHx 端口配置
 * @retval None
 */
void App_Atimer0_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    /* 外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */

    /* PA10(ATIM0_CH0A) 端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                  /* 结构体初始化清零         */
    GPIO_PA10_RESET();                             /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;         /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                      /* 端口初始化               */
    GPIO_PA10_AF_ATIM0_CH0A_SET();                 /* PA10复用为ATIM0_CH0A     */
}

/**
 * @brief  ATIM0 配置
 * @retval None
 */
void App_Timer0_Cfg(void)
{
    uint16_t                  u16ArrValue;
    uint16_t                  u16CntValue;
    stc_atim0_mode23_cfg_t    stcAtim0BaseCfg    = {0};
    stc_atim0_m23_input_cfg_t stcAtim0ChxACapCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* ATIM0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                                  /* 结构体初始化清零 */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M1_M1CR_WORK_MODE_SAWTOOTH; /* 齿波模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M23_M23CR_CT_PCLK;          /* 定时器功能，计数时钟为内部PCLK */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M23_M23CR_ATIM0CLK_PRS64;   /* PCLK/64 */
    stcAtim0BaseCfg.u32CntDir      = ATIM0_M23_M23CR_DIR_UP_CNT;       /* 向上计数，在三角波模式时只读 */
    ATIM0_Mode23_Init(&stcAtim0BaseCfg);                               /* ATIM0 的模式23功能初始化 */

    DDL_ZERO_STRUCT(stcAtim0ChxACapCfg);                                               /* 结构体初始化清零 */
    stcAtim0ChxACapCfg.u32CHxCmpCap   = ATIM0_M23_CRCHx_CSA_CSB_CAPTURE;               /* CH0A通道设置为捕获模式 */
    stcAtim0ChxACapCfg.u32CHxCapSel   = ATIM0_M23_CRCHx_CRxCFx_CAPTURE_EDGE_RISE_FALL; /* CH0A通道上升沿下降沿捕获都使能 */
    stcAtim0ChxACapCfg.u32CHxInFlt    = ATIM0_M23_FLTR_FLTxx_THREE_PCLK_4;             /* PCLK/4 3个连续有效 */
    stcAtim0ChxACapCfg.u32CHxPolarity = ATIM0_M23_FLTR_CCPxx_NORMAL_IN_OUT;            /* 正常输入输出 */
    ATIM0_Mode23_PortInput_CHA_Cfg(&stcAtim0ChxACapCfg);                               /* 端口输入初始化配置 */

    u16ArrValue = 0xFFFF;
    ATIM0_Mode23_ARRSet(u16ArrValue); /* 设置重载值,并使能缓存 */
    ATIM0_Mode23_ARR_Buffer_Enable(TRUE);

    u16CntValue = 0;
    ATIM0_Mode1_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM0_ClearAllIrqFlag();                                      /* 清中断标志 */
    ATIM0_Mode23_EnableIrq(ATIM0_M23_INT_CA0 | ATIM0_M23_INT_UI); /* 使能ATIM0 CB0比较/捕获中断 */
    EnableNvic(ATIM0_UEV_IRQn, IrqLevel3, TRUE);                  /* TIM0_UEV中断使能 */
    EnableNvic(ATIM0_CHA_IRQn, IrqLevel3, TRUE);                  /* TIM0_CHA中断使能 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
