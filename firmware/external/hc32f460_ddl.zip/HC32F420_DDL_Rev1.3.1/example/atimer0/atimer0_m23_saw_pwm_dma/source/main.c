/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "dmac.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Atimer0_Port_Cfg(void);
static void App_Atimer0_Cfg(uint16_t u16Period, uint16_t u16CHxACompare, uint16_t u16CHxBCompare);
static void App_Dma_Cfg();

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
volatile static uint32_t u32Tim0PWMDuty[2] = {0x6000, 0x3000};

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Clock_Cfg(); /* 时钟初始化 */

    App_Atimer0_Port_Cfg(); /* Atimer3 Port端口配置 */

    App_Atimer0_Cfg(0x9000, 0x6000, 0x3000); /* Atimer3 配置:周期 0x9000;                          */
                                             /* CH0/1/2通道A比较值0x6000; CH0/1/2通道B比较值0x3000 */
    App_Dma_Cfg();                           /* DMA传输初始化 */

    ATIM0_Mode23_Run(); /* 运行 */

    /* 可添加其他其他操作，待准备好后使能PWM输出 */

    ATIM0_Mode23_Manual_PWM_Output_Enable(TRUE); /* 端口输出使能 */

    while (1)
    {
        ;
    }
}

/**
 * @brief  ATIM0_UEV 中断函数
 * @retval None
 */
void ATim0_Uev_IRQHandler(void)
{
    static uint8_t i = 0;

    /* Atimer0 模式23 更新中断 */
    if (0 == i)
    {
        STK_LED_ON(); /* LED 引脚输出高电平 */

        u32Tim0PWMDuty[0] = 0x3000;
        u32Tim0PWMDuty[1] = 0x6000;

        i++;
    }
    else if (1 == i)
    {
        STK_LED_OFF(); /* LED 引脚输出低电平 */

        u32Tim0PWMDuty[0] = 0x6000;
        u32Tim0PWMDuty[1] = 0x3000;

        i = 0;
    }
    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI); /* 清中断标志 */
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON 
                               | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0 
                             | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  ATIM0 CHx 端口配置
 * @retval None
 */
static void App_Atimer0_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* PA10(ATIM0_CH0A) PA11(ATIM0_CH0B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零         */
    GPIO_PA10_RESET();                                   /* 端口初始电平->低         */
    GPIO_PA11_RESET();                                   /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_10 | GPIO_PIN_11; /* 端口引脚->P10，P11       */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;       /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                            /* 端口初始化               */
    GPIO_PA10_AF_ATIM0_CH0A_SET();                       /* PA10复用为ATIM0_CH0A     */
    GPIO_PA11_AF_ATIM0_CH0B_SET();                       /* PA11复用为ATIM0_CH0B     */
}

/**
 * @brief  ATIM0 配置
 * @param  [in] u16Period:        周期
 * @param  [in] u16CHxACompare:   CHA比较值
 * @param  [in] u16CHxBCompare:   CHB比较值
 * @retval None
 */
void App_Atimer0_Cfg(uint16_t u16Period, uint16_t u16CHxACompare, uint16_t u16CHxBCompare)
{
    uint16_t                    u16CntValue;
    stc_atim0_mode23_cfg_t      stcAtim0BaseCfg    = {0};
    stc_atim0_m23_compare_cfg_t stcAtim0ChxACmpCfg = {0};
    stc_atim0_m23_compare_cfg_t stcAtim0ChxBCmpCfg = {0};
    stc_atim0_m23_rcr_cfg_t     stcRcrCfg          = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* Atimer0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                                            /* 结构体初始化清零 */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M23_M23CR_WORK_MODE_SAWTOOTH;         /* 锯齿波模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M23_M23CR_CT_PCLK;                    /* 定时器功能，计数时钟为内部PCLK */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M23_M23CR_ATIM0CLK_PRS1;              /*  PCLK */
    stcAtim0BaseCfg.u32CntDir      = ATIM0_M23_M23CR_DIR_UP_CNT;                 /* 向上计数，在三角波模式时只读 */
    stcAtim0BaseCfg.u32PWMTypeSel  = ATIM0_M23_M23CR_COMP_PWM_INDEPT;            /* 独立输出PWM */
    stcAtim0BaseCfg.u32PWM2sSel    = ATIM0_M23_M23CR_PWM2S_COMPARE_SINGLE_POINT; /* 单点比较功能 */
    stcAtim0BaseCfg.u32ShotMode    = ATIM0_M23_M23CR_SHOT_CYCLE;                 /* 循环计数 */
    stcAtim0BaseCfg.u32URSSel      = ATIM0_M23_M23CR_URS_OV_UND_UG_RST;          /* 上溢出/下溢出/软件更新UG/从模式复位 */

    ATIM0_Mode23_Init(&stcAtim0BaseCfg); /* ATIM0 的模式23功能初始化 */

    ATIM0_Mode23_ARRSet(u16Period);
    ATIM0_Mode23_ARR_Buffer_Enable(TRUE); /* 设置重载值,并使能缓存 */

    ATIM0_Mode23_Channel_Compare_Value_Set(ATIM0_COMPARE_CAPTURE_CH0A, u16CHxACompare); /* 设置CHA比较值 */
    ATIM0_Mode23_Channel_Compare_Value_Set(ATIM0_COMPARE_CAPTURE_CH0B, u16CHxBCompare); /* 设置CHB比较值 */

    DDL_ZERO_STRUCT(stcAtim0ChxACmpCfg); /* 结构体初始化清零 */
    stcAtim0ChxACmpCfg.u32CHxCmpCap      = ATIM0_M23_CRCHx_CSA_CSB_COMPARE;
    stcAtim0ChxACmpCfg.u32CHxCmpModeCtrl = ATIM0_M23_FLTR_OCMxx_PWM_MODE_2;    /* OCREFA输出控制OCMA:PWM模式2 */
    stcAtim0ChxACmpCfg.u32CHxPolarity    = ATIM0_M23_FLTR_CCPxx_NORMAL_IN_OUT; /* 正常输出 */
    stcAtim0ChxACmpCfg.u32CHxCmpBufEn    = ATIM0_M23_CRCHx_BUFEx_ENABLE;       /* A通道缓存控制 */
    stcAtim0ChxACmpCfg.u32CHxCmpIntSel   = ATIM0_M23_M23CR_CISA_DISABLE_IRQ;   /* A通道比较中断控制:无 */
    ATIM0_Mode23_PortOutput_CHA_Cfg(&stcAtim0ChxACmpCfg);                      /* CHA比较输出端口配置 */

    DDL_ZERO_STRUCT(stcAtim0ChxBCmpCfg); /* 结构体初始化清零 */
    stcAtim0ChxBCmpCfg.u32CHxCmpCap      = ATIM0_M23_CRCHx_CSA_CSB_COMPARE;
    stcAtim0ChxBCmpCfg.u32CHxCmpModeCtrl = ATIM0_M23_FLTR_OCMxx_PWM_MODE_2;    /* OCREFB输出控制OCMB:PWM模式2(PWM互补模式下也要设置，避免强制输出) */
    stcAtim0ChxBCmpCfg.u32CHxPolarity    = ATIM0_M23_FLTR_CCPxx_NORMAL_IN_OUT; /* 正常输出 */
    stcAtim0ChxBCmpCfg.u32CHxCmpBufEn    = ATIM0_M23_CRCHx_BUFEx_ENABLE;       /* B通道缓存控制使能 */
    stcAtim0ChxBCmpCfg.u32CHxCmpIntSel   = ATIM0_M23_CRCHx_CISBx_DISABLE_IRQ;  /* B通道比较中断控制:无 */
    ATIM0_Mode23_PortOutput_CHB_Cfg(&stcAtim0ChxBCmpCfg);                      /* CHB比较输出端口配置 */

    ATIM0_Mode23_EnDisable_UEV_TrigDMA(TRUE); /* UEV更新触发DMA使能 */

    /* 事件更新周期设置，UD Mask 使能之后，0代表锯齿波每个上溢产生中断,每+1代表延迟一个周期 */
    /* 注意!!!!锯齿波模式，当设置计数方向向上，如果设置OV Mask使能，将不能产生Uev中断*/
    DDL_ZERO_STRUCT(stcRcrCfg);                                          /* 结构体初始化清零 */
    stcRcrCfg.u32EnOverFLowMask  = ATIM0_M23_RCR_OVF_IRQ_EVT_CNT_ENABLE; /* 屏蔽上溢重复计数 */
    stcRcrCfg.u32EnUnderFlowMask = ATIM0_M23_RCR_UND_IRQ_EVT_CNT_MASK;   /* 使能下溢重复计数 */
    stcRcrCfg.u32RepeatCountNum  = 0;
    ATIM0_Mode23_SetRepeatPeriod(&stcRcrCfg); /* 间隔周期设置 */

    u16CntValue = 0;
    ATIM0_Mode23_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM0_ClearAllIrqFlag();                     /* 清中断标志 */
    ATIM0_Mode23_EnableIrq(ATIM0_M23_INT_UI);    /* 使能ATIM0 上溢中断 */
    EnableNvic(ATIM0_UEV_IRQn, IrqLevel3, TRUE); /* ATIM0中断使能 */
}

/**
 * @brief  DMA通道配置, Timer0 uev 触发 DMA传输
 * @retval None.
 */
static void App_Dma_Cfg()
{
    stc_dmac_channel_init_t stcDmaCfg;

    /* 结构体变量 初始值清零 */
    DDL_ZERO_STRUCT(stcDmaCfg);

    /*  使能 DMA时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma);

    stcDmaCfg.u32Priority      = DMA_FIX_PRIORITY;                 /* 固定优先级 */
    stcDmaCfg.u32TrigSrc       = DMA_TRISRC_ATIM0_CHB;             /* 设置为Atimer0 UEV 触发 */
    stcDmaCfg.u32BlockCnt      = 0x02u;                            /* 块传输个数 */
    stcDmaCfg.u32TransferCnt   = 0x01u;                            /* Block模式，一次传输数据大小为 2,传输1次 */
    stcDmaCfg.u32TransferMode  = DMA_BLOCK_MODE;                   /* 选择块传输 */
    stcDmaCfg.u32DataSize      = DMA_DATA_WORD;                    /* 传输数据的宽度，此处选择字(32Bit)宽度 */
    stcDmaCfg.u32SrcAddrFix    = DMA_SRCADDR_INC;                  /* 源地址自增 */
    stcDmaCfg.u32DstAddrFix    = DMA_DSTADDR_INC;                  /* 目的地址自增 */
    stcDmaCfg.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE;          /* 使能重新加载BC/TC值 */
    stcDmaCfg.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE;        /* 使能重新加载传输源地址 */
    stcDmaCfg.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE;        /* 使能重新加载传输目的地址 */
    stcDmaCfg.u32SrcAddr       = (uint32_t) & (u32Tim0PWMDuty[0]); /* 指定传输源地址 */
    stcDmaCfg.u32DstAddr       = (uint32_t)&HC_ATIM0MODE23->CCR0A; /* 指定传输目的地址 */
    stcDmaCfg.u32ChanelEnMsk   = DMA_KEEP_ENABLE;                  /* 传输完成通道保持使能 */

    DMACCH_Init(HC_DMAC, DMA_CHANNEL0, &stcDmaCfg); /* DMA初始化 */

    DMAC_Enable();                        /* 使能DMAC */
    DMACCH_Enable(HC_DMAC, DMA_CHANNEL0); /* 使能DMA通道0 */
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
