/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Atimer0_Port_Cfg(void);
static void App_Atimer0_Cfg(uint16_t u16Period);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Atimer0_Port_Cfg(); /* ATIM0 端口配置 */

    App_Atimer0_Cfg(25000); /* ATIM0 配置; 16分频,周期25000-->25000*(1/4M) * 16 = 100000us = 100ms */

    ATIM0_Mode0_Run(); /* ATIM0 运行 */

    /* 用户可添加其他代码 */

    ATIM0_Mode0_Enable_TOG(TRUE); /* TOG翻转输出使能 */

    while (1)
        ;
}

/**
 * @brief  ATIM0 CHx 端口配置
 * @retval None
 */
static void App_Atimer0_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    /* 外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */

    /* PA10(ATIM0_CH0A) PA11(ATIM0_CH0B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零         */
    GPIO_PA10_RESET();                                   /* 端口初始电平->低         */
    GPIO_PA11_RESET();                                   /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_10 | GPIO_PIN_11; /* 端口引脚->P10，P11       */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;       /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                            /* 端口初始化               */
    GPIO_PA10_AF_ATIM0_CH0A_SET();                       /* PA10复用为ATIM0_CH0A     */
    GPIO_PA11_AF_ATIM0_CH0B_SET();                       /* PA11复用为ATIM0_CH0B     */
}

/**
 * @brief  ATIM0 配置
 * @retval None
 */
void App_Atimer0_Cfg(uint16_t u16Period)
{
    uint16_t              u16ArrValue;
    uint16_t              u16CntValue;
    stc_atim0_mode0_cfg_t stcAtim0BaseCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* ATIM0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                               /* 结构体初始化清零             */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M0_M0CR_WORK_MODE_TIMER; /* 定时器模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M0_M0CR_CT_PCLK;         /* 定时器功能，计数时钟为内部PCLK */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M0_M0CR_ATIM0CLK_PRS16;  /* PCLK/16 */
    stcAtim0BaseCfg.u32CntMode     = ATIM0_M0_M0CR_MD_16BIT_ARR;    /* 自动重载16位计数器/定时器 */
    stcAtim0BaseCfg.u32EnTog       = ATIM0_M0_M0CR_TOG_OFF;         /* TOG使能 */
    stcAtim0BaseCfg.u32EnGate      = ATIM0_M0_M0CR_GATE_OFF;        /* 门控功能关闭 */
    stcAtim0BaseCfg.u32GatePolar   = ATIM0_M0_M0CR_GATE_POLAR_HIGH;

    ATIM0_Mode0_Init(&stcAtim0BaseCfg); /* ATIM0 的模式0功能初始化 */

    u16ArrValue = 0x10000 - u16Period;
    ATIM0_Mode0_ARRSet(u16ArrValue); /* 设置重载值 */

    u16CntValue = 0x10000 - u16Period;
    ATIM0_Mode0_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM0_Mode0_Enable_Output(TRUE); /* ATIM0 端口输出使能 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
