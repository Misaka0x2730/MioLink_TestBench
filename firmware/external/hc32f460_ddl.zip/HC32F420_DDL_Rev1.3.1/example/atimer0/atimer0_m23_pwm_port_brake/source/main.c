/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static volatile uint16_t u16MainLoopCnt;
static volatile uint16_t u16MainLoopFlag;
static volatile uint16_t u16BkDelayCnt;

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Timer0_Port_Cfg(void);
static void App_Timer0_Cfg(uint16_t u16Period, uint16_t u16CHxACompare, uint16_t u16CHxBCompare);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Clock_Cfg(); /* 时钟初始化 */

    App_Timer0_Cfg(0x12C0, 0x900, 0); /* Atimer0 配置:周期 0x12C0(clk 48M, f = 5K);        */
                                      /* CH0/1/0x900; CH0/1/2通道B比较值互补模式不需要设置 */

    App_Timer0_Port_Cfg(); /* Atimer0 Port端口配置 */

    ATIM0_Mode23_Run(); /* 运行 */

    /* 可添加其他其他操作，待准备好后使能PWM输出 */

    ATIM0_Mode23_Manual_PWM_Output_Enable(TRUE); /* 端口输出使能 */

    while (1)
    {
        if (1 == u16MainLoopFlag) /* 1ms延时 */
        {
            u16MainLoopFlag = 0;

            if (TRUE == ATIM0_GetIntFlag(ATIM0_INT_FLAG_BI)) /* 是否发生刹车事件 */
            {
                u16BkDelayCnt++;
                if (u16BkDelayCnt >= 4000) /* 发生Brake，延时4后恢复PWM输出 */
                {
                    u16BkDelayCnt = 0;
                    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_BI);        /* 清除刹车标志 */
                    ATIM0_Mode23_Manual_PWM_Output_Enable(TRUE); /* 端口输出使能 */
                }
            }
        }
    }
}

/**
 * @brief  ATIM0_UEV 中断函数
 * @retval None
 */
void ATim0_Uev_IRQHandler(void)
{
    static uint8_t i;

    /* Atimer0 模式23 更新中断 */
    if (0 == i)
    {
        STK_LED_ON(); /* LED 引脚输出高电平 */

        ATIM0_Mode23_Channel_Compare_Value_Set(ATIM0_COMPARE_CAPTURE_CH0A, 0xA00); /* 设置CHA比较值 */

        i++;
    }
    else if (1 == i)
    {
        STK_LED_OFF(); /* LED 引脚输出低电平 */

        ATIM0_Mode23_Channel_Compare_Value_Set(ATIM0_COMPARE_CAPTURE_CH0A, 0x600); /* 设置CHA比较值 */

        i = 0;
    }

    u16MainLoopCnt++;
    if (u16MainLoopCnt >= 5) /* 为主循环延时1ms */
    {
        u16MainLoopCnt  = 0;
        u16MainLoopFlag = 1;
    }

    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI); /* 清中断标志 */
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON 
                               | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0 
                             | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  ATIM0 CHx 端口配置
 * @retval None
 */
static void App_Timer0_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* PA09(ATIM0_BK) 作为刹车输入端口 */
    DDL_ZERO_STRUCT(stcGpioInit);          /* 结构体初始化清零             */
    stcGpioInit.u32Pin  = GPIO_PIN_09;     /* 端口引脚->P09                */
    stcGpioInit.u32Mode = GPIO_MODE_INPUT; /* 端口方向配置->输入           */
    GPIOA_Init(&stcGpioInit);              /* 端口初始化                   */
    GPIO_PA09_AF_ATIM0_BK_SET();           /* PA09复用为ATIM0_BK           */

    /* PA10(ATIM0_CH0A) PA11(ATIM0_CH0B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零         */
    GPIO_PA10_RESET();                                   /* 端口初始电平->低         */
    GPIO_PA11_RESET();                                   /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_10 | GPIO_PIN_11; /* 端口引脚->P10，P11       */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;       /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                            /* 端口初始化               */
    GPIO_PA10_AF_ATIM0_CH0A_SET();                       /* PA10复用为ATIM0_CH0A     */
    GPIO_PA11_AF_ATIM0_CH0B_SET();                       /* PA11复用为ATIM0_CH0B     */
}

/**
 * @brief  ATIM0 配置
 * @param  [in] u16Period:        周期
 * @param  [in] u16CHxACompare:   CHA比较值
 * @param  [in] u16CHxBCompare:   CHB比较值
 * @retval None
 */
static void App_Timer0_Cfg(uint16_t u16Period, uint16_t u16CHxACompare, uint16_t u16CHxBCompare)
{
    uint16_t                     u16CntValue;
    stc_atim0_mode23_cfg_t       stcAtim0BaseCfg     = {0};
    stc_atim0_m23_compare_cfg_t  stcAtim0ChxACmpCfg  = {0};
    stc_atim0_m23_compare_cfg_t  stcAtim0ChxBCmpCfg  = {0};
    stc_atim0_m23_dt_cfg_t       stcAtim0DeadTimeCfg = {0};
    stc_atim0_m23_bk_input_cfg_t stcBkCfg            = {0};
    stc_atim0_m23_rcr_cfg_t      stcRcrCfg           = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* ATIM0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                                            /* 结构体初始化清零 */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M23_M23CR_WORK_MODE_TRIANGULAR;       /* 三角波模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M23_M23CR_CT_PCLK;                    /* 定时器功能，计数时钟为内部PCLK */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M23_M23CR_ATIM0CLK_PRS1;              /* PCLK */
    stcAtim0BaseCfg.u32PWMTypeSel  = ATIM0_M23_M23CR_COMP_PWM_COMP;              /* 互补输出PWM */
    stcAtim0BaseCfg.u32PWM2sSel    = ATIM0_M23_M23CR_PWM2S_COMPARE_SINGLE_POINT; /* 单点比较功能 */
    stcAtim0BaseCfg.u32ShotMode    = ATIM0_M23_M23CR_SHOT_CYCLE;                 /* 循环计数 */
    stcAtim0BaseCfg.u32URSSel      = ATIM0_M23_M23CR_URS_OV_UND;                 /* 上下溢更新 */
    ATIM0_Mode23_Init(&stcAtim0BaseCfg);                                         /* ATIM0 的模式23功能初始化 */

    /* 48M, f = 10K, */
    ATIM0_Mode23_ARRSet(u16Period); /* 设置重载值,并使能缓存 */
    ATIM0_Mode23_ARR_Buffer_Enable(TRUE);

    ATIM0_Mode23_Channel_Compare_Value_Set(ATIM0_COMPARE_CAPTURE_CH0A, u16CHxACompare); /* 设置CHA比较值 */

    DDL_ZERO_STRUCT(stcAtim0ChxACmpCfg); /* 结构体初始化清零 */
    stcAtim0ChxACmpCfg.u32CHxCmpCap      = ATIM0_M23_CRCHx_CSA_CSB_COMPARE;
    stcAtim0ChxACmpCfg.u32CHxCmpModeCtrl = ATIM0_M23_FLTR_OCMxx_PWM_MODE_2;    /* OCREFA输出控制OCMA:PWM模式2 */
    stcAtim0ChxACmpCfg.u32CHxPolarity    = ATIM0_M23_FLTR_CCPxx_NORMAL_IN_OUT; /* 正常输出 */
    stcAtim0ChxACmpCfg.u32CHxCmpBufEn    = ATIM0_M23_CRCHx_BUFEx_ENABLE;       /* A通道缓存控制 */
    stcAtim0ChxACmpCfg.u32CHxCmpIntSel   = ATIM0_M23_M23CR_CISA_DISABLE_IRQ;   /* A通道比较控制:无 */
    ATIM0_Mode23_PortOutput_CHA_Cfg(&stcAtim0ChxACmpCfg);                      /* CHA比较输出端口配置 */

    DDL_ZERO_STRUCT(stcAtim0ChxBCmpCfg); /* 结构体初始化清零 */
    stcAtim0ChxBCmpCfg.u32CHxCmpCap      = ATIM0_M23_CRCHx_CSA_CSB_COMPARE;
    stcAtim0ChxBCmpCfg.u32CHxCmpModeCtrl = ATIM0_M23_FLTR_OCMxx_PWM_MODE_2;    /* OCREFB输出控制OCMB:PWM模式2(PWM互补模式下也要设置，避免强制输出) */
    stcAtim0ChxBCmpCfg.u32CHxPolarity    = ATIM0_M23_FLTR_CCPxx_NORMAL_IN_OUT; /* 正常输出 */
    stcAtim0ChxBCmpCfg.u32CHxCmpIntSel   = ATIM0_M23_CRCHx_CISBx_DISABLE_IRQ;  /* B通道比较控制:无 */
    ATIM0_Mode23_PortOutput_CHB_Cfg(&stcAtim0ChxBCmpCfg);                      /* CHB比较输出端口配置 */

    DDL_ZERO_STRUCT(stcAtim0DeadTimeCfg); /* 结构体初始化清零 */
    stcAtim0DeadTimeCfg.bEnDeadTime      = TRUE;
    stcAtim0DeadTimeCfg.u32DeadTimeValue = 0xFF;
    ATIM0_Mode23_DT_Cfg(&stcAtim0DeadTimeCfg); /* 死区设置 */

    DDL_ZERO_STRUCT(stcRcrCfg);                                          /* 结构体初始化清零 */
    stcRcrCfg.u32EnOverFLowMask  = ATIM0_M23_RCR_OVF_IRQ_EVT_CNT_MASK;   /* 屏蔽上溢重复计数 */
    stcRcrCfg.u32EnUnderFlowMask = ATIM0_M23_RCR_UND_IRQ_EVT_CNT_ENABLE; /* 使能下溢重复计数 */
    stcRcrCfg.u32RepeatCountNum  = 0;
    ATIM0_Mode23_SetRepeatPeriod(&stcRcrCfg); /* 间隔周期设置 */

    ATIM0_Mode23_Brake_Port_Status_Cfg(ATIM0_M23_CRCHx_BKSA_BKSB_PORT_OUTPUT_LOW, 
        ATIM0_M23_CRCHx_BKSA_BKSB_PORT_OUTPUT_LOW); /* 刹车使能时，CHx端口输出低电平 */

    DDL_ZERO_STRUCT(stcBkCfg);                                     /* 结构体初始化清零 */
    stcBkCfg.u32BrakePolarity = ATIM0_M23_FLTR_BKP_REVERSE_IN;     /* 反向输入(低电平刹车) */
    stcBkCfg.u32BrakeFlt      = ATIM0_M23_FLTR_FLTxx_THREE_PCLK_4; /* PCLK/4 3个连续有效 */
    stcBkCfg.u32EnBrake       = ATIM0_M23_DTR_BKE_BRAKE_ENABLE;
    ATIM0_Mode23_BrakeInput_Cfg(&stcBkCfg); /* 刹车功能配置 */

    u16CntValue = 0;
    ATIM0_Mode23_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM0_ClearAllIrqFlag();                     /* 清中断标志 */
    ATIM0_Mode23_EnableIrq(ATIM0_M23_INT_UI);    /* 使能ATIM0 UEV更新中断 */
    EnableNvic(ATIM0_UEV_IRQn, IrqLevel0, TRUE); /* ATIM0中断使能 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
