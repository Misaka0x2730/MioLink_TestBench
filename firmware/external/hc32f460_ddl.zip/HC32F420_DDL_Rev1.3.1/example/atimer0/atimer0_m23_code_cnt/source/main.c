/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static volatile uint16_t u16ATIMCnt;

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Atimer0_Port_Cfg(void);
static void App_Timer0_Cfg(void);
static void App_Gen_Clk_In(void);
static void App_LED_Display_Cnt(void);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    stc_atim0_m23_master_slave_cfg_t stcTim0MSCfg;

    App_Clock_Cfg(); /* 时钟初始化 */

    App_Atimer0_Port_Cfg(); /* Atimer0 Port端口配置 */

    App_Timer0_Cfg(); /* Timer0 配置 */

    /* 正交编码计数模式1 */
    DDL_ZERO_STRUCT(stcTim0MSCfg); /* 结构体初始化清零 */
    stcTim0MSCfg.u32SlaveModeSel = ATIM0_M23_MSCR_SMS_QUADRATURE_M1;
    ATIM0_Mode23_MasterSlave_Trig_Set(&stcTim0MSCfg);

    ATIM0_Mode23_Cnt16Set(0u); /* Cnt清零 */
    ATIM0_Mode23_Run();        /* 运行 */
    App_Gen_Clk_In();          /* 信号输入并计数 */
    ATIM0_Mode23_Stop();       /* 停止 */
    GPIO_PA05_RESET();         /* PA5清零 */
    GPIO_PA06_RESET();         /* PA6清零 */
    delay1ms(1000);

    /* 正交编码计数模式2 */
    DDL_ZERO_STRUCT(stcTim0MSCfg); /* 结构体初始化清零 */
    stcTim0MSCfg.u32SlaveModeSel = ATIM0_M23_MSCR_SMS_QUADRATURE_M2;
    ATIM0_Mode23_MasterSlave_Trig_Set(&stcTim0MSCfg);

    ATIM0_Mode23_Cnt16Set(0u); /* Cnt清零 */
    ATIM0_Mode23_Run();        /* 运行 */
    App_Gen_Clk_In();          /* 信号输入并计数 */
    ATIM0_Mode23_Stop();       /* 停止 */
    GPIO_PA05_RESET();         /* PA5清零 */
    GPIO_PA06_RESET();         /* PA6清零 */
    delay1ms(1000);

    /* 正交编码计数模式3 */
    DDL_ZERO_STRUCT(stcTim0MSCfg); /* 结构体初始化清零 */
    stcTim0MSCfg.u32SlaveModeSel = ATIM0_M23_MSCR_SMS_QUADRATURE_M3;
    ATIM0_Mode23_MasterSlave_Trig_Set(&stcTim0MSCfg);

    ATIM0_Mode23_Cnt16Set(0u); /* Cnt清零 */
    ATIM0_Mode23_Run();        /* 运行 */
    App_Gen_Clk_In();          /* 信号输入并计数 */
    ATIM0_Mode23_Stop();       /* 停止 */
    GPIO_PA05_RESET();         /* PA5清零 */
    GPIO_PA06_RESET();         /* PA6清零 */
    delay1ms(1000);

    while (1)
    {
        ;
    }
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0 | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  ATIM0 CHx 端口配置
 * @retval None
 */
void App_Atimer0_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* PA05(模拟正交信号A)和PA06(模拟正交信号B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零         */
    GPIO_PA05_RESET();                                   /* 端口初始电平->低         */
    GPIO_PA06_RESET();                                   /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_05 | GPIO_PIN_06; /* 端口引脚->P05&P06        */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;       /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                            /* 端口初始化               */

    /* PB00(ATIM0_CH0A)和PB01(ATIM0_CH0B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_00 | GPIO_PIN_01; /* 端口引脚->P00&P01        */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT;           /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                            /* 端口初始化               */
    GPIO_PB00_AF_ATIM0_CH0A_SET();                       /* PB00复用为ATIM0_CH0A     */
    GPIO_PB01_AF_ATIM0_CH0B_SET();                       /* PB01复用为ATIM0_CH0B     */
}

/**
 * @brief  ATIM0 配置
 * @retval None
 */
void App_Timer0_Cfg(void)
{
    uint16_t               u16ArrValue;
    stc_atim0_mode23_cfg_t stcAtim0BaseCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* ATIM0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                                  /* 结构体初始化清零 */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M1_M1CR_WORK_MODE_SAWTOOTH; /* 锯齿波模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M23_M23CR_CT_PCLK;          /* 定时器功能，计数时钟为内部PCLK */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M23_M23CR_ATIM0CLK_PRS64;   /* PCLK/64 */
    stcAtim0BaseCfg.u32CntDir      = ATIM0_M23_M23CR_DIR_UP_CNT;       /* 向上计数，在三角波模式时只读 */
    ATIM0_Mode23_Init(&stcAtim0BaseCfg);                               /* ATIM0 的模式23功能初始化 */

    u16ArrValue = 0xFFFFU;
    ATIM0_Mode23_ARRSet(u16ArrValue); /* 设置重载值,并使能缓存 */
    ATIM0_Mode23_ARR_Buffer_Enable(TRUE);
}

/**
 * @brief  模拟产生编码器信号，仅供本样例调试用
 * @retval None.
 */
void App_Gen_Clk_In(void)
{
    uint32_t i;

    uint8_t bAin[17] = {0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1};
    uint8_t bBin[17] = {0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0};

    for (i = 0; i < 17; i++)
    {
        if (1U == bAin[i])
        {
            GPIO_PA05_SET(); /* PA5置位 */
        }
        else
        {
            GPIO_PA05_RESET(); /* PA5清零 */
        }

        if (1U == bBin[i])
        {
            GPIO_PA06_SET(); /* PA6置位 */
        }
        else
        {
            GPIO_PA06_RESET(); /* PA6清零 */
        }

        App_LED_Display_Cnt();
    }
}

/**
 * @brief  LED亮灭，闪烁次数代表计数值
 *         仅供调试使用,在正交信号AB模拟输出刷新后均会闪烁以显示Cnt的值，具体闪烁次数依据设置的正交编码计数模式和Cnt的值决定
 * @retval 需设置局部变量cnt的最大值 > u16ATIMCnt的最大值，否则LED显示不对标Cnt的值.
 */
void App_LED_Display_Cnt(void)
{
    uint32_t cnt;
    u16ATIMCnt = HC_ATIM0MODE23->CNT_f.CNT; /* 获取正交编码计数值 */
    for (cnt = 0; cnt < 50; cnt++)
    {
        if (cnt < u16ATIMCnt)
        {
            STK_LED_ON();
        }
        else
        {
            STK_LED_OFF();
        }
        delay1ms(2);
        STK_LED_OFF();
        delay1ms(2);
    }
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
