/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim0.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_PortCfg(void);
static void App_Atimer0_Cfg(uint16_t u16Period);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_PortCfg(); /* LED端口配置 */

    App_Atimer0_Cfg(1000); /* ATIM0 配置 */

    ATIM0_Mode0_Run(); /* ATIM0 运行 */

    while (1)
        ;
}

/**
 * @brief  ATIM0_UEV 中断函数
 * @retval None
 */
void ATim0_Uev_IRQHandler(void)
{
    static uint8_t i;

    /* ATIM0 模式0 计时溢出中断 */
    if (0 == i)
    {
        STK_LED_ON(); /* LED引脚输出高电平 */
        i++;
    }
    else
    {
        STK_LED_OFF(); /* LED引脚输出低电平 */
        i = 0;
    }

    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI); /* ATIM0 模式0 中断标志清除 */
}

/**
 * @brief  IO端口配置
 * @retval None
 */
static void App_PortCfg(void)
{
    stc_gpio_init_t stcGpioInit    = {0};
    stc_gpio_init_t stcETRGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /*PA00 设置为ATIM0_ETR */
    DDL_ZERO_STRUCT(stcETRGpioInit);              /* 结构体初始化清零             */
    stcETRGpioInit.u32Pin      = GPIO_PIN_00;     /* 端口引脚->P00                */
    stcETRGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入           */
    stcETRGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉     */
    GPIOA_Init(&stcETRGpioInit);                  /* 端口初始化                   */
    GPIO_PA00_AF_ATIM0_ETR_SET();                 /* PA00复用为ATIM0_ETR          */
}

/**
 * @brief  ATIM0 配置
 * @param  [in] u16Period:        周期
 * @retval None
 */
static void App_Atimer0_Cfg(uint16_t u16Period)
{
    uint16_t              u16ArrValue;
    uint16_t              u16CntValue;
    stc_atim0_mode0_cfg_t stcAtim0BaseCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim0); /* ATIM0 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim0BaseCfg);                               /* 结构体初始化清零 */
    stcAtim0BaseCfg.u32WorkMode    = ATIM0_M0_M0CR_WORK_MODE_TIMER; /* 定时器模式 */
    stcAtim0BaseCfg.u32CountClkSel = ATIM0_M0_M0CR_CT_ETR;          /* 计数器功能，计数时钟为外部时钟ETR信号 */
    stcAtim0BaseCfg.u32PRS         = ATIM0_M0_M0CR_ATIM0CLK_PRS1;   /* PCLK */
    stcAtim0BaseCfg.u32CntMode     = ATIM0_M0_M0CR_MD_16BIT_ARR;    /* 自动重载16位计数器/定时器 */
    stcAtim0BaseCfg.u32EnTog       = ATIM0_M0_M0CR_TOG_OFF;         /* TOG关闭 */
    stcAtim0BaseCfg.u32EnGate      = ATIM0_M0_M0CR_GATE_OFF;        /* 门控功能关闭 */
    stcAtim0BaseCfg.u32GatePolar   = ATIM0_M0_M0CR_GATE_POLAR_HIGH;

    ATIM0_Mode0_Init(&stcAtim0BaseCfg); /* ATIM0 的模式0功能初始化 */

    u16ArrValue = 0x10000 - u16Period;
    ATIM0_Mode0_ARRSet(u16ArrValue); /* 设置重载值(ARR = 0x10000 - 周期) */

    u16CntValue = 0x10000 - u16Period;
    ATIM0_Mode0_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM0_ClearIrqFlag(ATIM0_INT_CLR_UI);        /* 清中断标志 */
    ATIM0_Mode0_EnableIrq();                     /* 使能ATIM0中断(模式0时只有一个中断) */
    EnableNvic(ATIM0_UEV_IRQn, IrqLevel3, TRUE); /* ATIM0 开中断 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
