/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of spi.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"
#include "spi.h"
#include "gpio.h"
#include "flash.h"
#include "sysctrl.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
//主机相关数据
static  uint16_t u8MasterTxBuf[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
static __attribute((used)) uint16_t u8MasterRxBuf[10] = {0};
/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
static uint8_t u8TxIndex = 0;
static uint8_t u8RxIndex = 0;
static uint8_t SPI_Complete = 0;
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_ClkCfg(void);
static void App_GpioInit(void);
static void App_SPI0Init(void);

/**
* @brief  主机接收非空中断处理函数
 * @retval None
 */
void Spi0_Rx_IRQHandler(void)
{
    /* 清除标志位*/   
    SPI_ClearFlag(HC_SPI0, SPI_CLEAR_RXNE); 
    
    /* 获取接收数据*/ 
    u8MasterRxBuf[u8RxIndex++] = Spi_ReceiveData(HC_SPI0);

    /* 发送数据*/     
    if(u8TxIndex < 10)
    {
        Spi_Slave_DummyWriteData(HC_SPI0,u8MasterTxBuf[u8TxIndex++]);       
    }
    else
    {
        u8TxIndex = 0;
        SPI_Complete = 1;   
    }
}

/**
 * @brief  Main function of project
 * @retval None
 */
int32_t main(void)
{  
    /* 系统时钟初始化 */   
    App_ClkCfg();
    
    /* SPI0 Master 端口初始化 */
    App_GpioInit(); 

    /* SPI0 Master 配置*/
    App_SPI0Init();     

    /* SPI0 使能 */
    SPI_Enable(HC_SPI0);   
    
    /* 主机 NSS片选后开始通讯 */
    SPI_MasterNSSOutput(HC_SPI0, SPI_NSS_CONFIG_ENABLE);

    /* 确保从机识别到片选信号 */
    delay1ms(10);
   
    /* 主机向从机发送数据第一个数据 */
    u8TxIndex = 1;
    Spi_Slave_DummyWriteData(HC_SPI0, u8MasterTxBuf[0]);


    while(1)
    {
        if(SPI_Complete == 1)
        {
            /* 主机 拉高NSS片选 */
            SPI_MasterNSSOutput(HC_SPI0, SPI_NSS_CONFIG_DISABLE);   
            SPI_Complete = 0;           
        }
    }        
}


/**
 * @brief  系统时钟模块配置
 * @retval None
 */
static void App_ClkCfg(void)
{   
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t stcSysClk = {0};

    /* 系统时钟源初始化 */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH |\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_RCL |\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_XTH |\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;
    
    stcSysClkSrc.u32RCHState         = SYSCTRL_RCH_TRIM_24MHz|\
                                       SYSCTRL_RCH_DIV2;
    
    stcSysClkSrc.u32RCLState         = SYSCTRL_RCL_TRIM_32p8KHz |\
                                       SYSCTRL_RCL_WAITCYCLE256;
    
    stcSysClkSrc.u32XTHState         = SYSCTRL_XTH_DRV2 |\
                                       SYSCTRL_XTH_8t16MHz |\
                                       SYSCTRL_XTH_WAITCYCLE3;
    
    stcSysClkSrc.u32PLLState         = SYSCTRL_PLL_MULM_CONFIG(14) |\
                                       SYSCTRL_PLL_DIVN_CONFIG(1)  |\
                                       SYSCTRL_PLL_OEN_ON|\
                                       SYSCTRL_PLL_WAITCYCLE_CONFIG(7) |\
                                       SYSCTRL_PLL_OD_CONFIG(1) |\
                                       SYSCTRL_PLL_SRC_RCH;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}
  

    /* 系统时钟初始化 */     
    stcSysClk.u32ClockType          = SYSCTRL_CLOCKTYPE_SYSCLK |\
                                      SYSCTRL_CLOCKTYPE_HCLK   |\
                                      SYSCTRL_CLOCKTYPE_PCLK0  |\
                                      SYSCTRL_CLOCKTYPE_PCLK1;
                                    
    stcSysClk.u32SysClkSource       = SYSCTRL_SYSCLK_SOURCE_PLL; /* 选择PLL为系统时钟 Pclk = ((RCH_D = 24/6)*32/1)>>2 = 64MHZ */ 
    stcSysClk.u32HClkDiv            = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK = Pclk = 64MHZ */
    stcSysClk.u32PClk0Div           = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0 = Hclk = 64MHZ */
    stcSysClk.u32PClk1Div           = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1 = Hclk = 64MHZ */
    stcSysClk.u32WaitCycle          = SYSCTRL_FLASH_WAIT_CYCLE3; /* FLash_Wait = 3 */

    SYSCTRL_SysClkInit(&stcSysClk);
}

/**
 * @brief  系统端口初始化
 * @retval None
 */
static void App_GpioInit(void)
{
    stc_gpio_init_t stcGpioInit = {0};
    
    /* 使能GPIO_A/B的时钟 */   
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa);
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob);
    
    /* 配置CS */  
    stcGpioInit.u32Pin = GPIO_PIN_15;
    stcGpioInit.u32Mode = GPIO_MODE_OUTPUT_PP; 
    GPIOA_Init(&stcGpioInit); 
    
    /* 配置SCK和MOSI */
    stcGpioInit.u32Pin = GPIO_PIN_03|GPIO_PIN_05;
    stcGpioInit.u32Mode = GPIO_MODE_OUTPUT_PP; 
    GPIOB_Init(&stcGpioInit); 
    
    /* 配置MISO */  
    stcGpioInit.u32Pin = GPIO_PIN_04;
    stcGpioInit.u32Mode = GPIO_MODE_INPUT; 
    GPIOB_Init(&stcGpioInit);   
    
    /* 开启复用功能*/   
    GPIO_PA15_AF_SPI0_CS_SET();     
    GPIO_PB03_AF_SPI0_SCK_SET();   
    GPIO_PB05_AF_SPI0_MOSI_SET(); 
    GPIO_PB04_AF_SPI0_MISO_SET();
}   
/**
 * @brief  初始化SPI0
 * @retval None
 */                                               
static void App_SPI0Init(void)                                                                                                  
{                                                                                                                               
    stc_spi_init_t  SpiInitStruct={0};                                                                                          
    
    /* 第一步：开启SPI0时钟门控 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralSpi0);                 
    
    /* 第二步：复位SPI0模块 */
    SYSCTRL_PeriphReset(SysctrlPeripheralSpi0);                     
    
    /* 第三步：SPI0模块配置：主机 */      
    SpiInitStruct.u32Mode              = SPI_MODE_MASTER;                 /* 主机模式 */     
    SpiInitStruct.u32TransferDirection = SPI_FULL_DUPLEX;                 /* 全双工双向 */    
    SpiInitStruct.u32BaudRate          = SPI_BAUDRATE_PCLK_DIV4;          /* pclk/4 */
    SpiInitStruct.u32CPOL              = SPI_CLOCK_POLARITY_LOW;          /* 待机时低电平 */   
    SpiInitStruct.u32CPHA              = SPI_CLOCK_PHASE_1EDGE;           /* 第一个边沿采样(第二个边沿移位) */
    SpiInitStruct.u32DataWidth         = SPI_DATAWIDTH_16BIT;             /* 16bit数据宽度 */   
    SpiInitStruct.u32BitOrder          = SPI_MSB_FIRST;                   /* 最高有效位MSB收发在前 */   
    SpiInitStruct.u32NSS               = SPI_NSS_HARD_OUTPUT;             /* NSS信号由IO管脚输出 */                          
    SpiInitStruct.u32SampleDelay       = SPI_SAMPLE_DELAY;                /* 正常采样 */                                                                        
//    SpiInitStruct.u32DMAReq            = SPI_DMA_TRANSFER_RX_TX_DISABLE;  /* 关闭DMA */   
    
    Spi_Init(HC_SPI0, &SpiInitStruct);
    
    /* 第四步：清除所有中断标志位 */
    SPI_ClearFlag_ALL(HC_SPI0);  

    /* 第五步：使能接收缓冲非空中断 */
    SPI_EnableIT(HC_SPI0, SPI_IT_RXNE);
    EnableNvic(SPI0_RX_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
