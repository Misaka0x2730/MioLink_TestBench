/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "flash.h"
#include "gpio.h"
#include "i2c.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define I2C_SLAVEADDR 0xA0

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static en_result_t I2C_MasterWriteData(I2C_TypeDef* I2CX, uint8_t* pu8Data, uint32_t u32Len);
static en_result_t I2C_MasterReadData(I2C_TypeDef* I2CX, uint8_t* pu8Data, uint32_t u32Len);
static void        App_PortCfg(void);
static void        App_I2cCfg(void);

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
static uint8_t u8Senddata[10] = {0x12, 0x34, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11, 0x99};
static uint8_t u8Recdata[10]  = {0x00};

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    /* IO端口配置 */
    App_PortCfg();

    /* 等待 USER按键 按下 */
    while (0 != STK_USERKEY_READ())
        ;

    /* I2C 模块配置 */
    App_I2cCfg();

    /* 使能I2C模块 */
    I2C_Enable(HC_I2C0);

    /* I2C总线发送START起始位，开始传输数据 */
    I2C_SetStart(HC_I2C0, I2C_START_ENABLE);
    I2C_MasterWriteData(HC_I2C0, u8Senddata, 10); /* 主机发送10字节数据 */
    delay1ms(10);
    I2C_MasterReadData(HC_I2C0, u8Recdata, 10); /* 主机读取10字节数据 */

    if (0U == memcmp((void*)u8Recdata, (void*)u8Senddata, 10))
    {
        STK_LED_ON(); /* 对比数据一致点亮LED */
    }
    else
    {
        STK_LED_OFF(); /* 对比数据不一致熄灭LED */
    }

    while (1) {}
}

/**
 * @brief  IO端口配置
 * @retval None
 */
static void App_PortCfg(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOC外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;       /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_EXT_INT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;    /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                    /* 端口初始化               */

    /* I2C_SCL(PC04)和I2C_SDA(PC05)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零       */
    stcGpioInit.u32Pin      = GPIO_PIN_04 | GPIO_PIN_05; /* 端口引脚->P04 P05      */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_OD;       /* 端口方向配置->开漏输出 */
    stcGpioInit.u32PullUpDn = GPIO_PULL_UP;              /* 端口上下拉配置->上拉   */
    GPIOC_Init(&stcGpioInit);
    GPIO_PC04_AF_I2C0_SCL_SET(); /* PC04复用为SCL */
    GPIO_PC05_AF_I2C0_SDA_SET(); /* PC05复用为SDA */
}

/**
 * @brief  I2C 模块配置
 * @retval None
 */
static void App_I2cCfg(void)
{
    stc_i2c_master_init_cfg_t stcI2cCfg = {0U};

    /* 第一步：开启I2C时钟门控  */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralI2c0);

    /* 第二步：复位I2C模块 */
    SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_I2C0);

    /* 第三步：I2C主机 初始化配置 */
    DDL_ZERO_STRUCT(stcI2cCfg);                 /* 结构体初始化清零 */
    stcI2cCfg.u32Pclk     = SYSCTRL_GetPCLK0(); /* 获取PCLK时钟 */
    stcI2cCfg.u32BaudRate = 100000;             /* 100KHz */
    I2C_MasterInit(HC_I2C0, &stcI2cCfg);        /* 模块主机模式初始化 */
}

/**
 * @brief  主机读函数
 * @param  [in] I2CX:       I2C 单元
 * @param  [in] pu8Data:    读数据缓存指针
 * @param  [in] u32Len:     读数据长度
 * @retval en_result_t:
 *         - Ok: 读取成功
 */
static en_result_t I2C_MasterReadData(I2C_TypeDef* I2CX, uint8_t* pu8Data, uint32_t u32Len)
{
    en_result_t enRet = Error;
    uint8_t     u8i   = 0, u8State;

    /* I2C总线发送START起始位，开始传输数据 */
    I2C_SetStart(I2CX, I2C_START_ENABLE);

    while (1)
    {
        while (0 == I2C_IsActiveFlag_SI(I2CX)) /* 等待SI标志位置位 */ {}
        u8State = I2C_GetBusState(I2CX);
        switch (u8State)
        {
            case 0x08:                                 /* 已发送起始条件，将发送SLA+R                ***主机读：步骤1 */
                I2C_SetStart(I2CX, I2C_START_DISABLE); /* 清除start */
                I2C_WriteByte(I2CX, (I2C_SLAVEADDR | 0x01));
                break;
            case 0x18:                  /* 已发送SLA+W,并接收到ACK(此样例中未用到) */
                I2C_WriteByte(I2CX, 0); /* 发送内存地址 */
                break;
            case 0x28: /* 已发送数据，接收到ACK, 此处是已发送从机内存地址u8Addr并接收到ACK(此样例中未用到) */
                I2C_SetStart(I2CX, I2C_START_ENABLE);
                break;
            case 0x10: /* 已发送重复起始条件 */
                I2C_SetStart(I2CX, I2C_START_DISABLE);
                I2C_WriteByte(I2CX, (I2C_SLAVEADDR | 0x01)); /* 发送SLA+R，开始从从机读取数据 */
                break;
            case 0x40: /* 已发送SLA+R，并接收到ACK                   ***主机读：步骤2 */
                if (u32Len > 1)
                {
                    I2C_SetAck(I2CX, I2C_ACK); /* 使能主机应答功能 */
                }
                break;
            case 0x50: /* 已接收数据字节，并已返回ACK信号            ***主机读：步骤3 */
                pu8Data[u8i++] = I2C_ReadByte(I2CX);
                if (u8i == u32Len - 1)
                {
                    I2C_SetAck(I2CX, I2C_NACK); /* 已接收到倒数第二个字节，关闭ACK应答功能    ***主机读：步骤4 */
                }
                break;
            case 0x58: /* 已接收到最后一个数据，NACK已返回           ***主机读：步骤5 */
                pu8Data[u8i++] = I2C_ReadByte(I2CX);
                I2C_SetStop(I2CX, I2C_STOP_ENABLE); /* 发送停止条件 */
                break;
            case 0x38:                                /* 在发送地址或数据时，仲裁丢失 */
                I2C_SetStart(I2CX, I2C_START_ENABLE); /* 当总线空闲时发起起始条件 */
                break;
            case 0x48:                                /* 发送SLA+R后，收到一个NACK */
                I2C_SetStop(I2CX, I2C_STOP_ENABLE);   /* 发送停止条件 */
                I2C_SetStart(I2CX, I2C_START_ENABLE); /* 发送起始条件 */
                break;
            default:
                I2C_SetStart(I2CX, I2C_START_ENABLE); /* 其他错误状态，重新发送起始条件 */
                break;
        }
        I2C_ClearFlag_SI(I2CX); /* 清除中断状态标志位 */
        if (u8i == u32Len)      /* 数据全部读取完成，跳出while循环 */
        {
            break;
        }
    }
    enRet = Ok;
    return enRet;
}

/**
 * @brief  主机写函数
 * @param  [in] I2CX:       I2C 单元
 * @param  [in] pu8Data:    写数据缓存指针
 * @param  [in] u32Len:     写数据长度
 * @retval en_result_t:
 *         - Ok: 写成功
 */
static en_result_t I2C_MasterWriteData(I2C_TypeDef* I2CX, uint8_t* pu8Data, uint32_t u32Len)
{
    en_result_t enRet = Error;
    uint8_t     u8i   = 0, u8State;

    /* 发送起始条件 */
    I2C_SetStart(I2CX, I2C_START_ENABLE);
    while (1)
    {
        while (0 == I2C_IsActiveFlag_SI(I2CX))
        {
            ;
        }
        u8State = I2C_GetBusState(I2CX);
        switch (u8State)
        {
            case 0x08: /* 已发送起始条件                    ***主机写：步骤1 */
                I2C_SetStart(I2CX, I2C_START_DISABLE);
                I2C_WriteByte(I2CX, I2C_SLAVEADDR); /* 发送SLA+W */
                break;
            case 0x18:                               /* 已发送SLA+W，并接收到ACK          ***主机写：步骤2 */
            case 0x28:                               /* 上一次发送数据后接收到ACK         ***主机写：步骤3 */
                I2C_WriteByte(I2CX, pu8Data[u8i++]); /* 继续发送数据 */
                break;
            case 0x20:                                /* 上一次发送SLA+W后，收到NACK */
            case 0x38:                                /* 上一次在SLA+读或写时丢失仲裁 */
                I2C_SetStart(I2CX, I2C_START_ENABLE); /* 当I2C总线空闲时发送起始条件 */
                break;
            case 0x30:                              /* 已发送I2Cx_DATA中的数据，收到NACK，将传输一个STOP条件 */
                I2C_SetStop(I2CX, I2C_STOP_ENABLE); /* 发送停止条件 */
                break;
            default:
                break;
        }
        if (u8i > u32Len)
        {
            I2C_SetStop(I2CX, I2C_STOP_ENABLE); /* 此顺序不能调换，出停止条件        ***主机写：步骤4 */
            I2C_ClearFlag_SI(I2CX);
            break;
        }
        I2C_ClearFlag_SI(I2CX); /* 清除中断状态标志位 */
    }
    enRet = Ok;
    return enRet;
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
