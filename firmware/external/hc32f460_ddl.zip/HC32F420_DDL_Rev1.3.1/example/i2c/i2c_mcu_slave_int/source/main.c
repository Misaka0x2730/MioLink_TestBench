/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "flash.h"
#include "gpio.h"
#include "i2c.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_PortCfg(void);
static void App_I2cCfg(void);

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
static uint8_t u8Recdata[10] = {0x00};
static uint8_t u8SendLen     = 0;
static uint8_t u8RecvLen     = 0;
static uint8_t u8State       = 0;

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    /* IO端口配置 */
    App_PortCfg();

    /* 等待 USER按键 按下 */
    while (0 != STK_USERKEY_READ())
        ;

    /* I2C 模块配置 */
    App_I2cCfg();

    /* 使能I2C模块 */
    I2C_Enable(HC_I2C0);

    /* ACK打开，启动I2c数据传输 */
    I2C_SetAck(HC_I2C0, I2C_ACK);

    while (1)
    {
        ;
    }
}

/**
 * @brief  IO端口配置
 * @retval None
 */
static void App_PortCfg(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOC外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;       /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_EXT_INT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;    /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                    /* 端口初始化               */

    /* I2C_SCL(PC04)和I2C_SDA(PC05)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零       */
    stcGpioInit.u32Pin      = GPIO_PIN_04 | GPIO_PIN_05; /* 端口引脚->P04 P05      */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_OD;       /* 端口方向配置->开漏输出 */
    stcGpioInit.u32PullUpDn = GPIO_PULL_UP;              /* 端口上下拉配置->上拉   */
    GPIOC_Init(&stcGpioInit);
    GPIO_PC04_AF_I2C0_SCL_SET(); /* PC04复用为SCL */
    GPIO_PC05_AF_I2C0_SDA_SET(); /* PC05复用为SDA */
}

/**
 * @brief  I2C 模块配置
 * @retval None
 */
static void App_I2cCfg(void)
{
    stc_i2c_slave_init_cfg_t stcI2cCfg = {0};

    /* 第一步：开启I2C时钟门控  */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralI2c0);

    /* 第二步：复位I2C模块 */
    SYSCTRL_PeriphReset(SYSCTRL_PERIRESET_I2C0);

    /* 第三步：I2C从机 初始化配置 */
    DDL_ZERO_STRUCT(stcI2cCfg);                       /* 结构体初始化清零 */
    stcI2cCfg.u8SlaveAddr0   = 0x50;                  /* 从地址0，主模式无效 */
    stcI2cCfg.u8SlaveAddr1   = 0x00;                  /* 从地址1，主模式无效 */
    stcI2cCfg.u8SlaveAddr2   = 0x00;                  /* 从地址2，主模式无效 */
    stcI2cCfg.u32BroadcastEn = I2C_BROADCAST_DISABLE; /* 广播地址应答使能关闭，主模式无效 */
    stcI2cCfg.u32Filter      = I2C_FILTER_SIMPLE;     /* 高级滤波，更高的抗干扰性能 */
    I2C_SlaveInit(HC_I2C0, &stcI2cCfg);               /* 模块初始化 */

    /* 第四步： 中断开启 */
    I2C_ClearFlag_SI(HC_I2C0);              /* 开启中断前清除中断标志 */
    EnableNvic(I2C0_IRQn, IrqLevel3, TRUE); /* 使能NVIC对应中断位 */
}

/**
 * @brief  I2C 中断函数
 * @retval None
 */
void I2c0_IRQHandler(void)
{
    u8State = I2C_GetBusState(HC_I2C0);
    switch (u8State)
    {
        case 0x60: /* 已接收到(与自身匹配的)SLA+W；已接收ACK                   ***从机读：步骤1 ***从机写：步骤1 */
        case 0x70: /* 已接收通用调用地址（0x00）；已接收ACK */
        case 0xa0: /* 接收到停止条件或重复起始条件          */
            u8RecvLen = 0;
            break;
        case 0x68: /* 主控时在SLA+读写丢失仲裁；已接收自身的SLA+W；已返回ACK    */
        case 0x78: /* 主控时在SLA+读写中丢失仲裁；已接收通用调用地址；已返回ACK */
        case 0x88: /* 前一次寻址使用自身从地址；已接收数据字节；已返回非ACK     */
            break;
        case 0x80:                                          /* 前一次寻址使用自身从地址；已接收数据字节；已返回ACK      ***从机读：步骤2 */
        case 0x98:                                          /* 前一次寻址使用通用调用地址；已接收数据；已返回非ACK */
        case 0x90:                                          /* 前一次寻址使用通用调用地址；已接收数据；已返回ACK   */
            u8Recdata[u8RecvLen++] = I2C_ReadByte(HC_I2C0); /* 接收数据   */
            break;
        case 0xa8:                                          /* 已接收自身的SLA+R；已返回ACK,将要发出数据并将收到ACK位   ***从机写：步骤2 */
        case 0xb0:                                          /* 当主控时在SLA+读写中丢失仲裁；已接收自身SLA+R；已返回ACK */
            I2C_WriteByte(HC_I2C0, u8Recdata[u8SendLen++]); /* 发送数据首字节  */
            break;
        case 0xc8: /* 装入的数据字节已被发送；已接收ACK                                         */
        case 0xb8: /* 已发送数据；已接收ACK                                    ***从机写：步骤3 */
            I2C_WriteByte(HC_I2C0, u8Recdata[u8SendLen++]);
            break;
        case 0xc0: /* 发送数据，接收非ACK                                      ***从机写：步骤4 */
            break;
    }

    I2C_ClearFlag_SI(HC_I2C0);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
