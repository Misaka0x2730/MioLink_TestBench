/**
 *******************************************************************************
 * @file  main.c
 * @brief This file contains all the functions prototypes of the BTIMER driver
 *        library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MDAS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "btim.h"
#include "flash.h"
#include "gpio.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_Btimer5_Init(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* Btimer5初始化 */
    App_Btimer5_Init();

    /* 启动btim5运行 */
    Btim_Enable(HC_BTIM5);

    while (1)
    {
        ;
    }
}

/**
 * @brief  BTIMER5中断服务函数
 * @retval None.
 */
void GTim1_Ch23_BTimC_IRQHandler(void)
{
    static uint8_t i;

    if (TRUE == Btim_IsActiveFlag(HC_BTIM5, BTIM_IT_FLAG_UI))
    {
        if (0 == i)
        {
            STK_LED_ON(); /* LED 引脚输出高电平 */
            i++;
        }
        else
        {
            STK_LED_OFF(); /* LED 引脚输出低电平 */
            i = 0;
        }

        Btim_ClearFlag(HC_BTIM5, BTIM_IT_CLR_UI); /* 清除BTIM5的溢出中断标志位 */
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};
    stc_gpio_init_t stcEtrGpioInit = {0};
    stc_gpio_init_t stcTogGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);

    /* ETR(PD02)端口初始化 */
    stcEtrGpioInit.u32Pin      = GPIO_PIN_02;     /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcEtrGpioInit.u32Mode     = GPIO_MODE_INPUT; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcEtrGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOD_Init(&stcEtrGpioInit);
    GPIO_PD02_AF_CTIM1_ETR_SET();

    /* BTIM5_TOG(CTIM1_CH2)(PA09)BTIM5_TOGN(CTIM1_CH3)(PD10)端口初始化 */
    stcTogGpioInit.u32Pin         = GPIO_PIN_09 | GPIO_PIN_10; /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcTogGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP;       /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcTogGpioInit.u32DriverLevel = GPIO_Driver_Level_H;       /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcTogGpioInit.u32PullUpDn    = GPIO_PULL_NONE;            /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOA_Init(&stcTogGpioInit);
    GPIO_PA09_AF_CTIM1_CH2_SET();
    GPIO_PA10_AF_CTIM1_CH3_SET();
}

/**
 * @brief  初始化BTIMER5
 * @retval None.
 */
static void App_Btimer5_Init(void)
{
    stc_btim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim1_0_Btim345_1, TRUE); /* 配置BTIM3/4/5有效，GTIM1无效 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim1);        /* 使能BTIM3/4/5 外设时钟 */

    stcInitCfg.u32TaskMode        = BTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode        = BTIM_WORK_MODE_GATE;               /* 工作模式:门控模式，计数时钟为PCLK，ETR管脚输入信号作为门控 */
    stcInitCfg.u32Prescaler       = BTIM_COUNTER_CLK_DIV256;           /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn        = BTIM_TOGGLE_ENABLE;                /* TOG输出使能，TOGP和TOGN输出相位相反的信号 */
    stcInitCfg.u32TriggerSource   = BTIM_TRIGGER_SOURCE_ETR;           /* 触发源选择，使用外部ETR输入作为GATE门控 */
    stcInitCfg.u32ExInputPolarity = BTIM_ETR_POLARITY_INVERTED;        /* 外部输入极性选择，极性翻转，低电平有效 */
    stcInitCfg.u32AutoReloadVal   = (4000 - 1);                        /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Btim_Init(HC_BTIM5, &stcInitCfg);

    Btim_ClearFlag(HC_BTIM5, BTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Btim_EnableIT(HC_BTIM5, BTIM_IT_UI);      /* 允许BTIM5溢出中断 */
    EnableNvic(GTIM1_CH23_BTIMC_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
