/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of GTIM.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"
#include "flash.h"
#include "gpio.h"
#include "gtim.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_GTimer_Init(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* Gtimer0初始化 */
    App_GTimer_Init();

    /* 启动gtim运行 */
    Gtim_Enable(HC_GTIM0);

    while (1)
    {
        ;
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};
    stc_gpio_init_t stcChxGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOC外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOD外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);

    /* CTIM0_CH0(PA05)端口初始化,作为比较输出功能时候设置为输出 */
    stcChxGpioInit.u32Pin      = GPIO_PIN_05;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcChxGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcChxGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */
    GPIOA_Init(&stcChxGpioInit);

    GPIO_PA05_AF_CTIM0_CH0_SET();
}

/**
 * @brief  初始化GTIMER
 * @retval None.
 */
static void App_GTimer_Init(void)
{
    stc_gtim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1, FALSE); /*配置BTIM0/1/2有效，GTIM0无效*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);         /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode      = GTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode      = GTIM_WORK_MODE_PCLK;               /* 工作模式: 定时模式，计数时钟源来自PCLK */
    stcInitCfg.u32Prescaler     = GTIM_COUNTER_CLK_DIV1;             /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = GTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32AutoReloadVal = (40000 - 1);                       /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Gtim_Init(HC_GTIM0, &stcInitCfg);

    Gtim_SetCompareCaptureMode(HC_GTIM0, GTIM_COMPARE_CAPTURE_CH0, GTIM_COMPARE_CAPTURE_PWM_NORMAL); /* CHx PWM输出，CNT＞＝CCR输出高电平 */
    Gtim_SetCompareCaptureReg(HC_GTIM0, GTIM_COMPARE_CAPTURE_CH0, 20000);                            /* 比较值 20000 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
