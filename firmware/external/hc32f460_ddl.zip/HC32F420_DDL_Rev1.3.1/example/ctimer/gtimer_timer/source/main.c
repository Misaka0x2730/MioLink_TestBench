/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of GTIM.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "flash.h"
#include "gpio.h"
#include "gtim.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_GTimer0_Init(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* LPTimer0初始化 */
    App_GTimer0_Init();

    /* 启动gtim运行 */
    Gtim_Enable(HC_GTIM0);

    while (1)
    {
        ;
    }
}

/**
 * @brief  GTIMER中断服务函数
 * @retval None.
 */
void GTim0_Uev_Etr_BTimA_IRQHandler(void)
{
    static uint8_t i;

    if (TRUE == Gtim_IsActiveFlag(HC_GTIM0, GTIM_IT_FLAG_UI))
    {
        if (0 == i)
        {
            STK_LED_ON(); /* LED 引脚输出高电平 */
            i++;
        }
        else if (1 == i)
        {
            STK_LED_OFF(); /* LED 引脚输出低电平 */
            i = 0;
        }

        Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_UI); /* 清除GTIM0的溢出中断标志位   */
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);
}

/**
 * @brief  初始化GTIMER
 * @retval None.
 */
static void App_GTimer0_Init(void)
{
    stc_gtim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1, FALSE); /*配置BTIM0/1/2有效，GTIM0无效*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);         /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode      = GTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode      = GTIM_WORK_MODE_PCLK;               /* 工作模式: 定时器模式，计数时钟源来自PCLK */
    stcInitCfg.u32Prescaler     = GTIM_COUNTER_CLK_DIV256;           /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = GTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32AutoReloadVal = (4000 - 1);                        /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Gtim_Init(HC_GTIM0, &stcInitCfg);

    Gtim_DisableCompareCaptureAll(HC_GTIM0);

    Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Gtim_EnableIT(HC_GTIM0, GTIM_IT_UI);      /* 允许GTIM溢出中断    */
    EnableNvic(GTIM0_UEV_ETR_BTIMA_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
