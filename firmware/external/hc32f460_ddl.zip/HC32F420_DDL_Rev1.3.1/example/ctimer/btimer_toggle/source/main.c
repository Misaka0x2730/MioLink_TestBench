/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides firmware functions to manage the BTIM.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "btim.h"
#include "flash.h"
#include "gpio.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_BTimer1_Init(uint16_t u16Period);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* Btimer1初始化 */
    App_BTimer1_Init(4000U);

    /* 启动btim1运行 */
    Btim_Enable(HC_BTIM1);

    /* TOG输出使能 */
    Btim_EnableToggle(HC_BTIM1);

    while (1)
    {
        ;
    }
}

/**
 * @brief  BTIMER1中断服务函数
 * @retval None.
 */
void GTim0_Ch01_BTimB_IRQHandler(void)
{
    static uint8_t i;

    if (TRUE == Btim_IsActiveFlag(HC_BTIM1, BTIM_IT_FLAG_UI))
    {
        if (0 == i)
        {
            STK_LED_ON(); /* LED 引脚输出高电平*/
            i++;
        }
        else
        {
            STK_LED_OFF(); /* LED 引脚输出低电平*/
            i = 0;
        }

        Btim_ClearFlag(HC_BTIM1, BTIM_IT_CLR_UI); /* 清除BTIM1的溢出中断标志位  */
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};
    stc_gpio_init_t stcTogGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOa外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOb外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOc外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOd外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);

    /* BTIM1_TOG(CTIM0_CH0)(PA00)BTIM1_TOGN(CTIM0_CH1)(PA01)端口初始化 */
    stcTogGpioInit.u32Pin         = GPIO_PIN_00 | GPIO_PIN_01; /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcTogGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP;       /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcTogGpioInit.u32DriverLevel = GPIO_Driver_Level_H;       /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcTogGpioInit.u32PullUpDn    = GPIO_PULL_NONE;            /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOA_Init(&stcTogGpioInit);
    GPIO_PA00_AF_CTIM0_CH0_SET();
    GPIO_PA01_AF_CTIM0_CH1_SET();
}

/**
 * @brief  初始化BTIMER1
 * @retval None.
 */
static void App_BTimer1_Init(uint16_t u16Period)
{
    stc_btim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1, TRUE); /* 配置BTIM0/1/2有效，GTIM0无效 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);        /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode      = BTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode      = BTIM_WORK_MODE_PCLK;               /* 工作模式:定时器模式，计数时钟为PCLK */
    stcInitCfg.u32Prescaler     = BTIM_COUNTER_CLK_DIV256;           /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = BTIM_TOGGLE_ENABLE;                /* TOG输出使能，TOGP和TOGN输出相位相反的信号 */
    stcInitCfg.u32AutoReloadVal = (u16Period - 1);                   /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Btim_Init(HC_BTIM1, &stcInitCfg);

    Btim_ClearFlag(HC_BTIM1, BTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Btim_EnableIT(HC_BTIM1, BTIM_IT_UI);      /* 允许BTIM5溢出中断   */
    EnableNvic(GTIM0_CH01_BTIMB_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
