/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of gtimer.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"
#include "flash.h"
#include "gpio.h"
#include "gtim.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_GTimer1_Init(void);
static void App_GTimer2_Init(void);
/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* GTimer初始化 */
    App_GTimer1_Init();

    /* GTimer初始化 */
    App_GTimer2_Init();

    /* 启动Gtimer运行 */
    Gtim_Enable(HC_GTIM1);

    /* 启动Gtimer运行 */
    Gtim_Enable(HC_GTIM2);

    while (1)
    {
        ;
    }
}

/**
 * @brief  GTIMER中断服务函数
 * @retval None.
 */
void GTim1_Uev_Etr_BTimA_IRQHandler(void)
{
    if (TRUE == Gtim_IsActiveFlag(HC_GTIM1, GTIM_IT_FLAG_UI))
    {
        Gtim_ClearFlag(HC_GTIM1, GTIM_IT_CLR_UI); /* 清除GTIM的溢出中断标志位    */
    }
}

/**
 * @brief  GTIMER中断服务函数
 * @retval None.
 */
void GTim2_Uev_Etr_BTimA_IRQHandler(void)
{
    static uint8_t i;

    if (TRUE == Gtim_IsActiveFlag(HC_GTIM2, GTIM_IT_FLAG_UI))
    {
        if (0 == i)
        {
            STK_LED_ON(); /* LED 引脚输出高电平 */
            i++;
        }
        else if (1 == i)
        {
            STK_LED_OFF(); /* LED 引脚输出低电平 */
            i = 0;
        }

        Gtim_ClearFlag(HC_GTIM2, GTIM_IT_CLR_UI); /* 清除GTIM的溢出中断标志位    */
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);
}

/**
 * @brief  初始化GTIMER1
 * @retval None.
 */
static void App_GTimer1_Init(void)
{
    stc_gtim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim1_0_Btim345_1, FALSE); /*配置BTIM3/4/5有效，GTIM1无效*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim1);         /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode        = GTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode        = GTIM_WORK_MODE_PCLK;               /* 工作模式: 计数器模式，计数时钟源来自CR.TRS选择 */
    stcInitCfg.u32Prescaler       = GTIM_COUNTER_CLK_DIV1;             /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn        = GTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32TriggerSource   = GTIM_TRIGGER_SOURCE_ETR;           /* 触发源选择，使用外部ETR输入信号 */
    stcInitCfg.u32ExInputPolarity = GTIM_ETR_POLARITY_NORMAL;          /* 外部输入极性选择，极性不翻转 */
    stcInitCfg.u32AutoReloadVal   = (4000 - 1);                        /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Gtim_Init(HC_GTIM1, &stcInitCfg);

    Gtim_SetExInputFilter(HC_GTIM1, GTIM_ETR_FLT_PCLK_DIV1_CYCLE4);
    Gtim_DisableCompareCaptureAll(HC_GTIM1);

    Gtim_ClearFlag(HC_GTIM1, GTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Gtim_EnableIT(HC_GTIM1, GTIM_IT_UI);      /* 允许GTIM溢出中断  */
    EnableNvic(GTIM1_UEV_ETR_BTIMA_IRQn, IrqLevel3, TRUE);
}

/**
 * @brief  初始化GTIMER2
 * @retval None.
 */
static void App_GTimer2_Init(void)
{
    stc_gtim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim2_0_Btim678_1, FALSE); /*配置BTIM6/7/8有效，GTIM2无效*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim2);         /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode        = GTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 连续计数模式 */
    stcInitCfg.u32WorkMode        = GTIM_WORK_MODE_EXTERNAL;           /* 工作模式: 计数器模式，计数时钟源来自CR.TRS选择 */
    stcInitCfg.u32Prescaler       = GTIM_COUNTER_CLK_DIV1;             /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn        = GTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32TriggerSource   = GTIM_TRIGGER_SOURCE_ITR2;          /* 触发源选择，ITR2内部互联信号 */
    stcInitCfg.u32ExInputPolarity = GTIM_ETR_POLARITY_NORMAL;          /* 外部输入极性选择，极性不翻转 */
    stcInitCfg.u32AutoReloadVal   = (1000 - 1);                        /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Gtim_Init(HC_GTIM2, &stcInitCfg);

    Gtim_SetExInputFilter(HC_GTIM2, GTIM_ETR_FLT_PCLK_DIV4_CYCLE4);
    Gtim_DisableCompareCaptureAll(HC_GTIM2);

    Gtim_ClearFlag(HC_GTIM2, GTIM_IT_CLR_UI); /* 清除溢出中断标志位 */
    Gtim_EnableIT(HC_GTIM2, GTIM_IT_UI);      /* 允许GTIM溢出中断  */
    EnableNvic(GTIM2_UEV_ETR_BTIMA_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
