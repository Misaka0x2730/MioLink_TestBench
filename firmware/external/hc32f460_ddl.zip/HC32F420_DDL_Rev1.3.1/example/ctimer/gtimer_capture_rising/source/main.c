/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of GTIM.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"
#include "flash.h"
#include "gpio.h"
#include "gtim.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static uint32_t          u32CaptureVal_0;
static uint32_t          u32CaptureVal_1;
volatile static uint32_t u32CaptureVal_Result;
volatile static uint32_t u32CaptureVal_OldResult;

static uint32_t u32Uev_start_flag = 0;
static uint32_t u32Uev_counter    = 0;
uint32_t        u32Capture_result = 0;

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_GTimer_Init(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* Gtimer0初始化 */
    App_GTimer_Init();

    /* 启动gtim运行 */
    Gtim_Enable(HC_GTIM0);

    while (1)
    {
        ;
    }
}

/**
 * @brief  GTIMER中断服务函数
 * @retval None.
 */
void GTim0_Uev_Etr_BTimA_IRQHandler(void)
{
    if (TRUE == Gtim_IsActiveFlag(HC_GTIM0, GTIM_IT_FLAG_UI))
    {
        Gtim_ClearFlag(HC_GTIM0, GTIM_IT_FLAG_UI);
        if (u32Uev_start_flag)
        {
            u32Uev_counter++;
        }
    }
}
/**
 * @brief  GTIMER中断服务函数
 * @retval None.
 */
void GTim0_Ch01_BTimB_IRQHandler(void)
{
    static uint32_t index = 0;

    if (TRUE == Gtim_IsActiveFlag(HC_GTIM0, GTIM_IT_FLAG_CC0))
    {
        Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_CC0);

        if (index == 0)
        {
            u32CaptureVal_0   = Gtim_GetCompareCaptureReg(HC_GTIM0, GTIM_COMPARE_CAPTURE_CH0);
            u32Uev_start_flag = 1;
            index             = 1;
        }
        else
        {
            u32CaptureVal_1   = Gtim_GetCompareCaptureReg(HC_GTIM0, GTIM_COMPARE_CAPTURE_CH0);
            u32Capture_result = u32CaptureVal_1 + u32Uev_counter * 0xFFFF - u32CaptureVal_0;
            u32Uev_start_flag = 0;
            u32Uev_counter    = 0;
            index             = 0;
        }
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};
    stc_gpio_init_t stcChxGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOC外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOD外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);

    /* CTIM0_CH0(PA05)端口初始化,设为捕获功能输入 */
    stcChxGpioInit.u32Pin      = GPIO_PIN_05;     /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcChxGpioInit.u32Mode     = GPIO_MODE_INPUT; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcChxGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */
    GPIOA_Init(&stcChxGpioInit);

    GPIO_PA05_AF_CTIM0_CH0_SET();
}

/**
 * @brief  初始化GTIMER
 * @retval None.
 */
static void App_GTimer_Init(void)
{
    stc_gtim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1, FALSE); /*配置BTIM0/1/2无效，GTIM0有效*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);         /* 使能BTIM0/0/2 外设时钟 */

    stcInitCfg.u32TaskMode      = GTIM_TASK_MODE_CONTINUOUS_COUNTER; /* 计数模式：连续计数 */
    stcInitCfg.u32WorkMode      = GTIM_WORK_MODE_PCLK;               /* 工作模式: 定时器模式，计数时钟源来自PCLK */
    stcInitCfg.u32Prescaler     = GTIM_COUNTER_CLK_DIV1;             /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = GTIM_TOGGLE_DISABLE;               /* TOG输出禁止 */
    stcInitCfg.u32AutoReloadVal = 0xFFFF;                            /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Gtim_Init(HC_GTIM0, &stcInitCfg);

    Gtim_SetCompareCaptureMode(HC_GTIM0, GTIM_COMPARE_CAPTURE_CH0, GTIM_COMPARE_CAPTURE_RISING);

    Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_UI | GTIM_IT_CLR_CC0); /* 清除溢出中断和捕获比较0中断标志位 */
    Gtim_EnableIT(HC_GTIM0, GTIM_IT_UI | GTIM_IT_CC0);          /* 允许GTIM溢出中断 */

    EnableNvic(GTIM0_CH01_BTIMB_IRQn, IrqLevel3, TRUE);
    EnableNvic(GTIM0_UEV_ETR_BTIMA_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
