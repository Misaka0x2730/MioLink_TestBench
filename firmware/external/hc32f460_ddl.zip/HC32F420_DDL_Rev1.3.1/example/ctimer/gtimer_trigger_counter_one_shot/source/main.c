/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of GTIM.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"
#include "flash.h"
#include "gpio.h"
#include "gtim.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_GPIO_Init(void);
static void App_GTimer_Init(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */

int32_t main(void)
{
    /* GPIO初始化 */
    App_GPIO_Init();

    /* GTimer0初始化 */
    App_GTimer_Init();

    /* ETR 输入一次下降沿，启动gtim运行一次，溢出后停止 */

    while (1) {}
}

/**
 * @brief  GTIMER中断服务函数
 * @retval None.
 */
void GTim0_Uev_Etr_BTimA_IRQHandler(void)
{
    if (TRUE == Gtim_IsActiveFlag(HC_GTIM0, GTIM_IT_FLAG_TI))
    {
        STK_LED_ON(); /* LED 引脚输出高电平 */
        delay1ms(500);
        STK_LED_OFF(); /* LED 引脚输出低电平 */

        Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_TI); /* 清除GTIM0的触发中断标志位   */
    }

    if (TRUE == Gtim_IsActiveFlag(HC_GTIM0, GTIM_IT_FLAG_UI))
    {
        STK_LED_ON(); /* LED 引脚输出高电平 */
        delay1ms(200);
        STK_LED_OFF(); /* LED 引脚输出低电平 */

        Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_UI); /* 清除GTIM0的溢出中断标志位   */
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t stcLEDGpioInit = {0};
    stc_gpio_init_t stcETRGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOC外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOD外设时钟使能 */

    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin         = STK_LED_PIN;         /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOB_Init(&stcLEDGpioInit);

    /* ETR端口初始化 */
    stcETRGpioInit.u32Pin      = GPIO_PIN_00;     /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcETRGpioInit.u32Mode     = GPIO_MODE_INPUT; /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcETRGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */

    GPIOA_Init(&stcETRGpioInit);
    GPIO_PA00_AF_CTIM0_ETR_SET();
}

/**
 * @brief  初始化GTIMER
 * @retval None.
 */
static void App_GTimer_Init(void)
{
    stc_gtim_init_t stcInitCfg = {0};

    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1, FALSE); /*配置BTIM0/1/2有效，GTIM0无效*/
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);         /* 使能BTIM0/0/2 外设时钟 */

    /* 先设置ETR输入滤波 */
    Gtim_SetExInputFilter(HC_GTIM0, GTIM_ETR_FLT_PCLK_DIV4_CYCLE4);

    stcInitCfg.u32TaskMode        = GTIM_TASK_MODE_ONESHOT_COUNTER; /* 单次计数模式 */
    stcInitCfg.u32WorkMode        = GTIM_WORK_MODE_TRIGGER;         /* 工作模式: 触发启动模式，计数时钟为PCLK，TRS信号触发计数器启动 */
    stcInitCfg.u32Prescaler       = GTIM_COUNTER_CLK_DIV32768;      /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn        = GTIM_TOGGLE_DISABLE;            /* TOG输出禁止 */
    stcInitCfg.u32TriggerSource   = GTIM_TRIGGER_SOURCE_ETR;        /* 触发源选择，使用外部ETR输入作为触发信号 */
    stcInitCfg.u32ExInputPolarity = GTIM_ETR_POLARITY_INVERTED;     /* 外部输入极性选择，极性翻转,低有效 */
    stcInitCfg.u32AutoReloadVal   = (1220 - 1);                     /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Gtim_Init(HC_GTIM0, &stcInitCfg);

    Gtim_ClearFlag(HC_GTIM0, GTIM_IT_CLR_UI | GTIM_IT_CLR_TI); /* 清除溢出中断标志位和触发中断标志位 */
    Gtim_EnableIT(HC_GTIM0, GTIM_IT_UI | GTIM_IT_TI);          /* 允许GTIM溢出中断\触发中断 */
    EnableNvic(GTIM0_UEV_ETR_BTIMA_IRQn, IrqLevel3, TRUE);
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
