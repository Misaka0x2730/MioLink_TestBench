/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides firmware functions to manage the BTIM.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "btim.h"
#include "gpio.h"
#include "flash.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_ClkCfg(void);
static void App_GPIO_Init(void);
static void App_Btimer0_Init(void);
static void App_Btimer1_Init(void);

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of project
 * @retval uint32_t: return value, if needed
 */
 
int32_t main(void)
{  
    /* 系统时钟初始化：12MHZ */
    App_ClkCfg();   
    
    /* 端口初始化 */   
    App_GPIO_Init();
    
    /* Btimer0初始化 */  
    App_Btimer0_Init();
    
    /* Btimer1初始化 */ 
    App_Btimer1_Init(); 
    
    /* 启动Btim1运行 */ 
    Btim_Enable(HC_BTIM1);  
    
    /* 启动Btim0运行 */
    Btim_Enable(HC_BTIM0);      
    
    while (1)
    {
        ;
    }
}

/**
 * @brief  系统时钟模块配置
 * @retval None
 */
static void App_ClkCfg(void)
{   
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t stcSysClk = {0};

    /* 系统时钟源初始化 */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH |\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_RCL |\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_XTH |\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;
    
    stcSysClkSrc.u32RCHState         = SYSCTRL_RCH_TRIM_24MHz|\
                                       SYSCTRL_RCH_DIV2;
    
    stcSysClkSrc.u32RCLState         = SYSCTRL_RCL_TRIM_32p8KHz |\
                                       SYSCTRL_RCL_WAITCYCLE256;
    
    stcSysClkSrc.u32XTHState         = SYSCTRL_XTH_DRV2 |\
                                       SYSCTRL_XTH_8t16MHz |\
                                       SYSCTRL_XTH_WAITCYCLE3;
    
    stcSysClkSrc.u32PLLState         = SYSCTRL_PLL_MULM_CONFIG(14) |\
                                       SYSCTRL_PLL_DIVN_CONFIG(1) |\
                                       SYSCTRL_PLL_OEN_ON|\
                                       SYSCTRL_PLL_WAITCYCLE_CONFIG(7) |\
                                       SYSCTRL_PLL_OD_CONFIG(1) |\
                                       SYSCTRL_PLL_SRC_RCH;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}
  

    /* 系统时钟初始化 */     
    stcSysClk.u32ClockType          = SYSCTRL_CLOCKTYPE_SYSCLK |\
                                      SYSCTRL_CLOCKTYPE_HCLK   |\
                                      SYSCTRL_CLOCKTYPE_PCLK0  |\
                                      SYSCTRL_CLOCKTYPE_PCLK1;
                                    
    stcSysClk.u32SysClkSource       = SYSCTRL_SYSCLK_SOURCE_RCH;
    stcSysClk.u32HClkDiv            = SYSCTRL_SYSCLK_HCLK_PRS1;
    stcSysClk.u32PClk0Div           = SYSCTRL_SYSCLK_PCLK0_PRS1;
    stcSysClk.u32PClk1Div           = SYSCTRL_SYSCLK_PCLK1_PRS1;
    stcSysClk.u32WaitCycle          = SYSCTRL_FLASH_WAIT_CYCLE1;

    SYSCTRL_SysClkInit(&stcSysClk);
}


/**
 * @brief  BTIMER1中断服务函数
 * @retval None.
 */
void GTim0_Ch01_BTimB_IRQHandler(void)
{
    static uint8_t i = 0;
    
    if (TRUE == Btim_IsActiveFlag(HC_BTIM1, BTIM_IT_FLAG_UI))
    {
        if(0 == i)
        {
            STK_LED_ON();  /* LED 引脚输出高电平*/   
            i++;
        }
        else if(1 == i)
        {
            STK_LED_OFF();  /* LED 引脚输出低电平*/    
            i = 0;
        }
        
        Btim_ClearFlag(HC_BTIM1, BTIM_IT_FLAG_UI); /*清除BTIM1的溢出中断标志位  */  
    }
}

/**
 * @brief  端口配置初始化
 * @retval None.
 */
static void App_GPIO_Init(void)
{
    stc_gpio_init_t  stcLEDGpioInit = {0};
    
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    
    /* LED(PB12)端口初始化 */
    stcLEDGpioInit.u32Pin = STK_LED_PIN;                    /* GPIO PIN脚选择      @ref GPIO_PINs_Define    */
    stcLEDGpioInit.u32Mode = GPIO_MODE_OUTPUT_PP;           /* GPIO 模式选择       @ref GPIO_Mode_Define    */
    stcLEDGpioInit.u32DriverLevel = GPIO_Driver_Level_H;    /* GPIO 驱动能力       @ref GPIO_Driver_Define  */
    stcLEDGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* GPIO 上下拉配置     @ref GPIO_Pull_Define    */
    
    GPIOB_Init(&stcLEDGpioInit); 
}

/**
 * @brief  初始化BTIMER0
 * @retval None.
 */
static void App_Btimer0_Init(void)
{
    stc_btim_init_t    stcInitCfg = {0};    
    
    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1,TRUE);              /* 配置BTIM0/1/2有效，GTIM0无效 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);                    /* 使能BTIM0/0/2 外设时钟 */
    
    stcInitCfg.u32TaskMode      = BTIM_TASK_MODE_CONTINUOUS_COUNTER;    /* 连续计数模式 */
    stcInitCfg.u32WorkMode      = BTIM_WORK_MODE_PCLK;                  /* 工作模式:定时器模式，计数时钟源来自PCLK */
    stcInitCfg.u32Prescaler     = BTIM_COUNTER_CLK_DIV1;                /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn      = BTIM_TOGGLE_DISABLE;                  /* TOG输出禁止 */
    stcInitCfg.u32AutoReloadVal = 0xFFFF;                               /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Btim_Init(HC_BTIM0, &stcInitCfg);
}

/**
 * @brief  初始化BTIMER1
 * @retval None.
 */
static void App_Btimer1_Init(void)
{
    stc_btim_init_t    stcInitCfg = {0}; 
    
    SYSCTRL_Func_Ctrl(Sysctrl_Fun_Gtim0_0_Btim012_1,TRUE);              /* 配置BTIM0/1/2有效，GTIM0无效 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCTim0);                    /* 使能BTIM0/0/2 外设时钟 */
                                                                        
    stcInitCfg.u32TaskMode        = BTIM_TASK_MODE_CONTINUOUS_COUNTER;  /* 连续计数模式 */
    stcInitCfg.u32WorkMode        = BTIM_WORK_MODE_EXTERNAL;            /* 工作模式: 计数器模式，计数时钟源来自CR.TRS选择 */
    stcInitCfg.u32Prescaler       = BTIM_COUNTER_CLK_DIV1;              /* 对计数时钟进行预除频 */
    stcInitCfg.u32ToggleEn        = BTIM_TOGGLE_DISABLE;                /* TOG输出禁止 */
    stcInitCfg.u32TriggerSource   = BTIM_TRIGGER_SOURCE_ITR;            /* 触发源选择，上一级BTIM的ITR输出(溢出) */
    stcInitCfg.u32ExInputPolarity = BTIM_ETR_POLARITY_NORMAL;           /* 外部输入极性选择，极性不翻转*/
    stcInitCfg.u32AutoReloadVal   = (100-1);                             /* 自动重载寄存ARR赋值,计数周期为PRS*(ARR+1)*TPCLK */
    Btim_Init(HC_BTIM1, &stcInitCfg);
    
    Btim_ClearFlag(HC_BTIM1,BTIM_IT_CLR_UI);                            /* 清除溢出中断标志位 */
    Btim_EnableIT(HC_BTIM1, BTIM_IT_UI);                                /* 允许BTIM1溢出中断 */
    EnableNvic(GTIM0_CH01_BTIMB_IRQn, IrqLevel3, TRUE); 
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
