/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "atim3.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"
#include "dmac.h"

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static uint16_t aDstBuffer[3U];

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Timer3_Port_Cfg(void);
static void App_Timer3_Cfg(uint16_t u16Period, uint16_t u16CHxACompare, uint16_t u16CHxBCompare);
static void App_Adc_Cfg(void);
static void App_DMA_Cfg(en_dma_channel_t channel_id);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Clock_Cfg(); /* 时钟初始化 */

    App_DMA_Cfg(DMA_CHANNEL0); /* DMA0通道配置 */
        
    App_Timer3_Cfg(0x12C0, 0x900, 0); /* Atimer3 配置:周期 0x12C0(clk 48M, f = 5K);        */
                                      /* CH0/1/0x900; CH0/1/2通道B比较值互补模式不需要设置 */

    App_Timer3_Port_Cfg(); /* Atimer3 Port端口配置 */

    App_Adc_Cfg(); /* ADC ADC顺序扫描功能配置 */

    ADC_Enable_EOC_DMATransfer(HC_ADC0); /* 开启ADC_EOC_DMA功能 */

    ATIM3_Mode23_Run(); /* 运行 */

    /* 可添加其他其他操作，待准备好后使能PWM输出 */

    ATIM3_Mode23_Manual_PWM_Output_Enable(TRUE); /* 端口输出使能 */

    while (1)
    {
        ;
    }
}

/**
 * @brief  ATIM3_UEV 中断函数
 * @retval None
 */
void ATim3_Uev_IRQHandler(void)
{
    static uint8_t i;

    /* Atimer3 模式23 更新中断 */
    if (0 == i)
    {
        STK_LED_ON(); /* LED 引脚输出高电平 */
        i++;
    }
    else if (1 == i)
    {
        STK_LED_OFF(); /* LED 引脚输出低电平 */
        i = 0;
    }
    ATIM3_ClearIrqFlag(ATIM3_INT_CLR_UI); /* 清中断标志 */     
}

/**
 * @brief  ADC 中断函数
 * @retval None
 */
void Adc_IRQHandler(void)
{
    static uint8_t i;

    /* ADC 顺序扫描EOS中断 */
    if (TRUE == ADC_IsActiveFlag(HC_ADC0, ADC_FLAG_EOS)) /* 判断是否产生EOS标志 */
    {
        if (0 == i)
        {
            ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH0A, 0xA00); /* 设置CH0 通道A比较值 */
            ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH1A, 0xA00); /* 设置CH1 通道A比较值 */
            ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH2A, 0xA00); /* 设置CH2 通道A比较值 */
            i++;
        }
        else if (1 == i)
        {
            ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH0A, 0x600); /* 设置CH0 通道A比较值 */
            ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH1A, 0x600); /* 设置CH1 通道A比较值 */
            ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH2A, 0x600); /* 设置CH2 通道A比较值 */
            i = 0;
        }

        ADC_ClearFlag(HC_ADC0, ADC_CLEAR_EOS); /* 清中断标志 */
    }
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON
                               | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0
                             | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  DMAC CHx 配置
 * @retval None
 */
static void App_DMA_Cfg(en_dma_channel_t channel_id)
{
    stc_dmac_channel_init_t stcDmacChInit = {0};
    
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralDma); 
    
    stcDmacChInit.u32Priority      = DMA_FIX_PRIORITY,             
    stcDmacChInit.u32TrigSrc       = DMA_TRISRC_ADC0_SINGLE_EOC,   
    stcDmacChInit.u32BlockCnt      = 1U,                            
    stcDmacChInit.u32TransferCnt   = 3U,                            
    stcDmacChInit.u32TransferMode  = DMA_BLOCK_MODE,               
    stcDmacChInit.u32DataSize      = DMA_DATA_HALFWORD,            
    stcDmacChInit.u32SrcAddrFix    = DMA_SRCADDR_FIX,              
    stcDmacChInit.u32DstAddrFix    = DMA_DSTADDR_INC,              
    stcDmacChInit.u32BTCntReload   = DMA_BTCNT_RELOAD_ENABLE,      
    stcDmacChInit.u32SrcAddrReload = DMA_SRCADDR_RELOAD_ENABLE,    
    stcDmacChInit.u32DstAddrReload = DMA_DSTADDR_RELOAD_ENABLE,    
    stcDmacChInit.u32SrcAddr       = (uint32_t)(&(HC_ADC0->RESULT)),
    stcDmacChInit.u32DstAddr       = (uint32_t)aDstBuffer,         
    stcDmacChInit.u32ChanelEnMsk   = DMA_KEEP_ENABLE,                                                                                                              
       
    DMACCH_Init(HC_DMAC, channel_id, &stcDmacChInit);       
    DMACCH_Enable(HC_DMAC, DMA_CHANNEL0);                  
    DMAC_Enable();         
}

/**
 * @brief  ATIM3 CHx 端口配置
 * @retval None
 */
void App_Timer3_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioc); /* GPIOC外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiod); /* GPIOD外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /*PD03设置为ATIM3_BK, 作为刹车输入端口 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_03;     /* 端口引脚->P03            */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    GPIOD_Init(&stcGpioInit);                  /* 端口初始化               */
    GPIO_PD03_AF_ATIM3_BK_SET();               /* PD03复用为ATIM3_BK       */

    /* PA04(ATIM3_CH0A), PA05(ATIM3_CH1A), PA06(ATIM3_CH2A), PA07(ATIM3_CH0B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                                               /* 结构体初始化清零 */
    GPIO_PA04_RESET();                                                          /* 端口初始电平->低 */
    GPIO_PA05_RESET();                                                          /* 端口初始电平->低 */
    GPIO_PA06_RESET();                                                          /* 端口初始电平->低 */
    GPIO_PA07_RESET();                                                          /* 端口初始电平->低 */
    stcGpioInit.u32Pin = GPIO_PIN_04 | GPIO_PIN_05 | GPIO_PIN_06 | GPIO_PIN_07; /* 端口引脚->P04, P05, P06, P07 */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                      /* 端口初始化               */
    GPIO_PA04_AF_ATIM3_CH0A_SET();                 /* PA04复用为ATIM3_CH0A     */
    GPIO_PA05_AF_ATIM3_CH1A_SET();                 /* PA05复用为ATIM3_CH1A     */
    GPIO_PA06_AF_ATIM3_CH2A_SET();                 /* PA06复用为ATIM3_CH2A     */
    GPIO_PA07_AF_ATIM3_CH0B_SET();                 /* PA07复用为ATIM3_CH0B     */

    /* PC04(ATIM3_CH1B), PC05(ATIM3_CH2B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零         */
    GPIO_PC04_RESET();                                   /* 端口初始电平->低         */
    GPIO_PC05_RESET();                                   /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_04 | GPIO_PIN_05; /* 端口引脚->P04, P05       */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;       /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉 */
    GPIOC_Init(&stcGpioInit);                            /* 端口初始化               */
    GPIO_PC04_AF_ATIM3_CH1B_SET();                       /* PC04复用为ATIM3_CH1B     */
    GPIO_PC05_AF_ATIM3_CH2B_SET();                       /* PC05复用为ATIM3_CH2B     */
}

/**
 * @brief  ATIM3 配置
 * @param  [in] u16Period:        周期
 * @param  [in] u16CHxACompare:   CHA比较值
 * @param  [in] u16CHxBCompare:   CHB比较值
 * @retval None
 */
void App_Timer3_Cfg(uint16_t u16Period, uint16_t u16CHxACompare, uint16_t u16CHxBCompare)
{
    uint16_t                     u16CntValue;
    stc_atim3_mode23_cfg_t       stcAtim3BaseCfg     = {0};
    stc_atim3_m23_compare_cfg_t  stcAtim3ChxACmpCfg  = {0};
    stc_atim3_m23_compare_cfg_t  stcAtim3ChxBCmpCfg  = {0};
    stc_atim3_m23_dt_cfg_t       stcAtim3DeadTimeCfg = {0};
    stc_atim3_m23_rcr_cfg_t      stcRcrCfg           = {0};
    stc_atim3_m23_adc_trig_cfg_t stcAtimTrigAdc      = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim3); /* ATIM3 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim3BaseCfg);                                      /* 结构体初始化清零 */
    stcAtim3BaseCfg.u32WorkMode    = ATIM3_M23_M23CR_WORK_MODE_TRIANGULAR; /* 三角波模式 */
    stcAtim3BaseCfg.u32CountClkSel = ATIM3_M23_M23CR_CT_PCLK;       /* 定时器功能，计数时钟为内部PCLK */
    stcAtim3BaseCfg.u32PRS         = ATIM3_M23_M23CR_ATIM3CLK_PRS1; /*  PCLK */
    stcAtim3BaseCfg.u32PWMTypeSel = ATIM3_M23_M23CR_COMP_PWM_COMP;              /* 互补输出PWM */
    stcAtim3BaseCfg.u32PWM2sSel   = ATIM3_M23_M23CR_PWM2S_COMPARE_SINGLE_POINT; /* 单点比较功能 */
    stcAtim3BaseCfg.u32ShotMode   = ATIM3_M23_M23CR_SHOT_CYCLE;                 /* 循环计数 */
    stcAtim3BaseCfg.u32URSSel     = ATIM3_M23_M23CR_URS_OV_UND;                 /* 上下溢更新 */
    ATIM3_Mode23_Init(&stcAtim3BaseCfg); /*  ATIM3 的模式23功能初始化 */

    /*  48M, f = 10K */
    ATIM3_Mode23_ARRSet(u16Period); /* 设置重载值,并使能缓存 */
    ATIM3_Mode23_ARR_Buffer_Enable(TRUE);

    ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH0A, u16CHxACompare); /* 设置CH0比较值A */
    ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH1A, u16CHxACompare); /* 设置CH1比较值A */
    ATIM3_Mode23_Channel_Compare_Value_Set(ATIM3_COMPARE_CAPTURE_CH2A, u16CHxACompare); /* 设置CH2比较值A */

    DDL_ZERO_STRUCT(stcAtim3ChxACmpCfg); /* 结构体初始化清零 */
    stcAtim3ChxACmpCfg.u32CHxCmpCap      = ATIM3_M23_CRCHx_CSA_CSB_COMPARE;
    stcAtim3ChxACmpCfg.u32CHxCmpModeCtrl = ATIM3_M23_FLTR_OCMxx_PWM_MODE_2;    /* OCREFA输出控制OCMA:PWM模式2 */
    stcAtim3ChxACmpCfg.u32CHxPolarity    = ATIM3_M23_FLTR_CCPxx_NORMAL_IN_OUT; /* 正常输出 */
    stcAtim3ChxACmpCfg.u32CHxCmpBufEn    = ATIM3_M23_CRCHx_BUFEx_ENABLE;       /* A通道缓存控制 */
    stcAtim3ChxACmpCfg.u32CHxCmpIntSel   = ATIM3_M23_M23CR_CISA_DISABLE_IRQ;   /* A通道比较控制:无 */
    ATIM3_Mode23_PortOutput_CHxA_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH0, &stcAtim3ChxACmpCfg); /* 比较输出端口配置 */
    ATIM3_Mode23_PortOutput_CHxA_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH1, &stcAtim3ChxACmpCfg); /* 比较输出端口配置 */
    ATIM3_Mode23_PortOutput_CHxA_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH2, &stcAtim3ChxACmpCfg); /* 比较输出端口配置 */

    DDL_ZERO_STRUCT(stcAtim3ChxBCmpCfg); /* 结构体初始化清零 */
    stcAtim3ChxBCmpCfg.u32CHxCmpCap = ATIM3_M23_CRCHx_CSA_CSB_COMPARE;
    stcAtim3ChxBCmpCfg.u32CHxCmpModeCtrl =
        ATIM3_M23_FLTR_OCMxx_PWM_MODE_2; /* OCREFB输出控制OCMB:PWM模式2(PWM互补模式下也要设置，避免强制输出) */
    stcAtim3ChxBCmpCfg.u32CHxPolarity = ATIM3_M23_FLTR_CCPxx_NORMAL_IN_OUT; /* 正常输出 */
    stcAtim3ChxBCmpCfg.u32CHxCmpIntSel = ATIM3_M23_CRCHx_CISBx_DISABLE_IRQ;              /* B通道比较控制:无 */
    ATIM3_Mode23_PortOutput_CHxB_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH0, &stcAtim3ChxBCmpCfg); /* 比较输出端口配置 */
    ATIM3_Mode23_PortOutput_CHxB_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH1, &stcAtim3ChxBCmpCfg); /* 比较输出端口配置 */
    ATIM3_Mode23_PortOutput_CHxB_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH2, &stcAtim3ChxBCmpCfg); /* 比较输出端口配置 */

    DDL_ZERO_STRUCT(stcAtimTrigAdc);           /* 结构体初始化清零 */
    stcAtimTrigAdc.bEnTrigADC    = TRUE;       /* 使能ADC触发全局控制 */
    stcAtimTrigAdc.bEnUevTrigADC = TRUE;       /* Uev更新触发ADC */
    ATIM3_Mode23_TrigADC_Cfg(&stcAtimTrigAdc); /* 触发ADC配置 */

    DDL_ZERO_STRUCT(stcAtim3DeadTimeCfg); /* 结构体初始化清零 */
    stcAtim3DeadTimeCfg.bEnDeadTime      = TRUE;
    stcAtim3DeadTimeCfg.u32DeadTimeValue = 0xFF;
    ATIM3_Mode23_DT_Cfg(&stcAtim3DeadTimeCfg); /* 死区设置 */

    DDL_ZERO_STRUCT(stcRcrCfg);                                          /* 结构体初始化清零 */
    stcRcrCfg.u32EnOverFLowMask  = ATIM3_M23_RCR_OVF_IRQ_EVT_CNT_MASK;   /* 屏蔽上溢重复计数 */
    stcRcrCfg.u32EnUnderFlowMask = ATIM3_M23_RCR_UND_IRQ_EVT_CNT_ENABLE; /* 使能下溢重复计数 */
    stcRcrCfg.u32RepeatCountNum  = 0;
    ATIM3_Mode23_SetRepeatPeriod(&stcRcrCfg); /* 间隔周期设置 */

    u16CntValue = 0;
    ATIM3_Mode23_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM3_ClearAllIrqFlag();                     /* 清中断标志 */
    ATIM3_Mode23_EnableIrq(ATIM3_M23_INT_UI);    /* 使能ATIM3 UEV更新中断 */
    EnableNvic(ATIM3_UEV_IRQn, IrqLevel3, TRUE); /* ATIM3_UEV 开中断 */
}

/**
 * @brief  ADC 顺序扫描配置
 * @retval None
 */
static void App_Adc_Cfg(void)
{
    stc_adc_cfg_t     stcAdcCfg    = {0};

    /* 端口配置 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* 开启GPIO外设时钟 */
    GPIO_PA00_ANALOG_SET();
    GPIO_PA01_ANALOG_SET();
    GPIO_PA02_ANALOG_SET();

    /* ADC配置 */
    /* 开启BGR，模拟模块，必须开启BGR */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0); /* 开启adc0外设时钟 */
    ADC_BGR_Enable(HC_ADC0);
    ADC_Enable(HC_ADC0);
    delay10us(2);

    /* ADC 初始化配置 */
    DDL_ZERO_STRUCT(stcAdcCfg);                                 /* 结构体初始化清零 */
    stcAdcCfg.AdcSampCycleSel = ADC_SAMPLINGTIME_10CYCLE;       /* ADC采样周期选择 */
    stcAdcCfg.AdcOpBuf        = ADC_BUFF_DISABLE;               /* ADC输入信号放大器控制使能 */
    stcAdcCfg.AdcRefVolSel    = ADC_REF_VOLTAGE_AVCC;           /* ADC参考电压选择 */
    stcAdcCfg.AdcClkDiv       = ADC_CLOCK_PCLK_DIV16;           /* ADC时钟选择 */
    stcAdcCfg.RaccEn          = ADC_RACCCLR_DISABLE;            /* ADC转换结果自动累加功能 */
    stcAdcCfg.OvMode          = ADC_OVMD_ENABLE;                /* ADC过转换时Adc_Result存储方式 */
    stcAdcCfg.AdcAlign        = ADC_RIGHT_ALIGN_ENABLE;         /* ADC转换结果对齐控制 */
    stcAdcCfg.AdcMode         = ADC_CONVERSION_MODE_SQR_SINGLE; /* ADC转换模式 */

    ADC_Init(HC_ADC0, &stcAdcCfg); /* 初始化配置 */

    /* 配置通道和通道输入源 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH0MUX, ADC_Channel_Mux0_PA00);    /* 配置通道0的输入源来自PA00 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH1MUX, ADC_Channel_Mux1_PA01);    /* 配置通道1的输入源来自PA01 */
    ADC_SetChannelInputSource(HC_ADC0, ADC_SQRCH2MUX, ADC_Channel_Mux2_PA02);    /* 配置通道2的输入源来自PA02 */    
    
    /* 配置为3次 */
    ADC_Set_SQR_ChCnt(HC_ADC0, (3U - 1U)); 
          
    /* 配置外部触发源 */
    ADC_SetExtTrigger0Source(HC_ADC0, ADCMSKTRIGATIMER3);

    /* ADC 中断使能 */
    ADC_ClearFlag_ALL(HC_ADC0); /* 清除所有中断标志位 */
    ADC_EnableIT(HC_ADC0, ADC_IT_EOS);
    EnableNvic(ADC0_ADC1_IRQn, IrqLevel3, TRUE);
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
