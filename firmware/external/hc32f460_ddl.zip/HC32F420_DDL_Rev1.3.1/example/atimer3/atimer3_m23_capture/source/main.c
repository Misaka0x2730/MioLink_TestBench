/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim3.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static uint32_t          Atim3_Capture_Value1, Atim3_Capure_Value2;
static volatile int32_t  Atim3_Capture_Value;
static volatile uint16_t Atim3_Uev_Cnt;

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Clock_Cfg(void);
static void App_Atimer3_Port_Cfg(void);
static void App_Timer3_Cfg(void);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Clock_Cfg(); /* 时钟初始化 */

    App_Atimer3_Port_Cfg(); /* Atimer3 Port端口配置 */

    App_Timer3_Cfg(); /* Atimer3 配置 */

    ATIM3_Mode23_Run(); /* 运行 */

    while (1) {}
}

/**
 * @brief  ATim3_ChYA 中断函数
 * @retval None
 */
void ATim3_ChYA_IRQHandler(void)
{
    static uint8_t i;

    /* Timer3 捕获中断A */
    if (0 == i)
    {
        Atim3_Capture_Value1 = ATIM3_Mode23_Channel_Capture_Value_Get(ATIM3_COMPARE_CAPTURE_CH0A); /* 第一次读取捕获值 */
        Atim3_Uev_Cnt        = 0;
        i++;
    }
    else
    {
        Atim3_Capure_Value2 = ATIM3_Mode23_Channel_Capture_Value_Get(ATIM3_COMPARE_CAPTURE_CH0A);  /* 第二次读取捕获值 */
        Atim3_Capture_Value = Atim3_Uev_Cnt * 0xFFFF + Atim3_Capure_Value2 - Atim3_Capture_Value1; /* 两次捕获之间的差值 */

        Atim3_Uev_Cnt = 0;

        i = 0;
    }

    ATIM3_ClearIrqFlag(ATIM3_INT_CLR_PWC_CA0); /* 清中断标志 */
}

/**
 * @brief  ATIM3_UEV 中断函数
 * @retval None
 */
void ATim3_Uev_IRQHandler(void)
{
    /* timer3计数溢出中断 */
    Atim3_Uev_Cnt++;
    ATIM3_ClearIrqFlag(ATIM3_INT_CLR_UI);
}

/**
 * @brief  时钟初始化
 * @retval None
 */
void App_Clock_Cfg(void)
{
    stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
    stc_sysctrl_clk_init_t           stcSysClk    = {0};

    /* 系统时钟源初始化 */
    /* FOUT = FIN * MULM / DIVN / OD = 4 * 48 / 1 / 2^2 = 48MHz */
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;

    stcSysClkSrc.u32PLLState = SYSCTRL_PLL_MULM_CONFIG(48) | SYSCTRL_PLL_DIVN_CONFIG(1) | SYSCTRL_PLL_OEN_ON 
                               | SYSCTRL_PLL_WAITCYCLE_CONFIG(7) | SYSCTRL_PLL_OD_CONFIG(2) | SYSCTRL_PLL_SRC_RCH;

    while (Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)) /* 时钟源初始化 */
    {
        ;
    }

    /* 系统时钟初始化 */
    stcSysClk.u32ClockType = SYSCTRL_CLOCKTYPE_SYSCLK | SYSCTRL_CLOCKTYPE_HCLK | SYSCTRL_CLOCKTYPE_PCLK0 
                             | SYSCTRL_CLOCKTYPE_PCLK1; /* 时钟初始化需要操作PLL，HCLK和PCLK */

    stcSysClk.u32SysClkSource = SYSCTRL_SYSCLK_SOURCE_PLL; /* PLL为系统时钟 */
    stcSysClk.u32HClkDiv      = SYSCTRL_SYSCLK_HCLK_PRS1;  /* HCLK不分频 */
    stcSysClk.u32PClk0Div     = SYSCTRL_SYSCLK_PCLK0_PRS1; /* PCLK0不分频 */
    stcSysClk.u32PClk1Div     = SYSCTRL_SYSCLK_PCLK1_PRS1; /* PCLK1不分频 */
    stcSysClk.u32WaitCycle    = SYSCTRL_FLASH_WAIT_CYCLE2; /* 设置flash 读等待为2个周期 */

    SYSCTRL_SysClkInit(&stcSysClk); /* 时钟初始化 */
}

/**
 * @brief  ATIM3 CHx 端口配置
 * @retval None
 */
void App_Atimer3_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */

    /* PA04(ATIM3_CH0A) 端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                  /* 结构体初始化清零         */
    GPIO_PA04_RESET();                             /* 端口初始电平->低         */
    stcGpioInit.u32Pin      = GPIO_PIN_04;         /* 端口引脚->P04            */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出   */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉 */
    GPIOA_Init(&stcGpioInit);                      /* 端口初始化               */
    GPIO_PA04_AF_ATIM3_CH0A_SET();                 /* PA04复用为ATIM3_CH0A     */
}

/**
 * @brief  ATIM3 配置
 * @retval None
 */
void App_Timer3_Cfg(void)
{
    uint16_t                  u16ArrValue;
    uint16_t                  u16CntValue;
    stc_atim3_mode23_cfg_t    stcAtim3BaseCfg    = {0};
    stc_atim3_m23_input_cfg_t stcAtim3ChxaCapCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim3); /* ATIM3 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim3BaseCfg);                                  /* 结构体初始化清零 */
    stcAtim3BaseCfg.u32WorkMode    = ATIM3_M1_M1CR_WORK_MODE_SAWTOOTH; /* 齿波模式 */
    stcAtim3BaseCfg.u32CountClkSel = ATIM3_M23_M23CR_CT_PCLK;          /* 定时器功能，计数时钟为内部PCLK */
    stcAtim3BaseCfg.u32PRS         = ATIM3_M23_M23CR_ATIM3CLK_PRS64;   /* PCLK/64 */
    stcAtim3BaseCfg.u32CntDir      = ATIM3_M23_M23CR_DIR_UP_CNT;       /* 向上计数，在三角波模式时只读 */
    ATIM3_Mode23_Init(&stcAtim3BaseCfg);                               /* ATIM3 的模式23功能初始化 */

    DDL_ZERO_STRUCT(stcAtim3ChxaCapCfg);                                               /* 结构体初始化清零 */
    stcAtim3ChxaCapCfg.u32CHxCmpCap   = ATIM3_M23_CRCHx_CSA_CSB_CAPTURE;               /* CH0A通道设置为捕获模式 */
    stcAtim3ChxaCapCfg.u32CHxCapSel   = ATIM3_M23_CRCHx_CRxCFx_CAPTURE_EDGE_RISE_FALL; /* CH0A通道上升沿下降沿捕获都使能 */
    stcAtim3ChxaCapCfg.u32CHxInFlt    = ATIM3_M23_FLTR_FLTxx_THREE_PCLK_4;             /* PCLK/4 3个连续有效 */
    stcAtim3ChxaCapCfg.u32CHxPolarity = ATIM3_M23_FLTR_CCPxx_NORMAL_IN_OUT;            /* 正常输入输出 */

    ATIM3_Mode23_PortInput_CHxA_Cfg(ATIM3_M23_OUTPUT_CHANNEL_CH0, &stcAtim3ChxaCapCfg); /* 端口输入初始化配置 */

    u16ArrValue = 0xFFFF;
    ATIM3_Mode23_ARRSet(u16ArrValue); /* 设置重载值,并使能缓存 */
    ATIM3_Mode23_ARR_Buffer_Enable(TRUE);

    u16CntValue = 0;
    ATIM3_Mode1_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM3_ClearAllIrqFlag();                                      /* 清中断标志 */
    ATIM3_Mode23_EnableIrq(ATIM3_M23_INT_CA0 | ATIM3_M23_INT_UI); /* 使能ATIM3 CB0比较/捕获中断 */
    EnableNvic(ATIM3_UEV_IRQn, IrqLevel3, TRUE);                  /* ATIM3_UEV 开中断 */
    EnableNvic(ATIM3_CHA_IRQn, IrqLevel3, TRUE);                  /* ATIM3_CHA 开中断 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
