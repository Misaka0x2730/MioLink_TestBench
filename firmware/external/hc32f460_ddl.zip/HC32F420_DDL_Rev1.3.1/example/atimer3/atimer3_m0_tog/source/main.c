/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "atim3.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_Atimer3_Port_Cfg(void);
static void App_Atimer3_Cfg(uint16_t u16Period);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_Atimer3_Port_Cfg(); /* ATIM3 端口配置 */

    App_Atimer3_Cfg(25000); /* ATIM3 配置; 16分频,周期25000-->25000*(1/4M) * 16 = 100000us = 100ms */

    ATIM3_Mode0_Run(); /* ATIM3 运行 */

    /* 用户可添加其他代码 */

    ATIM3_Mode0_Enable_TOG(TRUE);

    while (1)
        ;
}

/**
 * @brief  ATIM3 CHx 端口配置
 * @retval None
 */
void App_Atimer3_Port_Cfg(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */

    /* PA04(ATIM3_CH0A) PA07(ATIM3_CH0B)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                        /* 结构体初始化清零             */
    stcGpioInit.u32Pin      = GPIO_PIN_04 | GPIO_PIN_07; /* 端口引脚->P04，P07           */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;       /* 端口方向配置->推挽输出       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;            /* 端口上下拉配置->无上下拉     */
    GPIOA_Init(&stcGpioInit);                            /* 端口初始化                   */
    GPIO_PA04_AF_ATIM3_CH0A_SET();                       /* PA04复用为ATIM3_CH0A         */
    GPIO_PA07_AF_ATIM3_CH0B_SET();                       /* PA07复用为ATIM3_CH0B         */
}

/**
 * @brief  ATIM3 配置
 * @param  [in] u16Period:        周期
 * @retval None
 */
void App_Atimer3_Cfg(uint16_t u16Period)
{
    uint16_t              u16ArrValue;
    uint16_t              u16CntValue;
    stc_atim3_mode0_cfg_t stcAtim3BaseCfg = {0};

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralATim3); /* ATIM3 外设时钟使能 */

    DDL_ZERO_STRUCT(stcAtim3BaseCfg);                               /* 结构体初始化清零 */
    stcAtim3BaseCfg.u32WorkMode    = ATIM3_M0_M0CR_WORK_MODE_TIMER; /* 定时器模式 */
    stcAtim3BaseCfg.u32CountClkSel = ATIM3_M0_M0CR_CT_PCLK;         /* 定时器功能，计数时钟为内部PCLK */
    stcAtim3BaseCfg.u32PRS         = ATIM3_M0_M0CR_ATIM3CLK_PRS16;  /* PCLK/16 */
    stcAtim3BaseCfg.u32CntMode     = ATIM3_M0_M0CR_MD_16BIT_ARR;    /* 自动重载16位计数器/定时器 */
    stcAtim3BaseCfg.u32EnTog       = ATIM3_M0_M0CR_TOG_OFF;         /* TOG禁止 */
    stcAtim3BaseCfg.u32EnGate      = ATIM3_M0_M0CR_GATE_OFF;        /* 门控功能关闭 */
    stcAtim3BaseCfg.u32GatePolar   = ATIM3_M0_M0CR_GATE_POLAR_HIGH;

    ATIM3_Mode0_Init(&stcAtim3BaseCfg); /* ATIM3 的模式0功能初始化 */

    u16ArrValue = 0x10000 - u16Period;
    ATIM3_Mode0_ARRSet(u16ArrValue); /* 设置重载值 */

    u16CntValue = 0x10000 - u16Period;
    ATIM3_Mode0_Cnt16Set(u16CntValue); /* 设置计数初值 */

    ATIM3_Mode0_Enable_Output(TRUE); /* ATIM3 端口输出使能 */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
