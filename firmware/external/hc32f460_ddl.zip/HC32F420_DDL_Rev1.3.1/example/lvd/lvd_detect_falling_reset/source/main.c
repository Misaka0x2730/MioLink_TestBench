/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-20       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "flash.h"
#include "gpio.h"
#include "lvd.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_LvdPortInit(void);
static void App_LvdInit(void);

/**
 * @brief  Main function of project
 * @retval None
 */
int main(void)
{
    /* LVD 端口初始化 */
    App_LvdPortInit();

    /* LVD 初始化 */
    App_LvdInit();

    /* LVD 模块使能 */
    LVD_Enable(HC_LVD);

    /*
    ** LVD使能后并非立马可以正常工作，它需要一个建立时间，并且LVD使能之前LVD_OUT
    ** 输出的是默认低电平，当LVD使能时LVD_INPUT电平低于阈值，则使能后会产生一个上
    ** 升沿，由于受建立时间、响应时间、滤波时间的影响，这个上升沿很有可能是执行
    ** LVD_Enable(M0P_LVD)后的的几十微妙甚至是几十毫秒后才会到来。
    */
    delay1ms(100);

    STK_LED_ON();
    delay1ms(1000);
    STK_LED_OFF();

    while (1) {}
}

/* LVD 中断服务函数 */
void Lvd_IRQHandler(void)
{
    /* 判断中断标志位是否已置位 */
    if (TRUE == LVD_IsActiveFlag_IT(HC_LVD))
    {
        LVD_ClearFlag_IT(HC_LVD); /* 清除中断标志位 */

        /* 指示灯闪烁一次，提示用户已发生一次中断 */
        STK_LED_ON();
        delay1ms(1000);
        STK_LED_OFF();
        delay1ms(1000);
    }
}

/* LVD相关端口初始化 */
static void App_LvdPortInit(void)
{
    stc_gpio_init_t stcGpioInit = {0};

    /* GPIOA 外设时钟使能 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* 开启GPIOA外设时钟   */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* 开启GPIOB外设时钟   */

    /* LVD_OUT(PA03) 初始化 */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;
    stcGpioInit.u32Pin      = GPIO_PIN_03;
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;
    GPIOA_Init(&stcGpioInit);

    /* LED端口初始化 */
    stcGpioInit.u32Mode     = GPIO_MODE_OUTPUT_PP;
    stcGpioInit.u32Pin      = STK_LED_PIN;
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;
    GPIOB_Init(&stcGpioInit);

    /* PA03作为LVD的输出 */
    GPIO_PA03_AF_LVD_OUT_SET();
    STK_LED_OFF();

    /* 配置PB08为模拟输入，作为LVD检测电压输入*/
    GPIO_PB08_ANALOG_SET();
}

static void App_LvdInit(void)
{
    stc_lvd_init_t stcLvdCfg = {0};

    /* 第一步：开启LVD 外设时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripherallvd);

    /* 第二步：LVD 初始化配置 */
    stcLvdCfg.u32TriggerAction = LVD_TRIGGER_ACTION_RESET;
    stcLvdCfg.u32TriggerMode   = LVD_TRIGGER_MODE_FALLING;
    stcLvdCfg.u32InputSource   = LVD_INPUT_PB08;
    stcLvdCfg.u32ThresholdVolt = LVD_THRESHOLD_VOLT3p0V;
    stcLvdCfg.u32Filter        = LVD_FILTER_6820US;
    LVD_Init(HC_LVD, &stcLvdCfg);

    /* 第三步： 中断开启 */
    LVD_ClearFlag_IT(HC_LVD);
    LVD_EnableIT(HC_LVD);
    EnableNvic(LVD_IRQn, IrqLevel3, TRUE);
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
