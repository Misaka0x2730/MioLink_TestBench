/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of Flash.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
   2024-10-24       MADS            Add semicolon for GPIO macro call 
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2024, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void App_SystemClkInit_PLL45M_byRCH(void);
static void Gpio_Init(void);
/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static stc_sysctrl_sysclk_source_init_t stcSysClkSrc = {0};
static stc_sysctrl_clk_init_t           stcSysClk    = {0};

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ** This sample
 **
 ******************************************************************************/

int32_t main(void)
{
    delay1ms(2000);

    App_SystemClkInit_PLL45M_byRCH();
    Gpio_Init();

    GPIO_PB12_SET();

    for (int i = 0; i < 100000; i++)
    {
        __asm("nop");
    }

    GPIO_PB12_RESET();

    delay1ms(100);

    Flash_Cache_Reset();
    Flash_CacheConfig(FLASH_CACHE_INSTRUCTION_EN);

    GPIO_PB12_SET();

    for (int i = 0; i < 100000; i++)
    {
        __asm("nop");
    }

    GPIO_PB12_RESET();

    while (1)
        ;
}

static void Gpio_Init(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */
}

/**
 * @brief  以RCH_D为时钟源的PLL作为系统时钟源
 * @retval None
 */
static void App_SystemClkInit_PLL45M_byRCH(void)
{
    /* 第一步：开启BGR，模拟模块，必须开启BGR */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralAdc0);  /* 开启adc0外设时钟   */ 
    ADC_BGR_Enable(HC_ADC0); 
    
    /* 系统时钟源初始化 */ 
    stcSysClkSrc.u32SysClkSourceType = SYSCTRL_SYSCLK_SOURCE_TYPE_RCH|\
                                       SYSCTRL_SYSCLK_SOURCE_TYPE_PLL;    
    
    stcSysClkSrc.u32RCHState         = SYSCTRL_RCH_TRIM_24MHz |\
                                       SYSCTRL_RCH_DIV2;

    stcSysClkSrc.u32PLLState         = SYSCTRL_PLL_MULM_CONFIG(30) |\
                                       SYSCTRL_PLL_DIVN_CONFIG(2) |\
                                       SYSCTRL_PLL_OEN_ON|\
                                       SYSCTRL_PLL_WAITCYCLE_CONFIG(7) |\
                                       SYSCTRL_PLL_OD_CONFIG(2) |\
                                       SYSCTRL_PLL_SRC_RCH;
    
    while(Ok != SYSCTRL_SysClkSrcInit(&stcSysClkSrc)){;}    

    delay1ms(10);
        
    /* 系统时钟初始化 */          
    stcSysClk.u32SysClkSource        = SYSCTRL_SYSCLK_SOURCE_PLL;
    stcSysClk.u32WaitCycle           = SYSCTRL_FLASH_WAIT_CYCLE2;
    SYSCTRL_SysClkInit(&stcSysClk);
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
