/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides example of Flash.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "ddl.h"
#include "flash.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static uint32_t u32TestBuffer[128] = {0};
/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ** This sample
 **
 ******************************************************************************/

int32_t main(void)
{
    uint32_t u32Addr = 0x1f800u;

    /* 对需要擦除的扇区解锁，bit32设1，扇区252~255擦写使能   */
    Flash_LockSet(FlashLock1, 0x80000000u);

    /*  ==> 16位编程     */
    /*  FLASH目标扇区擦除 */
    while (Ok != Flash_OpModeConfig(FlashSectorEraseMode))
        ;
    if (Ok != Flash_SectorErase(u32Addr))
    {
        while (1)
            ;
    }
    /*  FLASH 字节写、校验 */
    while (Ok != Flash_OpModeConfig(FlashWriteMode))
        ;
    if (Ok != Flash_WriteHalfWord(u32Addr, (uint16_t*)u32TestBuffer, 256))
    {
        while (1)
            ;
    }

    /*  ==> 32位编程     */
    /*  FLASH目标扇区擦除 */
    while (Ok != Flash_OpModeConfig(FlashSectorEraseMode))
        ;
    if (Ok != Flash_SectorErase(u32Addr))
    {
        while (1)
            ;
    }

    /*  FLASH 字节写、校验 */
    while (Ok != Flash_OpModeConfig(FlashWriteMode))
        ;
    if (Ok != Flash_WriteWord(u32Addr, u32TestBuffer, 128))
    {
        while (1)
            ;
    }

    while (Ok != Flash_LockAll())
        ; /* 对应上述解锁的扇区，重新对该扇区加锁 */

    while (1)
        ;
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
