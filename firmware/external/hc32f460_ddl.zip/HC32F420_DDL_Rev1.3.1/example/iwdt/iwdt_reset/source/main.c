/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-08-15       MADS            First version
   2023-12-18       MADS            Delete IWDT_Start() after initialization
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022~2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "flash.h"
#include "gpio.h"
#include "iwdt.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define LED_BLINK() \
    do \
    { \
        STK_LED_OFF(); \
        delay1ms(100U); \
        STK_LED_ON(); \
        delay1ms(100U); \
        STK_LED_OFF(); \
        delay1ms(100U); \
        STK_LED_ON(); \
        delay1ms(100U); \
        STK_LED_OFF(); \
        delay1ms(100U); \
        STK_LED_ON(); \
        delay1ms(100U); \
        STK_LED_OFF(); \
    } while (0U);

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
static void App_GpioInit(void);
static void App_IwdtInit(void);

/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    App_GpioInit(); /* LED/按键 端口初始化 */

    /*  IWDT 复位现象观测 */
    if (SYSCTRL_ResetFlagGet(SYSCTRL_RESETFLAG_IWDT))
    {
        SYSCTRL_ResetFlagClear(SYSCTRL_RESETFLAG_IWDT);
        LED_BLINK();
    }

    App_IwdtInit(); /* IWDT 启动、初始化 */

    while (1)
    {
        /* 溢出前按键按下后执行喂狗程序 */
        if (STK_USERKEY_READ())
        {
            ;
        }
        else
        {
            IWDT_Feed();
            STK_LED_OFF();
        }
    }
}

/**
 * @brief  IWDT 中断服务程序
 */
static void App_IwdtInit(void)
{
    stc_iwdt_init_t stcIwdtInit = {0};

    /* 开启IWDT外设时钟 */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralIwt);

    /* IWDT 初始化(独立开门狗） */
    /* IWDT 溢出时间 = (计数值(u32ArrCounter)/32800) * 分频系数(u32Prescaler) */
    /* 本例为：(3125/10K)*16 = 5.0s */
    stcIwdtInit.u32Action     = IWDT_OVER_RESET__SLEEPMODE_STOP;
    stcIwdtInit.u32ArrCounter = 3125U;
    stcIwdtInit.u32Window     = 0xFFFU;
    stcIwdtInit.u32Prescaler  = IWDT_RC10K_DIV_16;
    IWDT_Init(&stcIwdtInit);
}

/**
 * @brief  GPIO 初始化
 */
static void App_GpioInit(void)
{
    stc_gpio_init_t stcGpioInit;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpiob); /* GPIOB外设时钟使能 */

    /* LED(PB12)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);                     /* 结构体初始化清零             */
    GPIO_PB12_RESET();                                /* 端口初始电平->低, 关闭LED    */
    stcGpioInit.u32Pin         = GPIO_PIN_12;         /* 端口引脚->P12                */
    stcGpioInit.u32Mode        = GPIO_MODE_OUTPUT_PP; /* 端口方向配置->推挽输出       */
    stcGpioInit.u32DriverLevel = GPIO_Driver_Level_H; /* 端口驱动能力配置->高驱动能力 */
    stcGpioInit.u32PullUpDn    = GPIO_PULL_NONE;      /* 端口上下拉配置->无上下拉     */
    GPIOB_Init(&stcGpioInit);                         /* 端口初始化                   */

    /* USER KEY(PB10)端口初始化 */
    DDL_ZERO_STRUCT(stcGpioInit);              /* 结构体初始化清零         */
    stcGpioInit.u32Pin      = GPIO_PIN_10;     /* 端口引脚->P10            */
    stcGpioInit.u32Mode     = GPIO_MODE_INPUT; /* 端口方向配置->输入       */
    stcGpioInit.u32PullUpDn = GPIO_PULL_NONE;  /* 端口上下拉配置->无上下拉 */
    GPIOB_Init(&stcGpioInit);                  /* 端口初始化               */
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
