/**
 *******************************************************************************
 * @file  main.c
 * @brief This file provides firmware functions to manage the XXX.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-07-15       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "crc.h"
#include "ddl.h"
#include "flash.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define TIMEOUT_VALUE 10000U /* 超时时间(实际超时时间基于指令执行时间)  注：根据需要设置合适的值 */

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
/* 待编码数据 */
static uint8_t au8CrcTestData[8] = {0x12U, 0x34U, 0x56U, 0x78U, 0x9aU, 0xbcU, 0xdeU, 0xf0U};
/* 待编码数据数组长度 */
static uint32_t u32TestDataLen = 8U;
static uint32_t u32RefCrc32    = 0xA85A34A3;
static uint32_t u32CrcResult   = 0U;

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @param  None
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    en_result_t      enResult   = Error;
    volatile uint8_t u8TestFlag = 0U;

    SYSCTRL_PeriphClkEnable(SysctrlPeripheralCrc); /* CRC外设时钟使能 */

    /* 8位位宽下输入数据测试示例 */
    enResult = CRC32_Get8(au8CrcTestData, u32TestDataLen, &u32CrcResult, TIMEOUT_VALUE); /* 产生CRC16编码 */
    if (Ok == enResult)
    {
        if (u32RefCrc32 == u32CrcResult) /* 判断CRC16编码值是否正确 */
        {
            u8TestFlag = Ok;
        }
    }
    /* 检验待校验数据与校验值是否匹配，如果匹配返回TRUE,否则返回FALSE */
    enResult = CRC32_Check8(au8CrcTestData, u32TestDataLen, u32CrcResult, TIMEOUT_VALUE);

    /* 16位位宽下输入数据测试示例 */
    enResult = CRC32_Get16((uint16_t*)au8CrcTestData, u32TestDataLen / 2, &u32CrcResult, TIMEOUT_VALUE); /* 产生CRC16编码 */
    if (Ok == enResult)
    {
        if (u32RefCrc32 == u32CrcResult) /* 判断CRC16编码值是否正确 */
        {
            u8TestFlag = Ok;
        }
    }
    /* 检验待校验数据与校验值是否匹配，如果匹配返回TRUE,否则返回FALSE */
    enResult = CRC32_Check16((uint16_t*)au8CrcTestData, u32TestDataLen / 2, u32CrcResult, TIMEOUT_VALUE);

    /* 32位位宽下输入数据测试示例 */
    enResult = CRC32_Get32((uint32_t*)au8CrcTestData, u32TestDataLen / 4, &u32CrcResult, TIMEOUT_VALUE); /* 产生CRC16编码 */
    if (Ok == enResult)
    {
        if (u32RefCrc32 == u32CrcResult) /* 判断CRC16编码值是否正确 */
        {
            u8TestFlag = Ok;
        }
    }
    /* 检验待校验数据与校验值是否匹配，如果匹配返回TRUE,否则返回FALSE */
    enResult = CRC32_Check32((uint32_t*)au8CrcTestData, u32TestDataLen / 4, u32CrcResult, TIMEOUT_VALUE);

    while (1U)
    {
        ;
    }
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
