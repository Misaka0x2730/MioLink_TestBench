/**
 *******************************************************************************
 * @file  main.c
 * @brief Main function.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2023-06-28       MADS            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "gpio.h"
#include "flash.h"
#include "sysctrl.h"

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define SRAM_BB_REGION_BASE 0x20000000 /*!< SRAM base address of bit-band region */
#define SRAM_BB_ALIAS_BASE  0x22000000 /*!< SRAM base address of bit-band alias */

/*!< bit_num set value range: 0 ~ 31 */
/*!< Bit reset in SRAM bit-band alias */
#define SRAM_BB_RESET_BIT(addr, bit_num) \
        (*(__IO uint32_t*)(SRAM_BB_ALIAS_BASE | ((addr - SRAM_BB_REGION_BASE) << 5) | ((bit_num) << 2)) = 0)
/*!< Bit set in SRAM bit-band alias */
#define SRAM_BB_SET_BIT(addr, bit_num) \
        (*(__IO uint32_t*)(SRAM_BB_ALIAS_BASE | ((addr - SRAM_BB_REGION_BASE) << 5) | ((bit_num) << 2)) = 1)
/*!< Bit get in SRAM bit-band alias */
#define SRAM_BB_GET_BIT(addr, bit_num) \
        (*(__IO uint32_t*)(SRAM_BB_ALIAS_BASE | ((addr - SRAM_BB_REGION_BASE) << 5) | ((bit_num) << 2)))

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
__IO uint32_t u32Var;
uint32_t      u32GetBitValue;

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Main function of project
 * @retval int32_t: return value, if needed
 */
int32_t main(void)
{
    /* SRAM bit band example */
    u32Var = 0x5555AAAA;
    SRAM_BB_RESET_BIT((uint32_t)&u32Var, 15);                /* Reset bit15 of the variable */
    u32GetBitValue = SRAM_BB_GET_BIT((uint32_t)&u32Var, 15); /* Get bit15 of the variable */

    SRAM_BB_SET_BIT((uint32_t)&u32Var, 31);                  /* Set bit31 of the variable */
    u32GetBitValue = SRAM_BB_GET_BIT((uint32_t)&u32Var, 31); /* Get bit31 of the variable */

    /* Peripheral bit band example */
    SYSCTRL_PeriphClkEnable(SysctrlPeripheralGpioa); /* GPIOA外设时钟使能 */
    b_GPIOA_ADS_PIN0 = 0;                            /* Reset bit0 of the register */
    b_GPIOA_OPENDRAIN_PIN0 = 1;                      /* Set bit0 of the register */

    while (1U)
    {
        ;
    }
}
/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
